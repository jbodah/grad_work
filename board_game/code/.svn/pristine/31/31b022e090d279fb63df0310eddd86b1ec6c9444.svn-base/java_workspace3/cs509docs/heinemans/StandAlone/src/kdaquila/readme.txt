Converted to Eclipse: 10-11-2003
Verified functioning: 10-11-2003
  * note: spider is challenging, so without auto-solve, I 
    can't ensure all paths are functioning...
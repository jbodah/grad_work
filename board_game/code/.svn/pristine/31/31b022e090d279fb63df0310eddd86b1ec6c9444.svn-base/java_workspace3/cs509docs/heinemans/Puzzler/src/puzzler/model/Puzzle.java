package puzzler.model;

import java.awt.Polygon;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;

/**
 * Represents a specific puzzle composed of puzzle pieces.
 * <p>
 * 
 * For convenience, this class exposes an {@link Iterator} of 
 * {@link PuzzlePiece} objects.
 * <p>
 * Note that there is no way to delete a puzzle piece from a puzzle.
 * This is an intentional design.
 * 
 * @author George Heineman
 */
public class Puzzle implements Iterable<PuzzlePiece>{

	/** Unique ID counter. */
	private static int id;
	
	/** Pieces stored by id. */
	Hashtable<Integer,PuzzlePiece> pieces = new Hashtable<Integer,PuzzlePiece>(); 
	
	/** 
	 * Pieces stored by z coordinate. The index value into the array
	 * reflects the z coordinate.
	 */
	ArrayList<PuzzlePiece> byZcoord = new ArrayList<PuzzlePiece>(); 
	
	/**
	 * Return the piece associated with unique identifier or null
	 * if none exists.
	 * 
	 * @param id
	 */
	public PuzzlePiece getPiece (int id) {
		return pieces.get(id);
	}

	/**
	 * By restricting access to the PuzzlePiece we can effectively 
	 * guarantee that id within the puzzle is unique.
	 * <p>
	 * The added piece has a z-coordinate larger (i.e., behind) than
	 * any existing puzzle piece in the puzzle.
	 * 
	 * @param finalX
	 * @param finalY
	 * @param shape
	 */
	public PuzzlePiece addPiece (int finalX, int finalY, Polygon shape) {
		PuzzlePiece piece = new PuzzlePiece (++id, finalX, finalY, shape);
		
		byZcoord.add(piece);
		pieces.put(id, piece);
		
		return piece;
	}
	
	/**
	 * Return all pieces in order of z coordinate (i.e., from FRONT
	 * to BACK).
	 * 
	 * Generate {@link Iterator} over all puzzle pieces.
	 */
	public Iterator<PuzzlePiece> iterator() {
		return byZcoord.iterator();
	}
	
	/**
	 * Bring a puzzle piece to the front. If piece doesn't exist, return 
	 * <code>false</code> otherwise <code>true</code> is returned.
	 * 
	 * @param pp
	 */
	public boolean bringToFront(int id) {
		PuzzlePiece pp = pieces.get(id);
		if (pp == null) { return false; }
		
		byZcoord.remove(pp);
		byZcoord.add(0, pp);
		return true;
	}
}

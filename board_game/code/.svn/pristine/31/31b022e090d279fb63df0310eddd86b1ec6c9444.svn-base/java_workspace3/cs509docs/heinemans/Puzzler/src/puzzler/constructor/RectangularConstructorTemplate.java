package puzzler.constructor;

/**
 * Class that divides pieces of a puzzle such that each individual shape is 
 * a composition of unitSize x unitSize blocks.
 * 
 * @author George Heineman
 */
public abstract class RectangularConstructorTemplate extends ConstructorTemplate {
	
	int unitSize;
	
	public RectangularConstructorTemplate (int width, int height, int unitSize) {
		super(width, height);
		
		this.unitSize = unitSize;
	}
	

}

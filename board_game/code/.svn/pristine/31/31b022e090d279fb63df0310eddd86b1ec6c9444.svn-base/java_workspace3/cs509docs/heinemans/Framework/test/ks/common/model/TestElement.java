package ks.common.model;

import junit.framework.TestCase;

// must test listeners, mostly
public class TestElement extends TestCase {

	class TestListener implements ElementListener {
		
		public int val;
		
		public TestListener () {
			super();
		}
		
		
		@Override
		public void modelChanged(Element elt) {
			val = ((MutableInteger) elt).getValue();		
		}
	};
	
	public void testConstruct() {
		TestListener el = new TestListener();
		
		MutableInteger mi = new MutableInteger(47);
		mi.setListener(el);
		assertEquals (el, mi.getListener());
		mi.setValue(33);
		
		// assert listener was told!
		assertEquals (33, el.val);
		
		el.val = 99; // fix it improperly
		
		// same value DOES NOT reissue event
		mi.setValue(33);
		assertEquals (99, el.val);
		
		// invalid to set name to null.
		try {
			mi.setName(null);
			fail ("can't set model name to null");
		} catch (Exception e) {
			
		}
	}
	
	public void testElementBase() {
		Element e = new Element ();
		e.setName("sample");
		assertEquals ("ks.common.model.Element:sample", e.toString());
	}
	
}

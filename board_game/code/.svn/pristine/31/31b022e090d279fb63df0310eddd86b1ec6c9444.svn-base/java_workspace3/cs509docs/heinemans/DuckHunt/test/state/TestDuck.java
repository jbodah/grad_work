package state;

import java.awt.Dimension;
import java.awt.Point;

import state.Duck;
import junit.framework.TestCase;

/**
 * Set of tests for validating the Duck class.
 * 
 * @author heineman
 */
public class TestDuck extends TestCase {

	/** A duck to experiment with. */
	Duck duck1;

	/** Another duck to experiment with. */
	Duck duck2;
	
	/** Default width to use. */
	int width1 = 20; 
	/** Default height to use. */
	int height1 = 20;

	/** Default width to use. */
	int width2 = 40;
	
	/** Default height to use. */
	int height2 = 40;
	
	/**
	 * Setup some sample ducks to work with.
	 */
	protected void setUp() {
		duck1 = new Duck (new Point (100, 100), width1, height1);
		duck2 = new Duck (new Point (200, 200), width2, height2);
	}
	
	/*
	 * Test method for 'state.Duck.offset(int, int)'
	 */
	public void testOffset() {
		Point p = duck1.getLocation();
		duck1.offset(7,9);
		Point q = new Point (p.x+7, p.y+9);
		assertEquals (q, duck1.getLocation());
	}

	/*
	 * Test method for 'state.Duck.setLocation(Point)'
	 */
	public void testSetLocation() {
		// validate that Point is not copied when passed in.
		Point p = new Point (20, 20);
		duck1.setLocation (p);
		p.x = 99;
		assertEquals (duck1.getLocation(), new Point (20,20));
		
		// validate that setting point works.
		duck1.setLocation (new Point (30,30));
		assertEquals (duck1.getLocation(), new Point (30, 30));
	}

	/*
	 * Test method for 'state.Duck.setMovement(int, int)'
	 */
	public void testSetMovementIntInt() {
		// verify both values are appropriate.
		duck1.setMovement (14, 15);
		assertEquals (new Dimension (14, 15), duck1.getMovement());
	}

	/*
	 * Test method for 'state.Duck.getMovement()'
	 */
	public void testGetMovement() {
		// validate that Dimension is not passed through
		Dimension m = new Dimension (14, 15);
		duck1.setMovement (m);
		m.height = m.height+1;
		assertEquals (new Dimension (14, 15), duck1.getMovement());
	}

	/*
	 * Test method for 'state.Duck.setMovement(Dimension)'
	 */
	public void testSetMovementDimension() {
		Duck d = new Duck(new Point (1,1), 20, 30);
		d.setMovement (new Dimension (14, 15));
		assertEquals (new Dimension (14, 15), d.getMovement());
	}

	/*
	 * Test method for 'state.Duck.Duck(Point, int, int)'
	 */
	public void testDuck() {
		Duck d = new Duck(new Point (1,1), 20, 30);
		assertEquals (20, d.getWidth());
		assertEquals (30, d.getHeight());
		assertEquals (new Point (1,1), d.getLocation());
		assertEquals (new Dimension (0,0), d.getMovement());
		assertTrue (d.isAlive());
	}

	/*
	 * Test method for 'state.Duck.getLocation()'
	 */
	public void testGetLocation() {
		// validate that Point is not exposed via getLocation
		Point p = duck1.getLocation();
		Point copy = new Point (p);
		p.y = p.y + 1; // modify
		Point q = duck1.getLocation();
		assertEquals (q, copy);
		
		// validate that getting point it works.
		p = new Point (20, 20);
		duck1.setLocation (p);
		assertEquals (duck1.getLocation(), new Point (20,20));
	}

	/*
	 * Test method for 'state.Duck.getWidth()'
	 */
	public void testGetWidth() {
		// different ducks may have different widths
		assertEquals (duck1.getWidth(), width1);
		assertEquals (duck2.getWidth(), width2);

	}

	/*
	 * Test method for 'state.Duck.getHeight()'
	 */
	public void testGetHeight() {
		// different ducks may have different heights
		assertEquals (duck1.getHeight(), height1);
		assertEquals (duck2.getHeight(), height2);
	}

	/*
	 * Test method for 'state.Duck.kill()'
	 */
	public void testKill() {
		Duck d = new Duck(new Point (0,0), 20, 20);
		assertTrue (d.isAlive());
		d.kill();
		assertFalse (d.isAlive());
	}

	/*
	 * Test method for 'state.Duck.intersects(Point)'
	 */
	public void testIntersects() {
		// lots of cases to cover! Not all are being shown here, as you may imagine.
		Duck d = new Duck(new Point (100,100), 20, 20);
		assertTrue(d.intersects(new Point (100, 100)));
		assertTrue(d.intersects(new Point (120, 120)));
		assertFalse(d.intersects (new Point (0,0)));
	}

	/*
	 * Test method for 'state.Duck.isAlive()'
	 */
	public void testIsAlive() {
		Duck d = new Duck(new Point (0,0), 20, 20);
		assertTrue (d.isAlive());
	}

}

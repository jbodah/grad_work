package gui;

import java.awt.Component;
import java.awt.event.MouseEvent;

public class Tests {
	/** (x,y) are offsets into the component. Feel Free to Use as Is. */
	public static MouseEvent createPressed (Component comp, int x, int y) {
		MouseEvent me = new MouseEvent(comp, MouseEvent.MOUSE_PRESSED, 
				System.currentTimeMillis(), 0, 
				x, y, 0, false);
		return me;
	}
	
	/** (x,y) are offsets into the component. Feel Free to Use as Is. */
	public static MouseEvent createReleased (Component comp, int x, int y) {
		MouseEvent me = new MouseEvent(comp, MouseEvent.MOUSE_RELEASED, 
				System.currentTimeMillis(), 0, 
				x, y, 0, false);
		return me;
	}
	
	/** (x,y) are offsets into the component. Feel Free to Use as Is. */
	public static MouseEvent createClicked (Component comp, int x, int y) {
		MouseEvent me = new MouseEvent(comp, MouseEvent.MOUSE_CLICKED, 
				System.currentTimeMillis(), 0, 
				x, y, 0, false);
		return me;
	}
	
	/** (x,y) are offsets into the component. Feel Free to Use as Is. */
	public static MouseEvent createDoubleClicked (Component comp, int x, int y) {
		MouseEvent me = new MouseEvent(comp, MouseEvent.MOUSE_CLICKED, 
				System.currentTimeMillis(), 0, 
				x, y, 0, false);
		return me;
	}
	
	/** (x,y) are offsets into the component. Feel Free to Use as Is. */
	public static MouseEvent createDragged (Component comp, int x, int y) {
		MouseEvent me = new MouseEvent(comp, MouseEvent.MOUSE_DRAGGED, 
				System.currentTimeMillis(), 0, 
				x, y, 0, false);
		return me;
	}
}

package gui;


import java.awt.Point;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Package class to represent one of the individual score points that is to be drawn
 * in semi-overlapping time.
 */
class Score {
	// value
	int value;
	
	// when recorded
	long now;
	
	// location
	Point location;
	
	/**
	 * Default constructor for a Score object at a given location and value.
	 * 
	 * The current system time is recorded.
	 * 
	 * @param value
	 * @param loc
	 */
	Score (int value, Point loc) {
		this.value = value;
		this.now = System.currentTimeMillis();
		this.location = loc;
	}
	
	/**
	 * Constructor to be used by clone.
	 * 
	 * @param value
	 * @param loc
	 * @param time
	 */
	private Score (int value, Point loc, long time) {
		this.value = value;
		this.now = time;
		this.location = loc;
	}
	
	/**
	 * Return a clone of a Score object.
	 */
	public Object clone() {
		Score sc = new Score (this.value, (Point) this.location.clone(), this.now);
		return sc;
	}
}

/**
 * Acts as a container for the floating scores that are drawn on the canvas.
 * 
 * @author heineman
 */
public class Scores {
	/** collection of active scores */
	ArrayList<Score> scores = new ArrayList<Score>();

	/** 
	 * Record a score at the location, with specific points.
	 * 
	 * Because we know we are to be accessed in multi-thread environment, we synchronize
	 * at the method boundary, since ArrayList objects are not thread-safe.
	 * 
	 * @param point
	 * @param loc
	 */
	public synchronized void addScore (int point, Point loc) {
		scores.add(new Score(point, loc));   // have to add BEFORE starting up! Race condition			
	}
	
	/**
	 * Determines if there still is a need to draw points,
	 *  
	 * @return  true if there are no scores in our container
	 */
	public synchronized boolean isEmpty() {
		return scores.isEmpty();
	}
	
	/** 
	 * Return an iterator over the scores.
	 * 
	 * Make sure you sychronize over scores prior to calling this method. 
	 */
	public synchronized Iterator<Score> iterator() {
		return scores.iterator();
	}
}

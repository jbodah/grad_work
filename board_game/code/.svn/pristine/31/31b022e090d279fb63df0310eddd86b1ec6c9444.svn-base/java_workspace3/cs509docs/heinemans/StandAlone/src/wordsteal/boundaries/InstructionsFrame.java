package wordsteal.boundaries;

/**
 * Instructions Frame
 * @author Dan
 */
public class InstructionsFrame extends javax.swing.JFrame {

	//Version number
	private static final long serialVersionUID = 1L;
	
	/** 
	 * Creates new form HelpFrame 
	 * @param title Title displayed on the title bar of the application window 
	 */
    public InstructionsFrame(String title) {
    	super(title);
    	this.setResizable(false);
        initComponents();
    }

    /** 
     * initComponents
     * 
     * Initializes the components in the GUI
     */     
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        OKButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24));
        jLabel1.setText("WordSteal Rules");

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("\n  WordSteal is a fast-paced, competitive word game played by 2 - 4 players. The object of the game is to form words from the\n  given letter tiles, positioning them on the board to out-maneuver your opponents - or simply steal your opponent's words (and \n  points). \n\n  Setting up a Game:\n        �    To start a new game, select \"New Game\" on the main screen.\n        �    Set up the game by selecting the game options.\n        �    Select a \"Winning Score\" value, by default this is set to 50 points.\n        �    Select a \"Turn Time Limit\" value, by default this is set to 90 seconds.\n\n  Basic Game Rules :\n        �    Each player plays from a pool of seven tiles selected randomly from a starting set.\n        �    The first player to take a turn must drag tiles to the center of the board to form a word.\n        �    Each tile must touch one another with one tile covering the center green spot. Words can be placed horizontally or \n             vertically in a single row or column.\n        �    Once a player has dragged their tiles to the center of the board they must hit submit to create their word. If a \n             word is considered as illegal then the tiles are removed from the board and play is passed to the next player.\n        �    In turn, each player must place horizontally or vertically a minimum of two tiles on the board to form a word.\n        �    Players submit only one word per turn, although placed words may create more than one word on the board.\n        �    Players' turns are indicated by both the timer.\n        �    When a player's turn is completed and a word has been placed on the board then newly generated tiles will appear in\n              the rack.\n        �    The timer will tick down the seconds each player has remaining for each play.\n        �    At the end of a game, a log can be saved that describes all of the turns  played in the game.\n\n  Scoring:\n        �    Players placing words are awarded one point for each tile played. Players can add to their score by stealing points by\n             adding to existing words in play, which in turn will remove points from their opposition.\n             Example:\n\to    Player 1 places the word \"help\" = 4 points\n\to    Player 2 places \"less\" to create \"helpless\" = 4+4 points\n\to    Player 1 would have zero points while Player 2 would gain 8 points\n\to    If Player 1 could add \"ness\" to create \"helplessness\" thus scoring 12 points their opposition's \n\t      score would return to zero.\n        �    Points can be also be achieved by adding words parallel to existing words.\n              Example:\n                                READY\n              HELPLESSNESS\n  \n             Player 2 would lose 3 points while player 1 would gain 8 points. 5 points for the word they placed \"ready\" and 3 for the\n             additional 2 tile words they created, \"re\",\"es\" & \"as\"\n        �    Other points can be gained by placing tiles over orange colored squares. These additional points are indicated with an\n              orange highllighted number located next to the players' names.  These points can only be won if you place a tile over a\n              pink colored square, which clears the board.  If someone else clears the board then all bonus points you gained by\n              covering orange squares are lost.\n\n  Miscellaneous: \n  One situation might cause confusion, so is worth clarifying: \n        �    It is legal (and sometimes beneficial) to deliberately skip your turn even if you have a valid move available. Doing this is\n             not considered bad sportsmanship. Rationale: A 'No Skip' rule would not work, because it would be totally\n             unenforceable, and would likely lead to arguments about whether someone skipping was deliberate or not. \n\n  Additional Rules: \n  Originally, the game was played without any extra rules, but several variations have developed over time. These additional rules\n  only take effect if they are selected in the game options before the game is started. Any combination of one or more of these\n  rules may be chosen.\n        �    No S: Also called NS, this is a popular variation of play. No player may extend a word (not even their own word) by\n             adding a single S to the end of the word. Note that it is OK to extend 'CATCH' to 'CATCHES', or 'TOP' to 'STOP', or 'PIN'\n             to 'SPINS', but not OK to extend 'SPIN' to 'SPINS'. Extending 'THESE' to 'THESES' is also disallowed even though the\n             two words are unrelated. However, extending single letters such as 'A' to 'AS' is OK. Any player who breaks this rule\n             automatically loses the turn.\n        �    No Pinks: Also called NP. It is not legal to clear the board. The pink clearing squares have a line in them to indicate they\n             are not valid plays. Any player who plays a tile on a pink square automatically loses the turn.\n        �    No S, No Pinks: This combination is very popular. Some players play nothing else.\n        �    Two/Three Tile: A few players enjoy this a lot. A player must play exactly 2 (or 3) of the 7 tiles on each move (or else\n             skip). Any player who plays more tiles will lose their turn.\n\n Accessibility Controls:\n        �    Use the tab key to switch between all of the selectable objects on the main screen.\n        �    Moving tiles on the rack and board:\n\to    Press tab until a tile on the rack turns red. Move the arrow keys around to highlight different tiles on the board\n\t      and rack. Press space to grab a tile and then move it around.\n        �    Keyboard shortcuts:\n\to    The file menu can be accessed with Alt+F.\n\to    The edit menu can be accessed with Alt+E.\n\to    The help menu can be accessed with Alt+H.\n\to    File > New Game can be accessed with Ctrl+N.\n\to    File > Exit can be accessed with Ctrl+Q.\n\to    Edit > Undo can be accessed with Ctrl+Z.\n\to    Redo can be accessed with Ctrl+Y.\n\n  Rules adapted from (http://wordsteal.mymesis.com/altpages/wordstealrules.htm). \n");
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setEditable(false);
        jScrollPane1.setViewportView(jTextArea1);
        jTextArea1.setCaretPosition(0);

        OKButton.setText("OK");
        OKButton.setActionCommand("OKButton");
        
        //Action listener detects when "OK" button has been clicked
        OKButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	OKButtonActionPerformed(evt);
            }
        });

        //Set up form 
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 813, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(342, 342, 342)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(421, 421, 421)
                        .addComponent(OKButton, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 717, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(OKButton)
                .addContainerGap(35, Short.MAX_VALUE))
        );
        
        pack();
    }// </editor-fold>
    
    /**
     * Action listener detects when "OK" button has been clicked 
     * @param java.awt.event.ActionEvent
     */
    private void OKButtonActionPerformed(java.awt.event.ActionEvent evt) {
        setVisible(false);
        dispose();
    }

    /** Variable Declarations */     
    private javax.swing.JButton OKButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration

}


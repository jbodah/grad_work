package puzzler.controller.gui;

import gui.Tests;

import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.net.URL;

import puzzler.PuzzlerApplication;
import puzzler.model.Puzzle;
import puzzler.model.PuzzlePiece;
import puzzler.view.PuzzleManipulation;
import junit.framework.TestCase;
import puzzler.constructor.SimpleBlocksConstructor;

public class TestPieceMoverController extends TestCase {
	/** Overall application. */
	PuzzlerApplication app;
	
	/** Panel object being manipulated by this controller. */
	PuzzleManipulation panel;
	
	/** Sample puzzle. */
	Puzzle puzzle;
	
	/** Test image. */
	public static final String testImage = "/puzzler/controller/gui/testImage.jpg";
	
	@Override
	protected void setUp() {
		app = new PuzzlerApplication();
		
		panel = app.getPuzzleManipulation();
		
		// create sample puzzle
		SimpleBlocksConstructor sbc = new SimpleBlocksConstructor(120, 220, 50);
		puzzle = sbc.construct();
		
		// load test image
		URL u = this.getClass().getResource(testImage);
		Image image = Toolkit.getDefaultToolkit().createImage(u);
		if (image == null) {
			fail("unable to load test image:" + testImage);
		} 
			
		// Add pieces.
		Point loc = new Point (0, 0);
		for (PuzzlePiece pp : puzzle) {
			loc.translate(2, 2);
			
			// Piece knows of its location for model
			pp.setLocation(loc.x, loc.y);
			
			// PieceView knows of its location so it can draw itself properly.
			panel.addPiece(pp, image, pp.shape, new Point(pp.properX, pp.properY), loc);
		}
	}
	
	@Override
	protected void tearDown() {
		app.setVisible(false);
		app.dispose();
	}
	
	public void testMover() {
		PieceMoverController pmc = new PieceMoverController(panel);
		pmc.setPuzzle(puzzle);
		
		// grab piece that is found at (8,8) in the panel. note that the
		// first puzzle piece is at (2,2) so this means click in this puzzle
		// piece at relativeX,Y of [6,6].
		pmc.mousePressed(Tests.createPressed(panel, 8, 8));
		
		// say something about selected piece.
		assertTrue (pmc.selected != null);
		PuzzlePiece sel = pmc.selected;
		assertEquals (1, pmc.selected.id);
		
		// move out to here. The delta is 80-8, 80-8 or [72,72]so the final
		// location is going to be [2+72, 2+72] which is snapped to the grid
		// to make this [70, 70].
		pmc.mouseDragged(Tests.createDragged(panel, 80, 80));
		pmc.mouseReleased(Tests.createDragged(panel, 80, 80));
		
		// validate new location of this piece (snapped to grid.)
		assertEquals (70, sel.getX());
		assertEquals (70, sel.getY());
	}
}

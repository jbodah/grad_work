package state;

import java.awt.Dimension;
import java.awt.Point;

/**
 * 
 *
 * A bit of a hack to use Dimension to refer to (dx, dy) vector.
 * 
 * @author George
 */
public class Duck {
	/** Location of upper left-corner. */
	Point location;
	
	/** Dimensions of duck. */
	int width;
	int height;
	
	/** Movement in x and y direction. */
	int dx;
	int dy;
	
	/** Whether duck is alive. */
	boolean alive = true;
	
	/** 
	 * Move duck an incremental distance in both x and y coordinates.
	 * 
	 * @param dx
	 * @param dy
	 */
	public void offset (int dx, int dy) {
		location.x += dx;
		location.y += dy;
	}
	
	/**
	 * Set the location of the duck to the given input.
	 * 
	 * Make sure point is copied.
	 * 
	 * @param p
	 */
	public void setLocation (Point p) {
		location.x = p.x;
		location.y = p.y;
	}
	
	/** 
	 * Set the movement for the duck.
	 * @param dx
	 * @param dy
	 */
	public void setMovement (int dx, int dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	/** 
	 * Get the movement for the duck as a single Dimension object.
	 * @return movement in a dimension.
	 */
	public Dimension getMovement () {
		return new Dimension (dx, dy);
	}
	
	/** 
	 * Set the movement for the duck using a single Dimension object.
	 * 
	 * @param d   new non-null movement.
	 */
	public void setMovement (Dimension d) {
		this.dx = d.width;
		this.dy = d.height;
	}
	
	/**
	 * Place duck in its location.
	 * 
	 * Duck is initially stationary.
	 * 
	 * @param p      base location of upper left coordinate
	 * @param width  width of duck image
	 * @param height height of duck image
	 */
	public Duck (Point p, int width, int height) {
		this.location = p;
		this.width = width;
		this.height = height;
		
		this.dx = 0;
		this.dy = 0;
	}
	
	/** 
	 * Return location of duck.
	 *
	 * Note that copy is returned to avoid exposing state unnecessarily.
	 * 
	 * @return Point where duck is located.
	 */
	public Point getLocation() {
		return new Point (location);
	}
	
	/** 
	 * Return width of duck.
	 * @return  width in pixels.
	 */
	public int getWidth() {
		return width;
	}
	
	/** 
	 * Return height of duck.
	 * 
	 * @return height in pixels.
	 */
	public int getHeight() {
		return height;
	}
	
	/** 
	 * Kill off the duck.
	 *
	 * Duck is no longer alive after this method call.
	 */
	public void kill () {
		alive = false;
	}
	
	/**
	 * Determines if point intersects duck image.
	 * 
	 * @param p   the desired point
	 * @return    true if the given point is located within the rectangular duck region; false otherwise.
	 */
	public boolean intersects (Point p) {
		if (p.x < location.x) return false;
		if (p.x > location.x + width) return false;
		if (p.y < location.y) return false;
		if (p.y > location.y + height) return false;
		
		return true;
	}

	/**
	 * Determines if duck is still alive.
	 * 
	 * @return  true if the duck is alive; false otherwise.
	 */
	public boolean isAlive() {
		return alive;
	}
	
	/**
	 * Represents duck state as a String.
	 * 
	 * @return   String representation of duck.
	 */
	public String toString() {
		return "Duck @ " + location + "[" + width + "," + height + "]";
	}
}

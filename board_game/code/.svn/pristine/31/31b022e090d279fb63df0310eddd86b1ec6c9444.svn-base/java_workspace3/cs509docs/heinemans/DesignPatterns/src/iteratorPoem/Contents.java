package iteratorPoem;

import java.util.ArrayList;

/**
 * 
 * @author heineman
 *
 * @param <K>
 */
public interface Contents<K> {

	public void add(K k);
}

package ks.framework.interfaces;

/**
 * Manages connected status of users on server side.
 * 
 */
public interface IServerConnection {
	
	/**
	 * Register with the communicator the means to interact with given userName.
	 * 
	 * @param userName    String representing user connecting to server
	 * @param agent       ICommunicator object managing our communication.
	 */
	boolean connectUser(String userName, ICommunicator agent);
	
	/**
	 * Remove user from communication set.
	 * 
	 * @param userName    String representing user connecting to server
	 */
	boolean disconnectUser(String userName);
}

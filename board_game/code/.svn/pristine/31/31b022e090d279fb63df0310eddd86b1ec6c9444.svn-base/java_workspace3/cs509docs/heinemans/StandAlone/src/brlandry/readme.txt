Converted to Eclipse: 10-11-2003
Verified functioning: 10-11-2003
  * won some games.  
  * solve available! But some solves get stuck in 'endless' loop, and upon
    stopping, a card can be removed from the foundation. Not sure where the
    problem is... 
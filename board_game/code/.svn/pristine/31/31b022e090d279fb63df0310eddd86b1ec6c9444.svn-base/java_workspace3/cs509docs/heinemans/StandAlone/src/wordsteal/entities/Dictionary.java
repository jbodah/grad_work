package wordsteal.entities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Random;

public class Dictionary {

	//This is completely canned data and needs to be rewritten
	String letters = "";
	String[] words;
	
	/** Generator to ensure consistency. Create default one anew in case no seed set. */
	Random rndGenerator = new Random();
	
	// assume we can go UP and then DOWN
	public static final String defaultDictionary = "../StandAlone/Dictionaries/test.txt";
	
	public static Dictionary createDefaultDictionary() throws Exception {
		
		return new Dictionary(defaultDictionary);
	}
	
	/** Use this see when generating letters. */
	public void setSeed(int seed) {
		rndGenerator = new Random(seed);
	}
	
	public Dictionary(String filename) throws Exception {
		
		BufferedReader br = new BufferedReader(new FileReader(filename));
		
		String currentLine = br.readLine();
		
		while(currentLine.contains("=")) {
			
			String[] letter = currentLine.split("=");
			int num = Integer.parseInt(letter[1]);
			
			for(int i = 0; i < num; i++) {
				
				this.letters += letter[0];
			}
			
			currentLine = br.readLine();
			
		}
		
		this.words = currentLine.split(" ");
		Arrays.sort(this.words, String.CASE_INSENSITIVE_ORDER);
		
		br.close();
	}
	
	/**
	 * Generate a new letter.
	 * 
	 * @return
	 */
	public String generateLetter() {
		return String.valueOf(this.letters.charAt((int)(rndGenerator.nextDouble()*this.letters.length())));
	}
	
	public boolean isValidWord(String word) {
		return (Arrays.binarySearch(this.words, word, String.CASE_INSENSITIVE_ORDER) >= 0);
	}
	
}

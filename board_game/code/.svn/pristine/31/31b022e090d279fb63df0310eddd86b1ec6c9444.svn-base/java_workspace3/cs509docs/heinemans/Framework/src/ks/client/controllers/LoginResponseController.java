package ks.client.controllers;

import ks.client.UserContext;
import ks.client.interfaces.ILobby;
import ks.client.interfaces.IProcessClientMessage;
import ks.framework.common.Message;

/**
 * When a client registers for a new account, the userContext must be updated
 * to record this information. This controller is responsible for that task.
 * 
 * Only to be received from the server when actually logging into the server; not for
 * use when other users actually login.
 * 
 * @author George Heineman
 */
public class LoginResponseController implements IProcessClientMessage {

	@Override
	public boolean process(ILobby lobby, Message m) {
		UserContext context = lobby.getContext();
		if (!context.getSelfRegister()) { return true; }
		
		org.w3c.dom.Node node = m.contents(); 
		org.w3c.dom.NamedNodeMap map = node.getAttributes();
		org.w3c.dom.Node child = map.getNamedItem("player");
		String registeredUser = child.getNodeValue();
		
		// manipulate context to record proper information.
		context.setUser(registeredUser);
		context.setSelfRegister(false);
		return true;
	}

}

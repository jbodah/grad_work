You will develop your Kombat Solitaire variation within this project

Leave the ks source code alone without any changes. I am making it 
available so you can have full access to the source code, which may
make it easier for you to debug and solve your individual assignments.

When the time comes to submit your homework, you will only
submit the classes within your packages.

To run some "stand alone" examples, Launch the following:

  brlandry.GrandfatherClock
  darrent.FreeCell
  dijordan.PyramidGame
  heineman.Idiot
  heineman.Narcotic
  kdaquila.Spider
  scaviola.BCastle
  yostinso.FlowerGarden
  

package contractChecking;


public class TestSafeService1 extends BaseTests {
	
	public IDuplicate getObject() { 
		return new SafeService1();
	}
	
}

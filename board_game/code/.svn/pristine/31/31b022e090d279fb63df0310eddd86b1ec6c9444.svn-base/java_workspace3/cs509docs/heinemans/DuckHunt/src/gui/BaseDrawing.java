package gui;

import java.awt.*;

/**
 * This is the base class within the decorator chain.
 * 
 * Note that in our example, this class ultimately does nothing. Perhaps a small
 * background handler could be placed here.
 * 
 * Note that initially, this contains the full redrawState() method which has been
 * extracted from DuckCanvas.
 * 
 * So we separate DuckCanvas into two parts; since that class IS_A Canvas to manage
 * the mouse events, it can't also be IS_A Drawing Canvas.
 * 
 * @author heineman
 */
public class BaseDrawing extends DrawingCanvas {
	

	/**
	 * The base drawing Concrete drawer will put everything into a screen image so that
	 * it can, ultimately, be copied into the given drawing field.
	 * 
	 * @param state
	 * @param drawingField
	 */
	public BaseDrawing () {

	}

	/**
	 * Request game state to be redrawn.
	 */
	public void drawState (Graphics sc) {
		// nothing...
	}

}

package ks.server.ipc;

import org.w3c.dom.Document;



import junit.framework.TestCase;
import ks.framework.common.Configure;
import ks.framework.common.Message;

public class TestListener extends TestCase {

	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
			
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
	}

	public void testLoginSuccess() {
		// validate a simple chat
		String s = Message.requestHeader() + "<chat><text>Here is the message</text></chat></request>";
		Document d = Message.construct(s);
		assertTrue (d != null);
		
		Message m = new Message(d);
		
		// validate generic ACK
		Message m2 = Listener.loginSuccess(m.id, "1132", "nothing");
		assertEquals ("loginResponse", m2.getName());
	}
	

	public void testLoginFailure() {
		
		// validate generic negative response
		Message m = Listener.loginFailure("99", "1132", "nothing");
		assertEquals ("loginResponse", m.getName());
	}
	
}

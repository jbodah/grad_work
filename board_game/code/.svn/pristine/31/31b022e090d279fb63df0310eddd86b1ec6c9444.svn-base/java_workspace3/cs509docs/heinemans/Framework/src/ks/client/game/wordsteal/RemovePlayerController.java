package ks.client.game.wordsteal;


import ks.client.interfaces.IGameInterface;
import wordsteal.interfaces.IWordstealApp;

/**
 * Remove given player from the game.
 * <p>
 * Manages lots of cleanup/housework.
 * 
 * @author George Heineman
 */
public class RemovePlayerController extends CommonMoveController {
	
	/** 
	 * Construct controller
	 * @param mainFrame MainFrame allows ability to set and retrieve entity information
	 */
	public RemovePlayerController(IWordstealApp mainFrame) {
		super(mainFrame);
	}
	
	/**
	 * Remove player from game.
	 * 
	 * @param callback 
	 * @param moveString 
	 */
	public boolean process(IGameInterface callback, String fullName){
		
		this.mf.getGame().removePlayer(fullName);
		
		this.mf.updateGUI();		
		return true;
	}


}

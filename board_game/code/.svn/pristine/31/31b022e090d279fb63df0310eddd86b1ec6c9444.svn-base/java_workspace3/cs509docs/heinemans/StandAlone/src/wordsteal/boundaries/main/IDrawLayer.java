package wordsteal.boundaries.main;

import java.awt.Graphics2D;

/**
 * Decorator interface for the board and rack
 * @author Zach
 *
 */
public interface IDrawLayer {

	/**
	 * Draws the decorator
	 * @param g2D Graphics object
	 */
	void draw(Graphics2D g2D);
	
	/**
	 * 
	 * @return A description of the decorator
	 */
	String getDescription();
}

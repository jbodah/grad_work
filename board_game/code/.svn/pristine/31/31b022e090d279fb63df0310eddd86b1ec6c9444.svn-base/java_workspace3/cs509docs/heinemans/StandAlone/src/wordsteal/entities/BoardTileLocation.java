package wordsteal.entities;

/**
 * Class representing a location on the board. Not to be confused with
 * BoardLocation, this class is used for undo/redo and refers to a cell.
 * @author Zach
 *
 */
public class BoardTileLocation implements ITileLocation {

	/** The cell this location represents */
	Cell cell;
	
	/**
	 * Constructor
	 * @param cell Cell this location represents
	 */
	public BoardTileLocation(Cell cell) {
		
		this.cell = cell;
	}
	
	@Override
	public void addTile(Tile tile) {
		
		this.cell.setTile(tile);
	}

	@Override
	public Tile removeTile() {
		
		Tile tile = this.cell.getTile();
		this.cell.setTile(null);
		return tile;
	}

}

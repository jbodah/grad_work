package wordsteal.controllers;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import wordsteal.entities.Board;
import wordsteal.entities.BoardTileLocation;
import wordsteal.entities.Cell;
import wordsteal.entities.CellColor;
import wordsteal.entities.Game;
import wordsteal.entities.ITileLocation;
import wordsteal.entities.Rack;
import wordsteal.entities.RackTileLocation;
import wordsteal.entities.Tile;
import wordsteal.entities.TileMovement;
import wordsteal.interfaces.IWordstealApp;
import wordsteal.util.BoardLocation;


/**
 * Persistent controller providing keyboard-only access to the game. Traps
 * all key events to the BoardRackPanel.
 * @author zbrod
 *
 */
public class AccessibilityController implements KeyListener, FocusListener {

	/** Handle to main application object */
	IWordstealApp app;
	
	/** Flag determining if the currently highlighted tile is "grabbed" */
	boolean isHighlightedGrabbed = false;
	
	/**
	 * Constructor
	 * @param mf Handle to the main application object
	 */
	public AccessibilityController(IWordstealApp mf) {
		this.app = mf;
	}
	
	/**
	 * Called when player performs another action while the the current
	 * tile has not been "dropped". This forces it to be dropped first
	 */
	public void forceDropTile() {
		
		if(this.isHighlightedGrabbed) {
			
			handleGrabOrReleaseTile();
		}
	}
	
	/**
	 * Called when user presses the space bar or tile if force-dropped
	 */
	private void handleGrabOrReleaseTile() {
		
		Game game = this.app.getGame();
		Tile tile = game.getHighlightedTile();
		
		if(this.isHighlightedGrabbed) {
			
			ITileLocation srcLocation = game.getGrabbedTileSrcLocation();
			ITileLocation destLocation;
			game.setGrabbedTileSrcLocation(null);
			
			if(game.getRack().getTiles().contains(tile)) {
				
				destLocation = new RackTileLocation(
						game.getRack().getTiles().indexOf(tile),
						game.getRack());
			} else {
				
				destLocation = new BoardTileLocation(
						game.getBoard().getCellFromTile(tile));
			}
			
			game.getUndoManager().pushMovement(
					new TileMovement(srcLocation, destLocation));

		} else {
			
			if(game.getRack().getTiles().contains(tile)) {
				
				game.setGrabbedTileSrcLocation(
						new RackTileLocation(
								game.getRack().getTiles().indexOf(tile),
								game.getRack()));
			} else {
				
				game.setGrabbedTileSrcLocation(
						new BoardTileLocation(
								game.getBoard().getCellFromTile(tile)));
			}
		}
		
		// Toggle whether or not the tile is grabbed
		this.isHighlightedGrabbed = !this.isHighlightedGrabbed;
		
	}
	
	@Override
	public void keyPressed(KeyEvent ke) {
		
		// First make sure that there is no tile already grabbed
		if(this.app.getGame() != null && 
				this.app.getGame().getGrabbedTile() == null) {
		
			// The space bar is used to grab and release a tile
			if(ke.getKeyCode() == KeyEvent.VK_SPACE) {
				
				handleGrabOrReleaseTile();
			}
			else if(ke.getKeyCode() == KeyEvent.VK_UP) {
				
				Rack rack = this.app.getGame().getRack();
				Board board = this.app.getGame().getBoard();
				Tile tile = this.app.getGame().getHighlightedTile();
				Cell srcCell;
				
				// If the tile is on the rack, and the user presses the up key...
				if(rack.getTiles().contains(tile)) {
					
					// ...we want to search the board above. To do this, we create
					// a fake cell below the board, in the middle, and search
					// from there.
					srcCell = new Cell(new BoardLocation(Board.boardStructure.length, Board.boardStructure.length/2), CellColor.White);
					srcCell.setTile(tile);
					
					// If the tile is grabbed, we will be removing it from the rack
					if(this.isHighlightedGrabbed) {
						rack.removeTile(tile);
					}
					
				} else {
					// If the tile is on the board, we find the cell the tile is
					// inside so we can pass it to the search
					srcCell = board.getCellFromTile(tile);
				}
				
				// Search for the next cell on the board in the up direction
				Cell nextCell = board.getNextCell(srcCell,
						Board.UP, !this.isHighlightedGrabbed);
				
				// If it can find one...
				if(nextCell != null) {
					// If this highlighted tile is grabbed, we need to move it
					// from the source cell to the destination
					if(this.isHighlightedGrabbed) {
						
						nextCell.setTile(tile);
						srcCell.setTile(null);
						
					} else {
						// Otherwise, we just want to highlight the destination
						// cell
						this.app.getGame().setHighlightedTile(nextCell.getTile());
						
					}
				}
				
			}
			else if(ke.getKeyCode() == KeyEvent.VK_DOWN) {
				
				Rack rack = this.app.getGame().getRack();
				Board board = this.app.getGame().getBoard();
				Tile tile = this.app.getGame().getHighlightedTile();
				
				// If the tile is on the rack and the user presses down, nothing
				// happens. We only care if it is on the board.
				if(!rack.getTiles().contains(tile)) {
					
					Cell srcCell = board.getCellFromTile(tile);
					Cell nextCell = board.getNextCell(srcCell,
							Board.DOWN, !this.isHighlightedGrabbed);
					
					// If we've found a destination cell on the board
					if(nextCell != null) {
						// If the source tile is grabbed, move it from source
						// cell to dest cell
						if(this.isHighlightedGrabbed) {
							
							nextCell.setTile(tile);
							srcCell.setTile(null);
							
						} else {
							// Otherwise we just highlight the dest tile
							this.app.getGame().setHighlightedTile(nextCell.getTile());
							
						}
					} else {
						// If a dest cell was not found, it means we have run into
						// the rack.
						if(this.isHighlightedGrabbed) {
							// If the tile is grabbed, we move it to the rack
							srcCell.setTile(null);
							rack.addTile(tile);
						} else {
							
							// Otherwise, we highlight the first tile in the rack
							if(rack.getTiles() != null &&
									rack.getTiles().size() > 0 &&
									rack.getTiles().get(0) != null) {
								
								this.app.getGame().setHighlightedTile(rack.getTiles().get(0));
							}
						}
					}
				}
			}
			else if(ke.getKeyCode() == KeyEvent.VK_LEFT) {
				
				Rack rack = this.app.getGame().getRack();
				Board board = this.app.getGame().getBoard();
				Tile tile = this.app.getGame().getHighlightedTile();
				
				// If the tile is on the rack...
				if(rack.getTiles().contains(tile)) {
					
					int tileIndex = rack.getTiles().indexOf(tile);
					
					// If the tile is grabbed, we want to shift its position in
					// the rack
					if(this.isHighlightedGrabbed) {
						
						if(tileIndex > 0) {
							
							rack.getTiles().remove(tile);
							rack.insertTile(tile, tileIndex - 1);
						}
						
					} else {
						// Otherwise, we just want to highlight the next tile
						if(tileIndex > 0) {
							
							this.app.getGame().setHighlightedTile(
									rack.getTiles().get(tileIndex -1));
						}
					}
					
				} else {
					// Otherwise, it is on the board
					Cell srcCell = board.getCellFromTile(tile);
					Cell nextCell = board.getNextCell(srcCell,
							Board.LEFT, !this.isHighlightedGrabbed);
					
					if(nextCell != null) {
						// If the tile is grabbed, we want to move it to the
						// destination cell.
						if(this.isHighlightedGrabbed) {
							
							nextCell.setTile(tile);
							srcCell.setTile(null);
							
						} else {
							// Otherwise, just highlight the cell
							this.app.getGame().setHighlightedTile(nextCell.getTile());
							
						}
					}
				}
				
				
			}
			else if(ke.getKeyCode() == KeyEvent.VK_RIGHT) {
				
				Rack rack = this.app.getGame().getRack();
				Board board = this.app.getGame().getBoard();
				Tile tile = this.app.getGame().getHighlightedTile();
				
				if(rack.getTiles().contains(tile)) {
					
					int tileIndex = rack.getTiles().indexOf(tile);
					
					if(this.isHighlightedGrabbed) {
						
						if(tileIndex < rack.getTiles().size() - 1) {
							
							rack.getTiles().remove(tile);
							rack.insertTile(tile, tileIndex + 1);
						}
						
					} else {
						
						if(tileIndex < rack.getTiles().size() - 1) {
							
							this.app.getGame().setHighlightedTile(
									rack.getTiles().get(tileIndex + 1));
						}
					}
					
				} else {
					
					Cell srcCell = board.getCellFromTile(tile);
					Cell nextCell = board.getNextCell(srcCell,
							Board.RIGHT, !this.isHighlightedGrabbed);
					
					if(nextCell != null) {
						
						if(this.isHighlightedGrabbed) {
							
							nextCell.setTile(tile);
							srcCell.setTile(null);
							
						} else {
							
							this.app.getGame().setHighlightedTile(nextCell.getTile());
							
						}
					}
				}
			}
			
			// Make sure to refresh
			this.app.repaintBoardAndRack();
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void focusGained(FocusEvent e) {
		
		Game game = this.app.getGame();
		
		if(game != null) {
			
			if(game.getRack().getTiles() != null &&
					game.getRack().getTiles().size() > 0 &&
					game.getRack().getTiles().get(0) != null) {
				this.app.getGame().setHighlightedTile(game.getRack().getTiles().get(0));
				
			} else {
				Cell srcCell = new Cell(new BoardLocation(0, -1), CellColor.White);
				Cell nextCell = this.app.getGame().getBoard().getNextCell(srcCell,
						Board.RIGHT, true);
				
				if(nextCell != null) {
					
					this.app.getGame().setHighlightedTile(nextCell.getTile());
				}
			}
			
			this.app.repaintBoardAndRack();
		} 
		
	}

	@Override
	public void focusLost(FocusEvent e) {

		Game game = this.app.getGame();
		
		if(game != null) {
			this.app.getGame().setHighlightedTile(null);
			this.app.repaintBoardAndRack();
		}
		
	}

}

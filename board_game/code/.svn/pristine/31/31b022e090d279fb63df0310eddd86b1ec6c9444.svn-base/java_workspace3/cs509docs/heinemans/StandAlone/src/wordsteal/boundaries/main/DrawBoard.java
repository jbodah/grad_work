package wordsteal.boundaries.main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 * Decorator that draws the board object
 * @author Zach
 *
 */
public class DrawBoard extends DrawLayerBase {

	public DrawBoard(IDrawLayer next, BoardRackPanel brp) {
		super(next, brp);
		
	}

	@Override
	public void draw(Graphics2D g2D) {
		g2D.setStroke(new BasicStroke());
				
		// Draw border (debug)
		g2D.setColor(Color.BLACK);
		g2D.draw(BoardRackPanel.getBoardRect());
		
		for(int r = 0; r < BoardRackPanel.numBoardCells; r++) {
			for(int c = 0; c < BoardRackPanel.numBoardCells; c++) {
				
				Rectangle rect = BoardRackPanel.getBoardCellRect(r, c);
				
				Color color = Color.WHITE;
				
				switch(BoardRackPanel.boardStructure[r][c]) {
					case 0: color = Color.WHITE; break;
					case 1: color = Color.GREEN; break;
					case 2: color = Color.PINK; break;
					case 3: color = Color.ORANGE; break;
				}
				
				g2D.setColor(color);
				g2D.fill(rect);
				
				g2D.setColor(Color.BLACK);
				g2D.draw(rect);
			}
		}
		
		next(g2D);
	}

	@Override
	public String getDescription() {
		
		if(this.nextLayer != null) {
			return this.nextLayer.getDescription() + ", " + this.getClass().getName();
		} else {
			return this.getClass().getName();
		}
	}
	
	

}

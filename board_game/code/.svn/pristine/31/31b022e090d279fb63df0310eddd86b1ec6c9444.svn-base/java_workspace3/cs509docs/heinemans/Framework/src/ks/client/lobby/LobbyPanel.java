package ks.client.lobby;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.GroupLayout;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JScrollPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import ks.client.controllers.ProcessLobbyInputController;
import ks.client.interfaces.ILobby;
import ks.client.interfaces.IProcessLobbyInput;

/**
 * Inner GUI element that holds the primary graphical entities on the 
 * client side.
 * <p>
 * The intent is for user manager and table managers to be "dropped in" for
 * separation of implementation. This class takes advantage of the GroupLayout
 * layout manager for ease of design.
 * 
 * Significant TextPane adjustments as recommended by Alec Mitnik
 * 
 * @author George Heineman
 */
public class LobbyPanel extends JPanel {

	// keep eclipse happy. 
	private static final long serialVersionUID = 1L;
	
	private JTextField lobbyInput = null;
	private JPanel userManagerGUI = null;
	private JPanel  tableManagerGUI = null;
	private JScrollPane tblScrollPanel = null;
	private JScrollPane userScrollPanel = null;
	private JScrollPane lobbyScrollbarPanel = null;
	private JTextPane lobbyOutput = null;
	
	/** Lobby in which we are enclosed. */
	ILobby lobby;

	/** Default lobby controller (Can be overridden as needed). */
	IProcessLobbyInput defaultLobbyController;
	
	/**
	 * This is the default constructor
	 */
	public LobbyPanel(ILobby lobby) {
		super();
		
		this.lobby = lobby;
		initialize();
		
		// set default lobby controller to use
		defaultLobbyController = new ProcessLobbyInputController(lobby);
	}


	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(850, 710);
		
		// new GroupLayout idiom in place.
		GroupLayout layout = new GroupLayout(this);
		this.setLayout(layout);
		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);

		getTblScrollPanel();
		getUserScrollPanel();
		getLobbyScrollbarPanel();
		getLobbyInput();
		
		// deal here
		layout.setVerticalGroup(layout.createSequentialGroup()
			    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
			    	.addGroup(layout.createSequentialGroup()
			    		.addComponent(getTblScrollPanel())
			    		.addComponent(getLobbyScrollbarPanel())
			    		.addComponent(getLobbyInput()))
			    	.addComponent(getUserScrollPanel()))
			    	);
		
		layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(getTblScrollPanel())
						.addComponent(getLobbyScrollbarPanel())
						.addComponent(getLobbyInput()))
					.addComponent(getUserScrollPanel()))
					);
							
	}

	/** Set alternative lobby controller to use and return old one. */
	public IProcessLobbyInput setLobbyInputController (IProcessLobbyInput ipl) {
		IProcessLobbyInput old = defaultLobbyController;
		defaultLobbyController = ipl;
		
		return old;
	}
	
	/**
	 * return the user manager GUI	
	 */
	JPanel getUserManagerGUI() {
		return userManagerGUI;
	}

	/**
	 * return the table manager GUI
	 */
	JPanel getTableManagerGUI() {
		return tableManagerGUI;
	}

	/**
	 * This method initializes tblScrollPanel	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	public JScrollPane getTblScrollPanel() {
		if (tblScrollPanel == null) {
			tblScrollPanel = new JScrollPane();
			// tblScrollPanel.setBounds(0, 0, 496, 428);
			tblScrollPanel.getVerticalScrollBar().setUnitIncrement(10);
			tblScrollPanel.setMinimumSize(new Dimension(496, 88));
			tblScrollPanel.setMaximumSize(new Dimension(496, 428));
			tblScrollPanel.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		}
		return tblScrollPanel;
	}

	/**
	 * This method initializes userScrollPanel	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	public JScrollPane getUserScrollPanel() {
		if (userScrollPanel == null) {
			userScrollPanel = new JScrollPane();
			//userScrollPanel.setBounds(new Rectangle(603, 73, 350, 635));
			userScrollPanel.setMinimumSize(new Dimension(350, 88));
			//userScrollPanel.setMaximumSize(new Dimension(350, 428));
			//userScrollPanel.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
			//userScrollPanel.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		}
		return userScrollPanel;
	}

	/**
	 * This method initializes lobbyScrollbarPanel	
	 * 	
	 * @return javax.swing.JScrollPane	
	 */
	public JScrollPane getLobbyScrollbarPanel() {
		if (lobbyScrollbarPanel == null) {
			lobbyScrollbarPanel = new JScrollPane();
			//lobbyScrollbarPanel.setBounds(new Rectangle(11, 419, 581, 226));
			lobbyScrollbarPanel.setMaximumSize(new Dimension(496, 1000));
			//lobbyScrollbarPanel.setMinimumSize(new Dimension(496, 130));
			//lobbyScrollbarPanel.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			lobbyScrollbarPanel.setViewportView(getLobbyOutput());
			lobbyScrollbarPanel.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		}
		return lobbyScrollbarPanel;
	}

	/**
	 * This method initializes lobbyOutput	
	 * 	
	 * @return javax.swing.JTextPane	
	 */
	public JTextPane getLobbyOutput() {
		if (lobbyOutput == null) {
			lobbyOutput = new JTextPane();
			lobbyOutput.setMaximumSize(new Dimension(496, 5));
			
			// not writable directly by user.
			lobbyOutput.setEditable(false);
		}
		return lobbyOutput;
	}
	
	/**
	 * This method initializes lobbyOutput	
	 * 	
	 * @return javax.swing.JTextPane	
	 */
	public JTextField getLobbyInput() {
		if (lobbyInput == null) {
			lobbyInput = new JTextField(80);
			lobbyInput.setMaximumSize(new Dimension(496,24));
			
			lobbyInput.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent e) {
					String s = lobbyInput.getText();
					lobbyInput.setText("");

					defaultLobbyController.process(s);
					
					// REQUEST to access special controller instead of mine.
					// hand off to the newly constructed controller to process 
					// new ProcessLobbyInputController(lobby).process(s);

				}
				
			});
		}
		return lobbyInput;
	}
	
	/**
	 * Insert a new announcement into the lobby chat
	 * 
	 * @param s
	 */
	public void append(String s) {
		Style style = lobbyOutput.addStyle("Bold Italic", null);
		StyleConstants.setItalic(style, true);
		
		StyledDocument doc = lobbyOutput.getStyledDocument();
		
		try {
			doc.insertString(doc.getLength(), s + "\r\n", style);
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		StyleConstants.setItalic(style, false);
		
		scrollToEnd();		
	}

	/**
	 * Insert a new message into the lobby chat 
	 * 
	 * @param speaker
	 * @param s
	 */
	public void append(String speaker, String s, boolean publicMessage) { // CHANGED!
		Style style = lobbyOutput.addStyle("Bold Italic Red Blue Purple", null); // CHANGED!
		StyleConstants.setBold(style, true);
		
		Color defaultTextColor = StyleConstants.getForeground(style);
		if (lobby.getContext().getUser().equals(speaker)) {
			if (publicMessage) {									// CHANGED!...
				StyleConstants.setForeground(style, Color.RED);
			}
			else {
				StyleConstants.setItalic(style, true);
				StyleConstants.setForeground(style, new Color(128, 0, 255));
			}
		}
		else if (!publicMessage) {
			StyleConstants.setItalic(style, true);
			StyleConstants.setForeground(style, Color.BLUE);
		}															// ...CHANGED!
		
		StyledDocument doc = lobbyOutput.getStyledDocument();
		
		try {
			doc.insertString(doc.getLength(), speaker + ": ", style);
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		StyleConstants.setForeground(style, defaultTextColor);
		
		StyleConstants.setBold(style, false);
		try {
			doc.insertString(doc.getLength(), s + "\r\n", style);
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		StyleConstants.setItalic(style, false);
		
		scrollToEnd();		
	}
	
	/**
	 * Make sure we can scroll to the end on demand.
	 */
	void scrollToEnd() {
		lobbyOutput.setCaretPosition(lobbyOutput.getDocument().getLength());
	}

	/**
	 * Drop this one in.
	 * 
	 * @param tableManagerGUI
	 */
	public void setTableManagerGUI(JPanel tg) {
		tableManagerGUI = tg;
		tblScrollPanel.setViewportView(tg);
	}


	/**
	 * Drop this one in.
	 * 
	 * @param userManagerGUI
	 */
	public void setUserManagerGUI(JPanel ug) {
		userManagerGUI = ug;
		userScrollPanel.setViewportView(ug);
	}


}  //  @jve:decl-index=0:visual-constraint="10,10"

package wordsteal.entities;

public enum CellColor {

	White,
	Green,
	Pink,
	Orange
}

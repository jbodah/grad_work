package wordsteal.boundaries.main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 * Decorator that draws the tile currently grabbed by the player
 * @author Zach
 *
 */
public class DrawGrabbedTile extends DrawLayerBase {

	public DrawGrabbedTile(IDrawLayer next, BoardRackPanel brp) {
		super(next, brp);
	}

	@Override
	public void draw(Graphics2D g2D) {
		
		if(this.brp.getMainFrame().getGame() != null &&
		   this.brp.getMainFrame().getGame().getGrabbedTile() != null) {
			
			int x = this.brp.getMainFrame().getGame().getGrabbedTileX();
			int y = this.brp.getMainFrame().getGame().getGrabbedTileY();
			
			g2D.setStroke(new BasicStroke());
			
			if(this.brp.isWithinBoard(x, y)) {
			
				Rectangle rect = new Rectangle(
						x - BoardRackPanel.boardCellLength / 2,
						y - BoardRackPanel.boardCellLength / 2,
						BoardRackPanel.boardCellLength,
						BoardRackPanel.boardCellLength);
				
				g2D.setColor(Color.WHITE);
				g2D.fill(rect);
				
				if(this.brp.getMainFrame().getGame().getGrabbedTile().equals(
				   this.brp.getMainFrame().getGame().getHighlightedTile())) {
					g2D.setColor(Color.RED);
				} else {
					g2D.setColor(Color.BLACK);
				}
				g2D.draw(rect);
	
				g2D.setFont(new Font("Monospaced", Font.BOLD, BoardRackPanel.boardTileFontSize));
				g2D.drawString(this.brp.getMainFrame().getGame().getGrabbedTile().letter,
						x - BoardRackPanel.boardCellLength / 2 +
							BoardRackPanel.boardTileLetterXOffset,
						y - BoardRackPanel.boardCellLength / 2 +
							BoardRackPanel.boardTileLetterYOffset);
				
			} else {
				Rectangle rect = new Rectangle(
						x - BoardRackPanel.rackTileLength / 2,
						y - BoardRackPanel.rackTileLength / 2,
						BoardRackPanel.rackTileLength,
						BoardRackPanel.rackTileLength);
				
				g2D.setColor(Color.WHITE);
				g2D.fill(rect);
				
				if(this.brp.getMainFrame().getGame().getGrabbedTile().equals(
						   this.brp.getMainFrame().getGame().getHighlightedTile())) {
							g2D.setColor(Color.RED);
				} else {
					g2D.setColor(Color.BLACK);
				}
				g2D.draw(rect);
	
				g2D.setFont(new Font("Monospaced", Font.BOLD, BoardRackPanel.rackTileFontSize));
				g2D.drawString(this.brp.getMainFrame().getGame().getGrabbedTile().letter,
						x - BoardRackPanel.rackTileLength / 2 +
							BoardRackPanel.rackTileLetterXOffset,
						y - BoardRackPanel.rackTileLength / 2 +
							BoardRackPanel.rackTileLetterYOffset);
			}

		}
		
		next(g2D);
	}

	@Override
	public String getDescription() {
		if(this.nextLayer != null) {
			return this.nextLayer.getDescription() + ", " + this.getClass().getName();
		} else {
			return this.getClass().getName();
		}
	}

}

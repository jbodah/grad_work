package ks;

import java.util.ArrayList;

import arch.ServerExtension;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.framework.interfaces.IClientProcessor;

/**
 * A LocalClientProcessor is used during testing to construct a queue of messages
 * being delivered back from the server to the client.
 * <p>
 * Using this instantiation of a {@link IClientProcessor} it becomes possible 
 * to test a wide variety of client-side behaviors.
 * 
 * @author George Heineman
 */
public class LocalServerProcessor extends ServerExtension {

	public LocalServerProcessor() {
		
	}
	
	/** Store all messages in queue to be inspected, retrieved. */
	ArrayList<Message> queue = new ArrayList<Message>(); 
	
	@Override
	public boolean process(Communicator com, Message m) {
		synchronized (queue) {
			queue.add(m);
		}
		
		return true;
	}

	/** retrieve the next message to be processed. */
	public Message dequeue() {
		Message m;
		
		synchronized (queue) {
			m = queue.remove(0);
		}
		
		return m;
	}

	/** Determine whether a message is waiting. */
	public boolean hasMessage() {
		
		synchronized (queue) {
			return !queue.isEmpty();
		}
		
	}

}

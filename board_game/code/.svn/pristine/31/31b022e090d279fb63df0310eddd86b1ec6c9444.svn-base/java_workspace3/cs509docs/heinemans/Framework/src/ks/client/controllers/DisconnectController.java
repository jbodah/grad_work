package ks.client.controllers;

import ks.client.UserContext;
import ks.client.interfaces.ILobby;
import ks.client.ipc.Client;

/**
 * Deal with requests to disconnect.
 * 
 * This is an internal controller used by the KS framework code and that is why
 * it doesn't implement {@link IProcessClientMessage}. You will not need to modify this
 * class.
 * 
 * @author George Heineman 
 */
public class DisconnectController {
	/** Lobby to be managed. */
	ILobby lobby;
	
	/** 
	 * Connection controller needs to know the Lobby to manage its functionality.
	 * 
	 * @param room
	 */
	public DisconnectController (ILobby lobby) {
		this.lobby = lobby;
	}

	public boolean process(UserContext context) {
		Client client = context.getClient();
		client.disconnect();
		
		// Write to syserr because Lobby may be closing down...
		System.err.println ("Disconnecting from:" + context.getHost());
		return true;
	}

}

package puzzler.controller;

import javax.swing.JOptionPane;
import puzzler.PuzzlerApplication;

/**
 * Exit Application, as approved by user.
 * 
 * @author George Heineman
 */
public class ExitApplicationController {

	/** Controller will need app to manage it properly. */
	PuzzlerApplication app;


	/** Construct puzzle controller with application in mind. */
	public ExitApplicationController(PuzzlerApplication pa) {
		this.app = pa;

	}

	/**
	 * Load up a puzzle.
	 */
	public void process() {

		// Alert user
		int rc = JOptionPane.showConfirmDialog(app, "Exit Puzzler Application?", "Exit PuzzlerApplication", JOptionPane.YES_NO_OPTION);
		if (rc == JOptionPane.OK_OPTION) {
			app.setVisible(false);
			app.dispose();
		}
		
	}

}

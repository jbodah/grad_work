package ks.client.controllers;

import org.w3c.dom.Document;

import arch.ServerExtension;


import junit.framework.TestCase;
import ks.LocalClientProcessor;
import ks.client.UserContext;
import ks.client.controllers.ConnectController;
import ks.client.controllers.DisconnectController;
import ks.client.lobby.LobbyFrame;
import ks.framework.common.Configure;
import ks.framework.common.Message;
import ks.framework.communicator.SampleOutput;
import ks.server.controllers.ServerControllerChain;
import ks.server.ipc.Server;
import ks.server.processor.ServerProcessor;

/**
 * 
 */
public class TestProcessLobbyInputController extends TestCase {

	// host
	public static final String localhost = "localhost";
	
	// sample credentials
	public static final String user = "11324";
	public static final String password = "password";
	
	/** Constructed objects for this test case. */
	Server server;
	UserContext context;
	LobbyFrame lobby;
	LocalClientProcessor lcp;
	
	// random port 8000-10000 to avoid arbitrary conflicts
	int port;
	
	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			assertTrue (Configure.configure());
			
			// validate a simple tables
			String s = Message.requestHeader() + "<tables/></request>";
			Document d = Message.construct(s);
			assertTrue (d != null);
			
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
		
		port = (int) (8000 + Math.random()*2000);
		server = new Server(port);
		
		// Now that CHAT is not standard, we have to add in its controller
		// for processing.
		ServerControllerChain head = ServerProcessor.head();
		head.append(new ServerExtension());
		
		assertTrue (server.activate());
		
		waitASecond();
		
		// create client to connect
		context = new UserContext();  // by default, localhost
		lobby = new LobbyFrame (context);
		lobby.setVisible(true);
		
		context.setPort(port);
		context.setUser(user);
		context.setPassword(password);
		context.setSelfRegister(false);
		
		assertTrue (new ConnectController(lobby).process(context));
		
		waitASecond();
		
		// now 'hook' in a new processor to validate messages are being
		// properly received here.
		lcp = new LocalClientProcessor(lobby);
		context.getClient().setProcessor(lcp);
	}

	@Override
	protected void tearDown() {
		// the other way to leave is to manually invoke controller.
		assertTrue (new DisconnectController (lobby).process(context));
		
		waitASecond();
		server.deactivate();
		
		lobby.setVisible(false);
		lobby.dispose();
	}
	
	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	// Note that all test cases now can focus on the sending of a message
	// and the proper receipt of actual request(s) from the server. 
	// Still doesn't handle broadcast well, however.
	public void testClient() {

		// another "client" connected to the same server
		SampleOutput sample = new SampleOutput();
		server.connectUser("1133", sample);
		
		// validate that lobby input is working as expected
		ProcessLobbyInputController plic = new ProcessLobbyInputController(lobby);
		
		// try to send chat message.
		plic.process("Hey there");
		
		waitASecond();
		
		// WE should have no message because chat doesn't come back to owner
		assertFalse (lcp.hasMessage());
		
		// however user 1133 should have seen it
		boolean hasObj = sample.hasObject();
		assertTrue (hasObj);
		Message m = (Message) sample.readObject();
		assertEquals ("output", m.getName());
	}	
	
	

}

Pyramid:

  "As good a way as any of passing eternity in an Egyptian burial chamber..."
  
  Deal twenty-eight cards face up in the form of a pyramid, with one at the apex
  and seven in the bottom row. Cards can be removed in pairs if they total 
  thirteen. Kings can be removed as and when they are located.
  
  A card can be removed from the pyramid if it is not covered by another card.
  A card can be removed from the discard pile if it is the top card. The card
  in the "just drawn" pile can be removed at any time.
  
  To remove a card, press with the left mouse button to select it. If you try
  to select a King, it will be removed. Once one card is selected, click on the
  partner card whose total makes thirteen. If you have selected a valid move,
  then both cards are removed. If no move is possible, click on the deck to 
  move the "just drawn" card to the discard column and then the new card from 
  the deck replaces it. There is no redeal.   
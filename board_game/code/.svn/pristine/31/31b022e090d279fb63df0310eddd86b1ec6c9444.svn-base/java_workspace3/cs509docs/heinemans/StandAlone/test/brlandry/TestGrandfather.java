package brlandry;

import java.awt.event.MouseEvent;

import brlandry.ColumnToColumnMove;
import brlandry.GrandfatherClock;

import ks.client.gamefactory.GameWindow;
import ks.common.model.Card;
import ks.common.model.Deck;
import ks.launcher.Main;
import ks.tests.KSTestCase;

public class TestGrandfather extends KSTestCase {
	// this is the game under test.
	GrandfatherClock game;
	
	// window for game.
	GameWindow gw;
	
	protected void setUp() {
		game = new GrandfatherClock();
		
		// Because solitaire variations are expected to run within a container, we need to 
		// do this, even though the Container will never be made visible. Note that here
		// we select the "random seed" by which the deck will be shuffled. We use the 
		// special constant Deck.OrderBySuit (-2) which orders the deck from Ace of clubs
		// right to King of spades.
		gw = Main.generateWindow(game, Deck.OrderBySuit); 
		
	}
	
	// clean up properly
	protected void tearDown() {
		gw.setVisible(false);
		gw.dispose();
	}
	
	public void testMove() {
		assertEquals (new Card (Card.THREE, Card.CLUBS), game.columns[5].peek());
		
		// HACK. get to the bottom.
		MouseEvent pr = createPressed (game, game.cv[5], 0, 90);
		game.cv[5].getMouseManager().handleMouseEvent(pr);
		
		// Now drag card from col5 to col4
		MouseEvent rel = createReleased(game, game.cv[4], 0, 0);
		game.cv[4].getMouseManager().handleMouseEvent(rel);
		
		assertEquals (new Card (Card.THREE, Card.CLUBS), game.columns[4].peek());
		assertEquals (new Card (Card.ACE, Card.DIAMONDS), game.columns[5].peek());
	}
	
	public void testDblClickToMove() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());
		
		// HACK. get to the bottom.
		MouseEvent dbl = createDoubleClicked(game, game.cv[7], 0, 90);
		game.cv[7].getMouseManager().handleMouseEvent(dbl);
		
		// old one updated
		assertEquals (new Card (Card.JACK, Card.CLUBS), game.columns[7].peek());
		
		// ace placed on pileView
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.piles[4].peek());
	}
	
	public void testMoveManually() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());
		
		// HACK. get to the bottom.
		MouseEvent dbl = createPressed(game, game.cv[7], 0, 90);
		game.cv[7].getMouseManager().handleMouseEvent(dbl);
		
		// Now drag card from col5 to col4
		MouseEvent rel = createReleased(game, game.pv[4], 0, 0);
		game.pv[4].getMouseManager().handleMouseEvent(rel);
		
		// old one updated
		assertEquals (new Card (Card.JACK, Card.CLUBS), game.columns[7].peek());
		
		// ace placed on pileView
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.piles[4].peek());
	}
	
	public void testEmptyColumnMove() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());
		
		// HACK. clear out an entire column
		game.columns[6].removeAll();
		
		// HACK. get to the bottom.
		MouseEvent dbl = createPressed(game, game.cv[7], 0, 90);
		game.cv[7].getMouseManager().handleMouseEvent(dbl);
		
		// Now drag card from col5 to col4
		MouseEvent rel = createReleased(game, game.cv[6], 0, 0);
		game.cv[6].getMouseManager().handleMouseEvent(rel);
		
		// old one updated
		assertEquals (new Card (Card.JACK, Card.CLUBS), game.columns[7].peek());
		
		// ace placed on pileView
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[6].peek());
	}
	
	public void testColumnMove() {
		
		ColumnToColumnMove ccm = new ColumnToColumnMove( game.columns[5], null, game.columns[4]);
		assertTrue (ccm.valid(game));
		
		assertTrue (ccm.doMove(game));
		assertTrue (ccm.undo(game));
		
		
		// always invalid from empty column
		game.columns[5].removeAll();
		assertFalse (ccm.valid(game));
		
		// any move valid to an empty column
		ccm = new ColumnToColumnMove( game.columns[7], null, game.columns[5]);
		assertTrue (ccm.valid(game));
		
		// place King on ACE
		game.columns[4].removeAll();
		game.columns[5].removeAll();
		
		game.columns[4].add(new Card(Card.KING, Card.DIAMONDS));
		game.columns[5].add(new Card(Card.ACE, Card.DIAMONDS));
		
		ccm = new ColumnToColumnMove (game.columns[4], null, game.columns[5]);
		assertTrue (ccm.valid(game));
		assertTrue (ccm.doMove(game));
		assertTrue (ccm.undo(game));
	}
	
}

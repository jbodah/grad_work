package ks.client.game;

import heineman.Klondike;

import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import junit.framework.TestCase;
import ks.client.game.Factory;
import ks.client.game.GameInformation;
import ks.client.game.GameManager;
import ks.client.game.solitaire.SolitaireGameInformation;
import ks.client.gamefactory.PlayerJPanel;
import ks.client.interfaces.IGameInterface;
import ks.common.games.Solitaire;
import ks.common.view.Widget;

/**
 * Placed in this package to access 'package private' information
 * in SolitaireInformation.
 * 
 * @author George
 *
 */
public class TestSolitaireGameInformation extends TestCase {
	
	Properties props;
	Properties options;
	ArrayList<String> order;
	Properties players;
	
	String me = "982";
	String paul = "1124";
	String unknown = "135";
	
	int tableID = 13;
	
	SampleInterface callback;
	GameManager gm;
	SolitaireGameInformation info;
	PlayerJPanel control;
	
	/** Create Klondike variations. */
	protected void setUp() {
		props  = new Properties();
		String s = "heineman.Klondike";
		props.setProperty("game", s);
		
		options = new Properties();
		options.setProperty("undo", "true");
		options.setProperty("newHand", "true");
		options.setProperty("time", "4");    // brief game
		
		GameInformation game = Factory.create(props, options);

		players = new Properties();
		players.setProperty(me, "George Heineman");
		players.setProperty(paul, "Paul Simon");
		players.setProperty(unknown, "");

		// forgot that Properties has no guaranteed ordering.
		order = new ArrayList<String>();
		order.add(me);
		order.add(paul);
		order.add(unknown);

		game.setPlayers(order, players);
		
		callback = new SampleInterface();
		
		gm = GameManager.instance();
		assertTrue(gm.createGameWindow(tableID, me, props, options, order, players, callback));
		
		info = ((SolitaireGameInformation)gm.frame.info);
		control = info.getPlayerRanking();
	}
	
	protected void tearDown() {
		gm.frame.setVisible(false);
		gm.frame.dispose();
	}
	
	public void testBasis() {
		// start of game, all points are ZERO in Klondike
		assertEquals (0, control.getPlayerPoints(info.fullName(me)));
		assertEquals (0, control.getPlayerPoints(info.fullName(paul)));
		
		// now make an update assertion.
		Properties us = new Properties();
		us.setProperty(me, "36");
		us.setProperty(paul, "23");
		us.setProperty(unknown, "0");
		
		// Note that Paul has the most number of wins and this 
		// means he is in the lead, even though he doesn't have the
		// most accumulated total points. A bit contrived.
		Properties ug = new Properties();
		ug.setProperty(me, "numWins=0,numNewHands=5");
		ug.setProperty(paul, "numWins=2,numNewHands=0");
		ug.setProperty(unknown, "numWins=0,numNewHands=0");
		
		assertTrue (info.updateScores(us, ug));
			
		// note we need to use fullName when speaking to the control
		assertEquals (2, control.getPlayerHandsWon(info.fullName(paul)));
		assertEquals (0, control.getPlayerHandsWon(info.fullName(me)));
	}

	public void testNopMethods() {
		assertFalse (info.activateTurn(me));
		assertFalse (info.makeTurn(me, "garbage String"));
		assertFalse (info.skipTurn(me));		
	}
	
	public void testPointMethods() {
		// this updates my score (me); invoked directly by 
		// the specific solitaire plugin
		info.updateScore(10);
		assertEquals (10, info.getScore());
		
		info.updateScore(8);
		assertEquals (8, info.getScore());
		
		info.incrementNumWins();  // player wins
		info.updateScore(3);
		assertEquals (11, info.getScore());
		
		// Locks in their partial points
		info.incrementNumNewHands();
		assertEquals (11, info.getScore());
	
	}
	
	public void testLeaving() {
		// start of game, all points are ZERO in Klondike
		assertEquals (0, control.getPlayerPoints(info.fullName(me)));
		assertEquals (0, control.getPlayerPoints(info.fullName(paul)));
		
		// validate players are NOT disabled.
		assertFalse (control.isDisabled(null));
		
		// must cache because requestLeave eliminates info that we use to construct name.
		String fullPaul = info.fullName(paul);
		assertFalse (control.isDisabled(info.fullName(me)));
		assertFalse (control.isDisabled(fullPaul));
		
		assertTrue(info.requestLeave(paul));
		
		assertFalse (control.isDisabled(info.fullName(me)));
		assertTrue (control.isDisabled(fullPaul));
		
	}

	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	/** (dx,dy) are offsets into the widget space. Feel Free to Use as Is. */
	public MouseEvent createDoubleClicked (Solitaire game, Widget view, int dx, int dy) {
		MouseEvent me = new MouseEvent(game.getContainer(), MouseEvent.MOUSE_CLICKED, 
				System.currentTimeMillis(), 0, 
				view.getX()+dx, view.getY()+dy, 2, false);
		return me;
	}
	
	public void testTimer() {
		// this updates my score (me); invoked directly by 
		// the specific solitaire plugin. Forces a callback invocation.
		info.updateScore(10);
		assertEquals (10, info.getScore());
		
		// move the AceSpades up by double clicking on it
		Klondike game = (Klondike) ((SolitaireGameInformation) gm.frame.getGameInformation()).getActiveGame();
		
		for (Enumeration<Widget> en = game.getWidgets(); en.hasMoreElements(); ) {
			Widget w = en.nextElement(); 
			if (w.getName().equals ("BuildablePileView5")) {
				MouseEvent dbl = createDoubleClicked (game, w, 0, 0);
				w.getMouseManager().handleMouseEvent(dbl);
				break;
			}
		}
		
		// wait long enough (5 seconds) for the ticks to become externally processed.
		waitASecond();
		waitASecond();
		waitASecond();
		waitASecond();
		waitASecond();
		
		String s = callback.dequeue();
		assertTrue (callback.isUpdate(s));
		
		info.stop();
	}
	
}

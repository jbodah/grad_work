package gui;


import java.awt.Graphics;
import java.awt.Point;
import java.util.Iterator;

import state.Duck;
import state.GameState;

/**
 * Responsible for drawing ducks on the playing field.
 */
public class DecoratorDucks extends DrawingDecorator {
	
	/** Know the state of the game so we can draw the ducks. */
	private GameState state = null;
	
	/** The drawer to draw ducks. */
	private DuckDrawer drawer = null;
	
	/**
	 * Build Decoration on top of an existing chain (or the concrete one).
	 * 
	 * @param inner    Next decorator in the chain
	 * @param state    The state of the game
	 * @param drawer   The drawer to use when drawing ducks.
	 */
	public DecoratorDucks (DrawingCanvas inner, GameState state, DuckDrawer drawer) {
		super(inner); 
		
		this.state = state;
		this.drawer = drawer;
	}
	
	/** 
	 * Redraw the state.
	 * 
	 * Take care not to update (by mistake) the color in the graphics.
	 * 
	 * @param   Graphics entity into which we are drawn
	 */
	public void drawState(Graphics g) {
		
		java.awt.Color original = g.getColor();
		
		g.setColor (original);
		super.drawState(g);
		
		// we are going to be a "pre drawer" in that we draw our state before we let
		// others do it. This makes sense since ducks should be the lowest.
		for (Iterator<Duck> it = state.getDucks(); it.hasNext(); ) {
			Duck d = it.next();
			if (!d.isAlive()) continue;
			
			Point p = d.getLocation();
			if (drawer != null) {
				drawer.draw(g, p.x, p.y);
			} else {
				g.setColor(java.awt.Color.yellow);
				g.fillRect(p.x, p.y, d.getWidth(), d.getHeight());
			}
		}
		
		// Ok, let other decorators do their work. NOTE: if this had been a "post drawer"
		// decorator, then the gun sights would sometimes be BEHIND the duck, if not careful!
		//g.setColor (original);
		//super.drawState(g);
	}
}

package state;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Aggregates all game state via Facade:
 * 
 *    Knows about Gun
 *    Knows about the ten ducks.
 *    
 * @author George
 *
 */
public class GameState {
	/** The Gun. */
	Gun gun;
	
	/** The ducks. */
	ArrayList<Duck> ducks = new ArrayList<Duck>();
	
	/** Player score. */
	int score;
	
	/** protect outside access to default game state. */
	protected GameState() {
		
	}
	
	/**
	 * Given a gun and a set of ducks, this creates the initial state.
	 * 
	 * @param g        The gun used for the game 
	 * @param dit      The known ducks within an Iterator.
	 */
	public GameState(Gun g, Iterator<Duck> dit) {
		this.gun = g;
		
		while (dit.hasNext()) {
			Duck d = dit.next();
			
			ducks.add(d);
		}
	}
	
	/** Return score. */
	public int getScore() {
		return score;
	}
	
	/** Return gun information. */
	public Gun getGun() {
		return gun;
	}
	
	/** Return duck information. */
	public Iterator<Duck> getDucks() {
		return ducks.iterator();
	}

	/** If any single duck is alive, return TRUE. */
	public boolean stillAlive() {
		for (int i = 0; i < ducks.size(); i++) {
			Duck d = (Duck) ducks.get(i);
			if (d.alive) return true;
		}
		
		return false;
	}

	/**
	 * Increase the score.
	 * @param score
	 */
	public void increaseScore(int score) {
		this.score += score;		
	}
}

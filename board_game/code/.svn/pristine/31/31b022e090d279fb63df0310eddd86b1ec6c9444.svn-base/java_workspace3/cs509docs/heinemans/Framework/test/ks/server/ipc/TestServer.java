package ks.server.ipc;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;


import junit.framework.TestCase;
import ks.LocalClientProcessor;
import ks.client.UserContext;
import ks.client.ipc.Client;
import ks.client.lobby.LobbyFrame;
import ks.framework.common.Configure;
import ks.framework.common.Message;
import ks.framework.communicator.Communicator;

/**
 *
 */
public class TestServer extends TestCase {

	// host
	public static final String localhost = "localhost";
	
	// sample credentials
	public static final String user = "114234";
	public static final String password = "password";
	
	int specialPort;
	
	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
			
			// validate a simple chat
			String s = Message.requestHeader() + "<chat><text>Here is the message</text></chat></request>";
			Document d = Message.construct(s);
			assertTrue (d != null);
			
			// random port
			specialPort = (int)(8000 + Math.random()*1000);
			
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
	}

	
	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	public void testServer() {
		Server s = new Server(specialPort);
		assertTrue (s.activate());
		
		waitASecond();
		
		// create client to connect
		Client c = new Client();
		
		// client must rely on processor
		UserContext context = new UserContext();  // by default, localhost
		LobbyFrame lobby = new LobbyFrame (context);
		LocalClientProcessor lcp = new LocalClientProcessor(lobby);
		c.setProcessor(lcp);
		
		// initiate connection
		c.connect(localhost, specialPort, user, password, false);
		waitASecond();
		
		assertTrue (lcp.isConnected());
		Message m = lcp.dequeue();
		
		// first message is an 'ack' for the login
		System.out.println("received:" + m.contents().getTextContent());
		assertEquals ("loginResponse", m.getName());
		
		// have client send a chat output
		String cmd = Message.requestHeader() + "<chat>";
		String ch = "Testing CHAT";
		cmd += "<text>" + ch + "</text></chat></request>";
		Document d = Message.construct(cmd);
		m = new Message(d);
		c.sendToServer(m);
		
		waitASecond();
		
		// validate chat 'output' received by client.
		Message m2 = lcp.dequeue();
		assertTrue (m2 != null);
		assertEquals ("output", m2.getName());
		
		assertTrue (c.disconnect());
		
		// must wait to enable connection to cleanly close down before we
		// shut off the server. Specifically? LogoutController gets dying
		// client response, and we must have a live server for this to happen.
		// Note the hack. Revel in it!
		waitASecond();
		
		s.deactivate();
	
		lobby.setVisible(false);
		lobby.dispose();
	}	
	
	public void testSelfRegistratingServer() {
		Server s = new Server(specialPort);
		assertTrue (s.activate());
		
		waitASecond();
		
		// create client to connect
		Client c = new Client();
		
		// client must rely on processor
		UserContext context = new UserContext();  // by default, localhost
		LobbyFrame lobby = new LobbyFrame (context);
		LocalClientProcessor lcp = new LocalClientProcessor(lobby);
		c.setProcessor(lcp);
		
		c.connect(localhost, specialPort, user, password, true);
		waitASecond();
		
		assertTrue (lcp.isConnected());
		Message m = lcp.dequeue();
		
		// first message is an 'loginResponse' for the login
		assertEquals ("loginResponse", m.getName());
		
		// get generated user
		Node resp = m.contents();
		NamedNodeMap map = resp.getAttributes();
		Node pNode = map.getNamedItem("player");
		String who = pNode.getNodeValue();
		
		Communicator com = s.getCommunicator();
		assertTrue ("checking user:" + who, com.isOnline(who));
		
		// have client send a chat output
		String cmd = Message.requestHeader() + "<chat>";
		String ch = "Testing CHAT";
		cmd += "<text>" + ch + "</text></chat></request>";
		Document d = Message.construct(cmd);
		m = new Message(d);
		c.sendToServer(m);
		
		waitASecond();
		
		// validate chat 'output' received by client.
		Message m2 = lcp.dequeue();
		assertTrue (m2 != null);
		assertEquals ("output", m2.getName());
		
		// have client LOGOUT
		cmd = Message.requestHeader() + "<logout/></request>";
		d = Message.construct(cmd);
		m = new Message(d);
		c.sendToServer(m);

		// must wait to enable connection to cleanly close down before we
		// shut off the server. Specifically? LogoutController gets dying
		// client response, and we must have a live server for this to happen.
		// Note the hack. Revel in it!
		waitASecond();
		
		assertFalse (com.isOnline(user));
		
		s.deactivate();
	
		lobby.setVisible(false);
		lobby.dispose();

	}	
	
}

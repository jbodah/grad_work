package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import state.GameState;

/**
 * Responsible for drawing player's score on the playing field.
 */
public class DecoratorScore extends DrawingDecorator {
	
	/** Know the state of the game so we can draw the ducks. */
	private GameState state = null;
	
	/** Drawing font for points. */
	Font pointFont = new Font("Arial Bold", Font.BOLD, 20);

	/** Where to draw score. */
	private Point location;
	
	/**
	 * Build Decoration on top of an existing chain (or the concrete one).
	 * 
	 * @param inner     Next decorator in the chain
	 * @param state     The state of the game
	 * @param location  where to draw the points
	 */
	public DecoratorScore (DrawingCanvas inner, GameState state, Point location) {
		super(inner); 
		
		this.state = state;
		this.location = location;
	}
	
	/** 
	 * Redraw the state.
	 * 
	 * Take care not to update (by mistake) the color in the graphics.
	 * 
	 * @param   Graphics entity into which we are drawn
	 */
	public void drawState(Graphics g) {
		
		java.awt.Color original = g.getColor();
		super.drawState(g);
		
		// show player score in lower RIGHT corner.
		g.setColor(Color.yellow);
		g.setFont(pointFont);
		g.drawString("" + state.getScore(), location.x, location.y);

		// Ok, let other decorators do their work. NOTE: if this had been a "post drawer"
		// decorator, then the gun sights would sometimes be BEHIND the duck, if not careful!
		g.setColor (original);
		//super.drawState(g);
	}
}

package wordsteal.boundaries.main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.Iterator;

import wordsteal.entities.Tile;

/**
 * Decorator that draws the tiles residing in the rack
 * @author Zach
 *
 */
public class DrawTilesOnRack extends DrawLayerBase {

	public DrawTilesOnRack(IDrawLayer next, BoardRackPanel brp) {
		super(next, brp);
	}

	@Override
	public void draw(Graphics2D g2D) {
		
		if(this.brp.getMainFrame().getGame() != null) {
			g2D.setStroke(new BasicStroke());
			
			Iterator<Tile> rackIter = this.brp.getMainFrame().getGame().getRack().getTiles().iterator();
			int tileIndex = 0;
			
			while(rackIter.hasNext()) {
				
				Tile tile = rackIter.next();
				
				Rectangle rect = BoardRackPanel.getRackTileRect(tileIndex);
				
				g2D.setColor(Color.WHITE);
				g2D.fill(rect);
				
				if(tile.equals(this.brp.getMainFrame().getGame().getHighlightedTile())) {
					g2D.setColor(Color.RED);
				} else {
					g2D.setColor(Color.BLACK);
				}
				
				g2D.draw(rect);
	
				g2D.setFont(new Font("Monospaced", Font.BOLD, BoardRackPanel.rackTileFontSize));
				g2D.drawString(tile.letter,
						BoardRackPanel.rackPositionX + 
							(tileIndex + 1) * BoardRackPanel.rackSpacing +
							tileIndex * BoardRackPanel.rackTileLength +
							BoardRackPanel.rackTileLetterXOffset,
						BoardRackPanel.rackPositionY + BoardRackPanel.rackSpacing +
							BoardRackPanel.rackTileLetterYOffset);
				
				tileIndex++;
			}
		}
		
		next(g2D);
	}

	@Override
	public String getDescription() {
		
		if(this.nextLayer != null) {
			return this.nextLayer.getDescription() + ", " + this.getClass().getName();
		} else {
			return this.getClass().getName();
		}
	}

}

package ks.client.controllers;

import javax.swing.JMenuBar;
import javax.swing.JPanel;

import ks.client.UserContext;
import ks.client.interfaces.ILobby;

public class SampleLobby implements ILobby {

	UserContext context = new UserContext();
	
	// return empty context (though not null)...
	@Override
	public UserContext getContext() {
		return context;
	}

	@Override
	public void append(String s) {
		// TODO Auto-generated method stub

	}

	@Override
	public JPanel getTableManagerGUI() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPanel getUserManagerGUI() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JMenuBar getJMenuBar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void connected(boolean status) {
		// TODO Auto-generated method stub

	}

}

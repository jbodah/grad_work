package contractChecking;

public class TestUnsafe extends BaseTests {
	public IDuplicate getObject() { 
		return new UnsafeService();
	}
}

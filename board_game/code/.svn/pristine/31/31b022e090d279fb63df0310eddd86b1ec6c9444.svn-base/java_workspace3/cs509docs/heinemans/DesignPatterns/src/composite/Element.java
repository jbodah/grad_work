package composite;

/**
 * An Element is a member of a set (which includes either Numbers or Sets).
 */
public abstract class Element {
	
	/**
	 * Element constructor comment.
	 */
	public Element() {
		
	}
}

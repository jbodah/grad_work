package wordsteal.entities;

/**
 * Entity representing a game tile
 * @author zbrod
 *
 */
public class Tile {

	/** Letter on the tile */
	public final String letter;
	
	/** Player who owns the tile (null if no one owns it) */
	Player owner = null;
	
	/**
	 * Constructor
	 * @param letter Letter to put on the tile
	 */
	public Tile(String letter) {
		
		this.letter = letter;
	}

	/**
	 * 
	 * @return Player who owns the tile (null if no one)
	 */
	public Player getOwner() {
		return owner;
	}

	/**
	 * 
	 * @param owner Player who owns the tile (null if no one)
	 */
	public void setOwner(Player owner) {
		this.owner = owner;
	}
	
	/** Convenient helper method. */
	public String toString() {
		return letter;
	}
}

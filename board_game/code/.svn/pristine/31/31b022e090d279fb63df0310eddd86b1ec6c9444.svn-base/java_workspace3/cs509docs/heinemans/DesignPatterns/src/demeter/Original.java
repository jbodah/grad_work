package demeter;

public class Original {

	public void doWork() {
		// TODO Auto-generated method stub
		
	}

}

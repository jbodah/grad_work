package gui;

import java.awt.Graphics;

/**
 * The abstract base class representing decorators being used
 * as part of the rendering process.
 * 
 * @author heineman
 */
public abstract class DrawingDecorator extends DrawingCanvas {

	
	protected /*@ spec_public */ static long ctr = 0;
	
	/** The next one in the chain. */
	private DrawingCanvas inner;
	
	/**
	 * When constructing a Decorator, you must pass in the next one in the chain.
	 * 
	 * @param inner    The next object along the decorator chain.
	 */
	public DrawingDecorator (DrawingCanvas inner) {
		this.inner = inner;
	}
	
	
	/**
	 * When requested to draw state, just do it.
	 * 
	 * 
	 * @param Graphics object into which decorated state is drawn.
	 */
	/*@
	 
	  also ensures \old(ctr) < ctr;
	 
	 @*/
	public void drawState(Graphics g) {
		ctr++;
		inner.drawState(g);
	}
	
}

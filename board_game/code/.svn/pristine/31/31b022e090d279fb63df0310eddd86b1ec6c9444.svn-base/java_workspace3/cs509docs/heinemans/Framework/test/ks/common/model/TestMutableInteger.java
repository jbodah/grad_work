package ks.common.model;

import junit.framework.TestCase;

public class TestMutableInteger extends TestCase {

	public void testBasic() {
		MutableInteger mi = new MutableInteger(71);
		assertEquals (71, mi.getValue());
		mi.setValue(42);
		assertEquals (42, mi.getValue());
		
		
		// no impact
		mi.setValue(42);
		assertEquals (42, mi.getValue());
	}
	
	
	public void testNamed() {
		MutableInteger mi = new MutableInteger("myName", 33);
		
		// with no name, the name becomes MutableInteger
		assertEquals ("myName", mi.getName());
		assertEquals (33, mi.getValue());
	}
	
	public void testNoNamed() {
		MutableInteger mi = new MutableInteger(null, 55);
		
		// with no name, the name becomes MutableString
		assertTrue (mi.getName().startsWith("MutableInteger"));
		assertEquals (55, mi.getValue());
	}
	
	public void testToString() {
		MutableInteger mi = new MutableInteger("myName", 33);
		assertEquals ("ks.common.model.MutableInteger:myName=33", mi.toString());
	}
	
	public void testMutability() {
		// you can actually change a MI
		MutableInteger mi = new MutableInteger(null, 55);
		
		// with no name, the name becomes MutableString
		assertEquals (55, mi.getValue());
		mi.increment(-3);
		assertEquals (52, mi.getValue());
		mi.increment(3);
		assertEquals (55, mi.getValue());
		
		// nothing
		mi.increment(0);
		assertEquals (55, mi.getValue());
	}
}

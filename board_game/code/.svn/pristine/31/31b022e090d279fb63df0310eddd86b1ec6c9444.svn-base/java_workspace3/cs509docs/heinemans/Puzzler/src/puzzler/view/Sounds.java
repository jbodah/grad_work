package puzzler.view;

import java.applet.AudioClip;
import java.net.URL;

public class Sounds {

	/** Sound file. */
	static AudioClip fitClip = null;
	
	public static void playPieceFit() {
		if (fitClip == null) {
			URL url = Sounds.class.getResource("/sounds/pieceFit.wav");
			fitClip = java.applet.Applet.newAudioClip(url);
		}
		
		fitClip.play();
	}

}

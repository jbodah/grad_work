package wordsteal.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

import wordsteal.interfaces.IWordstealApp;

/**
 * TimerController is launched when a player's turn begins.
 * 
 * The controller counts down the amount of time the player
 * has left to submit a word.
 * 
 * @author Dan
 */
class TimerController implements ActionListener {

	/** Controller has handle to MainFrame */
	IWordstealApp mf;
	
	/** Current timer */
	Timer timer = null;
	
	/** Number of times the timer has fired since last reset */
	int count = 0;

	/** 
	 * Construct controller
	 * @param mainFrame MainFrame allows ability to set and retrieve entity information
	 */
	public TimerController(IWordstealApp mainFrame) {
		this.mf = mainFrame;
	}

	/**
	 * newTimer creates a new timer and if a timer already exists it stops it
	 */
	public void newTimer() {
		if (this.timer != null) {
			timer.stop();
		}
		this.timer = new Timer(1000, this);	    
		timer.setRepeats(true);
		timer.setInitialDelay(0);
		timer.start();
		count = 0;
	}
	
	/**
	 * Used to stop the current timer
	 */
	public void stop() {
		timer.stop();
	}
	
	/**
	 * Used to start the current timer
	 */
	public void start() {
		timer.start();
	}
	
	/**
	 * Used to restart the current timer
	 */
	public void restartTimer() {
		this.count = 0;
	}
	
	/**
	 * Returns the amount of seconds left in the current Player's turn
	 * @return
	 */
	public int getTimeRemaining() {
		return this.mf.getGame().getTimePerTurn() - this.count;		
	}

	/**
	 * actionPerformed is executed when the timer fires, if the max amount of time per turn is exceeded
	 * then the turn is passed to the next player, the number of consecutive skips is incremented
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		count++;
		// Update the timer display on the view
		//this.mf.updateTimer(count);
		
		// Check if time has been exceeded
		if (count >= this.mf.getGame().getTimePerTurn()) {
			// stop timer until restarted.
			stop();
			
			this.mf.skipTurn();
			restartTimer();
		}
		
	}	
}

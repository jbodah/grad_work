package state;

import java.awt.Point;

/**
 * Maintain location of the gun, and its charge state.
 * 
 * Once a gun is fired, its charge is set to zero. The recharging policy is
 * set by the default chargePolicy.
 * 
 * @author George
 */
public class Gun {
	
	/** Known charge (range 0 to 100). */
	private int charge = 100;
	
	/** Where gun is aimed. */
	private Point aim;
	
	/** Default constructor. */
	public Gun () {
		aim = new Point (0,0);        // missing and discovered during JUnit tests.
	}

	
	/**
	 * Set the charge of the gun.
	 * 
	 * restrict access to package
	 * @param ch
	 */
	void setCharge(int ch) {
		if (ch < 0) { ch = 0; }
		if (ch > 100) { ch = 100; }
		
		charge = ch;
	}
	
	/**
	 * Return the current charge in the gun.
	 */
	public int getCharge() {
		return charge;
	}

	/** 
	 * Sights of where the gun is pointed.
	 * 
	 * Note that we copy values to ensure safety of internal data.
	 * 
	 * @param point
	 */
	public void setAim(Point point) {
		aim.x = point.x;
		aim.y = point.y;
	}
	
	/** 
	 * Get sight of where gun is pointed.
	 * 
	 * Note that a copy of the Point is returned, to ensure safety of internal data.
	 * 
	 * @return  a copy of the point that represents the aim of the gun.
	 */
	public Point getAim () {
		return new Point (aim);
	}

	/**
	 * Determines if the gun is fully charged.
	 * @return true if the gun is at 100% capacity; false otherwise.
	 */
	public synchronized boolean isFullyCharged() {
		return charge == 100;
	}

	/** 
	 * Increment gun charge by 10%.
	 */
	public synchronized void increaseCharge() {
		charge += 10;		
	}

	/**
	 * Is the gun sufficiently charged (i.e., greater than 50%)
	 * @return true if the gun is at least 1/2 charged; false otherwise.
	 */
	public synchronized boolean isSufficientlyCharged() {
		return (charge > 50);
	}

	/** 
	 * Discharge the gun (penalty of 1/2 of total charge.
	 */
	public synchronized void discharge() {
		charge -= 50;		
	}
	
}

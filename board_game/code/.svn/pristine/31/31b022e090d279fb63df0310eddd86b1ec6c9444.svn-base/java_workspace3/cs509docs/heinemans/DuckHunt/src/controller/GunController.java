package controller;

import gui.IRefreshAgent;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.*;
import java.util.Iterator;

import state.Duck;
import state.GameState;
import state.Gun;

/**
 * Move the gun sights to follow the mouse.
 * 
 * Note that we need to add specific logic to "clean up" the sights once the last duck
 * is killed, otherwise there will be a linger 'sights' drawn.
 * 
 * How to deal with cursor?
 * 
 * @author George
 */
public class GunController implements MouseMotionListener, MouseListener {

	/** GameState information. */
	GameState state;
	
	/** If a refresh is needed, contact the refresh agent to request the refresh. */
	IRefreshAgent agent;
	
	/**
	 * Construct GunController to know of the 
	 * @param canvas
	 * @param ra
	 * @param state
	 */
	public GunController (IRefreshAgent ra, GameState state) {
		this.state = state;
		this.agent = ra;
	}
	

	/**
	 * Determine whether the end of the game has happened.
	 */
	public void determineGameEnding() {
		if (state.stillAlive()) return;
		
		agent.forceRepaint();

	}
	
	/** 
	 * Update the sights of the gun on the DuckCanvas.
	 * 
	 * Note: if the game is no longer active, then these sights should not be drawn.
	 * 
	 * @param point   where to place the sights.
	 */
	private void locate(Point point) {
		Gun gun = state.getGun();
		if (gun == null) return;

		// if not alive, no sights
		if (!state.stillAlive()) {
			return;
		}
		
		gun.setAim (point);
		agent.forceRepaint();
	}
	
	public void mouseDragged(MouseEvent e) {
		locate (e.getPoint());
	}


	public void mouseMoved(MouseEvent e) {
		locate (e.getPoint());
	}

	/** 
	 * Attempt to fire the gun at given point.
	 */
	public void mousePressed(MouseEvent e) {
		Point point = e.getPoint();
		fireGun (point);
	}

	/**
	 * Fire the gun at the given point.
	 * 
	 * Note that we keep this separate from the mouse handler to enable
	 * automatic testers to have access as well.
	 * 
	 * @param point    location where gun is to be fired.
	 */
	public void fireGun(Point point) {
		if (!state.stillAlive()) return;
		
		Gun g = state.getGun();
		
		synchronized (g) {
			if (!g.isSufficientlyCharged()) {
				Toolkit.getDefaultToolkit().beep();
				return;
			}

			// discharge the gun.  We select the right sound soon.
			g.discharge();
		}
		
		// determine if there is a hit. Only the first DUCK gets the bullet.
		boolean hitDuck = false;
		for (Iterator<Duck> it = state.getDucks(); it.hasNext(); ) {
			Duck d = it.next();
			if (!d.isAlive()) continue;
			
			if (d.intersects(point)) {
				d.kill();
				
				// play sounds in sequence.
				SoundController.makeGunSound();
				SoundController.makeDyingDuckSound();
				
				PointController pc = PointController.instance();
				Dimension dxy = d.getMovement();
				int score = (int) (10*Math.sqrt(dxy.height*dxy.height + dxy.width*dxy.width));
				pc.addScore(score, new Point (point.x, point.y-20));  // start above.
				
				state.increaseScore (score);
				
				// ONLY one duck can be shot at a time! Even if they overlap
				hitDuck = true;
				break;    // DEFECT #1
			}
		}
		
		// Make the sound only.
		if (!hitDuck) {
			SoundController.makeGunSound();
		}

		// bad place? if the last duck has been shot, reset drawing sights and change cursor
		determineGameEnding();
	}


	public void mouseReleased(MouseEvent e) {}
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}

}

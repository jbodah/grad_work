package ks.client.game.wordsteal;

import ks.client.interfaces.IGameInterface;
import wordsteal.boundaries.main.IExternalInterface;

/**
 * Wordsteal is implemented in its own project and I don't 
 * want to intermingle code, so we have to create bridge
 * interfaces, such as this one, to keep code bases separate. 
 * 
 * @author George Heineman
 */
public class BridgeCallback implements IExternalInterface {

	// primary interface. 
	IGameInterface game;
	
	// table id.
	int tableID;
	
	BridgeCallback (IGameInterface game, int tableID) {
		this.game = game;
		this.tableID = tableID;
	}
	
	@Override
	public void skipTurn() {
		game.skip(tableID);
	}

}

package wordsteal.controllers;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import wordsteal.boundaries.main.BoardRackPanel;
import wordsteal.entities.BoardTileLocation;
import wordsteal.entities.Cell;
import wordsteal.entities.ITileLocation;
import wordsteal.entities.Rack;
import wordsteal.entities.RackTileLocation;
import wordsteal.entities.Tile;
import wordsteal.entities.TileMovement;
import wordsteal.interfaces.IWordstealApp;

/**
 * Persistent controller used to handle the moving around of tiles. Traps all mouse
 * events from the board/rack area of the main UI
 * @author Zach
 *
 */
public class MoveTileController implements MouseListener, MouseMotionListener {

	/** Handle to main application object */
	IWordstealApp app;
	
	/**
	 * Constructor
	 * @param mf Handle to main application object
	 */
	public MoveTileController(IWordstealApp mf) {
		this.app = mf;
	}
	
	@Override
	public void mouseClicked(MouseEvent me) {
		

	}

	@Override
	public void mouseEntered(MouseEvent me) {
		

	}

	@Override
	public void mouseExited(MouseEvent me) {
		

	}

	@Override
	public void mousePressed(MouseEvent me) {
		if (this.app.isLockedUI()) { return; }
		
		// Force drop a tile if player was using keyboard
		this.app.getAccessibilityController().forceDropTile();
		
		// Make sure a game is actually in progress
		if(this.app.getGame() != null) {
			
			BoardRackPanel brp = (BoardRackPanel)me.getComponent();
			int x = me.getX();
			int y = me.getY();
			
			if(brp.isWithinBoard(x, y)) {
				
				Cell cell = brp.getClickedCell(x, y);
				Tile tile = cell.getTile();
				
				if(tile != null && tile.getOwner() == null) {
					cell.setTile(null);
					this.app.getGame().setGrabbedTile(tile);
					this.app.getGame().setGrabbedTileX(x);
					this.app.getGame().setGrabbedTileY(y);
					this.app.getGame().setGrabbedTileSrcLocation(
							new BoardTileLocation(cell));
				}
				
			} else {
				
				Tile tile = brp.getClickedTile(x, y);
				
				if(tile != null) {
					int tileIndex = this.app.getGame().getRack().getTiles().indexOf(tile);
					this.app.getGame().getRack().removeTile(tile);
					this.app.getGame().setGrabbedTile(tile);
					this.app.getGame().setGrabbedTileX(x);
					this.app.getGame().setGrabbedTileY(y);
					this.app.getGame().setGrabbedTileSrcLocation(
							new RackTileLocation(tileIndex, 
									this.app.getGame().getRack()));
				}
			}
			
			this.app.repaintBoardAndRack();
		}
	}

	@Override
	public void mouseReleased(MouseEvent me) {
		if (this.app.isLockedUI()) { return; }

		if(this.app.getGame() != null) {
			BoardRackPanel brp = (BoardRackPanel)me.getComponent();
			int x = me.getX();
			int y = me.getY();
			
			Tile grabbedTile = this.app.getGame().getGrabbedTile();
			
			if(grabbedTile != null) {
			
				ITileLocation srcLocation = this.app.getGame().getGrabbedTileSrcLocation();
				
				this.app.getGame().setGrabbedTile(null);
				this.app.getGame().setGrabbedTileX(0);
				this.app.getGame().setGrabbedTileY(0);
				this.app.getGame().setGrabbedTileSrcLocation(null);
				
				if(brp.isWithinBoard(x, y)) {
					
					Cell cell = brp.getClickedCell(x, y);
					
					if(cell.getTile() != null) {
						
						Rack rack = this.app.getGame().getRack();
						rack.addTile(grabbedTile);
						
						RackTileLocation rackLocation = new RackTileLocation(rack.getTiles().indexOf(grabbedTile), rack);
						TileMovement movement = new TileMovement(srcLocation, rackLocation);
						
						this.app.getGame().getUndoManager().pushMovement(movement);
								
						
					} else {
						
						cell.setTile(grabbedTile);
						this.app.getGame().getUndoManager().pushMovement(
								new TileMovement(srcLocation,
										new BoardTileLocation(cell)));
					}
					
				} else if(brp.isWithinRack(x, y)){
					
					int index = brp.getRackIndex(x, y);
					
					Rack rack = this.app.getGame().getRack();
					rack.insertTile(grabbedTile, index);
					
					RackTileLocation rackLocation = new RackTileLocation(index, rack);
					TileMovement movement = new TileMovement(srcLocation, rackLocation);
					
					this.app.getGame().getUndoManager().pushMovement(movement);
					
					
					
				} else {
					Rack rack = this.app.getGame().getRack();
					rack.addTile(grabbedTile);
					
					RackTileLocation rackLocation = new RackTileLocation(rack.getTiles().indexOf(grabbedTile), rack);
					TileMovement movement = new TileMovement(srcLocation, rackLocation);
					
					this.app.getGame().getUndoManager().pushMovement(movement);
				}
				
				this.app.repaintBoardAndRack();
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent me) {
		if (this.app.isLockedUI()) { return; }

		if(this.app.getGame() != null) {
			if(this.app.getGame().getGrabbedTile() != null) {
				BoardRackPanel brp = (BoardRackPanel)me.getComponent();
				int x = me.getX();
				int y = me.getY();
				
				if(brp.isGrabbedTileWithinGameArea(x, y)) {
					this.app.getGame().setGrabbedTileX(x);
					this.app.getGame().setGrabbedTileY(y);
				}
			}
			
			this.app.repaintBoardAndRack();
		}
	}

	@Override
	public void mouseMoved(MouseEvent me) {
		
	}

}

package ks.client.lobby;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import org.w3c.dom.Document;

import arch.MyLobbyInitialization;
import junit.framework.TestCase;
import ks.client.controllers.DisconnectController;
import ks.client.interfaces.ILobby;
import ks.client.interfaces.ILobbyInitialize;
import ks.client.ipc.Client;
import ks.framework.common.Configure;
import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.server.ipc.Server;

/** Validate controller works as expected. */
public class TestRegisterButtonController extends TestCase {

	ILobbyInitialize init;
	ConnectFrame cf;
	Server server;
	JPanel tempUserManagerGUI;
	JPanel tempTableManagerGUI;
	
	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			assertTrue (Configure.configure());
			
			// validate a simple tables
			String s = Message.requestHeader() + "<tables/></request>";
			Document d = Message.construct(s);
			assertTrue (d != null);
			
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
		
		// standard 7878
		server = new Server();
		server.activate();
		
		// create mock-User manager now outside. You should replace with 
		// the appropriate class construction on your end.
		 tempUserManagerGUI = new JPanel();
		JLabel jLabel = new JLabel();
		jLabel.setText("UMGUI To Be Inserted");
		tempUserManagerGUI.setLayout(new FlowLayout());
		tempUserManagerGUI.add(jLabel, null);
		
		// create mock-Table manager now outside. You should replace with 
		// the appropriate class construction on your end.
		 tempTableManagerGUI = new JPanel();
		JLabel jLabel1 = new JLabel();
		jLabel1.setText("TMGUI To Be Inserted");
		tempTableManagerGUI.setLayout(new FlowLayout());
		tempTableManagerGUI.add(jLabel1, null);
				
		// initialization callback. Client-side groups can pass in 
		// an object that provides this interface into the ConnectFrame
		// constructor and it will be called at the proper time.
		init = new MyLobbyInitialization(tempTableManagerGUI, tempUserManagerGUI);
		cf = new ConnectFrame(init);
	}
	
	protected void tearDown() {
		server.deactivate();
	}
	
	// helper function to sleep for a second.
	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	// this test cases assumes that the default server can launch
	// cleanly. Note that if you have left a server running by mistake
	// then this test case will fail.
	public void testProcess() {
		String password = "xxyyzz";
		cf.getRegisterPassText().setText(password);
		cf.getRegisterConfirmPassText().setText(password);
	
		ILobby lobby = new RegisterButtonController(cf).process(init);
		assertTrue (lobby != null);
		
		waitASecond();
		
		// make sure our GUIs are in place
		assertTrue (tempTableManagerGUI == lobby.getTableManagerGUI());
		assertTrue (tempUserManagerGUI == lobby.getUserManagerGUI());
		
		// who are we?
		String who = lobby.getContext().getUser();
		System.out.println("registered " + who);
		
		//validate password is the hashed version.
		String hash = Client.sha1(password);
		assertEquals (hash, lobby.getContext().getPassword());
		
		// validate server has someone
		Communicator c = server.getCommunicator();
		assertTrue (c.isOnline(who));
		
		// request log out from client.
		new DisconnectController(lobby).process(lobby.getContext());
		
		waitASecond();
		assertFalse (c.isOnline(who));
		
		((LobbyFrame) lobby).setVisible(false);
		((LobbyFrame) lobby).dispose();
	}
}

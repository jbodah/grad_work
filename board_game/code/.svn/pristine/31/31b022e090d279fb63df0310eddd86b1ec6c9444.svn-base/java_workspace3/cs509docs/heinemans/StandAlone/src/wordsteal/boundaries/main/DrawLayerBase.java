package wordsteal.boundaries.main;

import java.awt.Graphics2D;

/**
 * Base object for the decorators
 * @author Zach
 *
 */
public abstract class DrawLayerBase implements IDrawLayer {

	/** Next decorator in the chain to be drawn */
	protected IDrawLayer nextLayer;
	/** Handle to the parent UI object */
	protected BoardRackPanel brp;
	
	public DrawLayerBase(IDrawLayer next, BoardRackPanel brp) {
		this.nextLayer = next;
		this.brp = brp;
	}
	
	/**
	 * Draws the next decorator in the chain
	 * @param g2D Graphics object
	 */
	protected void next(Graphics2D g2D) {
		
		if(this.nextLayer != null) {
			this.nextLayer.draw(g2D);
		}
		
	}

}

package wordsteal.entities;

/**
 * Class representing a tile location on the rack for the purposes of undo/redo
 * @author Zach
 *
 */
public class RackTileLocation implements ITileLocation {

	/** Index of the tile on the rack */
	int tileIndex;
	/** Handle to rack */
	Rack rack;
	
	/**
	 * Constructor
	 * @param tileIndex Index of the tile on the rack
	 * @param rack Handle to rack
	 */
	public RackTileLocation(int tileIndex, Rack rack) {
		
		this.tileIndex = tileIndex;
		this.rack = rack;
	}
	
	@Override
	public void addTile(Tile tile) {
		
		this.rack.insertTile(tile, tileIndex);
	}

	@Override
	public Tile removeTile() {
		
		return this.rack.getTiles().remove(this.tileIndex);
		
	}

}

package controller;

import gui.BaseDrawing;
import gui.DecoratorDucks;
import gui.DecoratorGun;
import gui.DecoratorPoints;
import gui.DecoratorScore;
import gui.DefaultDuckDrawer;
import gui.DuckCanvas;
import gui.DuckDrawer;
import gui.IRefreshAgent;

import java.awt.Button;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import state.Duck;
import state.GameState;
import state.Gun;

/**
 * Responsible for creating the game, whether in an Applet or as a stand-alone application.
 * 
 * @author heineman
 */
public class CreateController {
	
	/** object that controls the views. */
	private DuckCanvas dc = null;
	
	/** object that knows how to draw ducks. Keep this around since it knows the size of the ducks for 'newGameState' */
	private DuckDrawer drawer = null;

	/** known game state. */
	private GameState state;
	
	/** Expose GunChargerController solely for testing. */
	private GunChargerController gcc;
	
	/** Expose GunController solely for testing. */
	private GunController gcon;
	
	/**
	 * Private controller to properly respond to restart requests.
	 * 
	 * @author heineman
	 */
	private class RestartController implements ActionListener {
	
		public void actionPerformed(java.awt.event.ActionEvent e) {
			createGame (dc);
		}
	}
	
	/**
	 * This method initializes guiPanel	
	 * 	
	 * @return java.awt.Panel	
	 */
	public DuckCanvas createPlayingArea() {
		if (dc == null) {
			
			dc = new DuckCanvas(531, 439);
			dc.setBounds(new java.awt.Rectangle(15,90,531,439));
			
			// nothing to draw, but create the drawer so it is ready for use later
			drawer = new DefaultDuckDrawer(dc);
			drawer.init();
		}
		return dc;
	}

	
	/**
	 * This method initializes startButton with the prepared RestartController.
	 * 	
	 * @return java.awt.Button	
	 */
	public Button createStartButton() {
		
		Button startButton = new Button();
		startButton.setBounds(new java.awt.Rectangle(40,45,112,23));
		startButton.setLabel("New Game");
		startButton.addActionListener(new RestartController());
			
		return startButton;
	}
	
	/**
	 * Create the game within the AWT component using the given state.
	 * 
	 * @param base
	 */
	public void createGame (Component base, GameState state) {
		this.state = state;
		
		// set up state for the game.
		dc.redrawState();
		
		// game cursor is crosshairs.
		Cursor c = Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR);
		dc.setCursor(c);		
		
		// must set up all of the decorators. In many cases, the controllers need
		// to tell the GUI to be drawn; this is exposed as a refresh agent.
		IRefreshAgent ra = new IRefreshAgent() {

			// on refresh, go to the canvas. Note that we don't let the decorator 
			// know of the canvas, hence this anonymous class.
			public void forceRepaint() {
				dc.redrawState();
			}
		};
		
		// create point controller, as a registered handler.
		BaseDrawing bd = new BaseDrawing();
		DecoratorPoints dp = new DecoratorPoints(bd);
		DecoratorDucks dd = new DecoratorDucks (dp, state, drawer);
		
		Rectangle rect = new Rectangle (40, dc.getHeight()-80,100,20);
		DecoratorGun   dg = new DecoratorGun (dd, state, rect);
		
		Point loc = new Point (dc.getWidth() - 60, dc.getHeight() - 80);
		DecoratorScore ds = new DecoratorScore (dg, state, loc);
		
		// note that this is going to be a singleton, so we don't use this object here. Check
		// out GunController for how it is used/accessed. All we must do is instantiate it
		// so the singleton access can retrieve it.
		new PointController (dp, ra);
		
		// so the drawer is now  DecoratorDucks(DecoratorPoints(BaseDrawing()))
		dc.setDrawers(ds);		
		
		// control the movement of ducks.
		DuckController controller = new DuckController (dc, state);
		controller.begin();
		
		// control the movement/action of the gun.
		gcon = new GunController (ra, state);
		dc.addMouseMotionListener(gcon);
		dc.addMouseListener(gcon);
		
		// ensure charging goes at timely pace
		gcc = new GunChargerController (state);
		gcc.begin();
		
		// ensure proper initialization of the sounds.
		SoundController.init();
	}
	
	/**
	 * Create the game within the AWT component. 
	 * 
	 * Generate a new Game
	 * @param base
	 */
	public void createGame (Component base) {
		createGame (base, newGameState());
	}
	
	/**
	 * Return a new game state.
	 * 
	 * For this to be invoked, both 'dc' and the 'drawer' must be initialized.
	 */
	protected GameState newGameState() {
		
		Gun g = new Gun();
		
		// initiate the state with ten randomly placed ducks.
		ArrayList<Duck> al = new ArrayList<Duck>();
		for (int i = 0; i < 10; i++) {
			Point p = new Point ((int) (Math.random() * (dc.getWidth()-drawer.getWidth())),
					(int) (Math.random() * (dc.getHeight()-drawer.getHeight())));
			Duck d = new Duck(p, drawer.getWidth(), drawer.getHeight());
			
			// give random movement
			int dx = (int) (Math.random()*20);
			int dy = (int) (Math.random()*20);
			if (dx == 10) dx = 5;  // avoid horizontal
			if (dy == 10) dy = 5;  // avoid vertical
			d.setMovement(2*(10-dx),2*(10-dy));
			
			al.add(d);
		}
		
		state = new GameState(g, al.iterator());
		return state;
	}

	/**
	 * Return the GunController to enable external access (likely via testing).
	 * 
	 * @return  the gun controller.
	 */
	public GunController getGunController() {
		return gcon;
	}
	
	/**
	 * Return the GunChargerController to enable external access (likely via testing).
	 * 
	 * @return  the gun charger controller.
	 */
	public GunChargerController getGunChargerController() {
		return gcc;
	}

	/**
	 * Expose game state as part of testing
	 *
	 */
	public GameState getGameState() {
		return state;
	}
}

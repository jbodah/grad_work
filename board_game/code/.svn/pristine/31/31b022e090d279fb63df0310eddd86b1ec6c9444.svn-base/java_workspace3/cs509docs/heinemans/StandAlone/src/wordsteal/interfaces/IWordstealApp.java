package wordsteal.interfaces;

import wordsteal.controllers.AccessibilityController;
import wordsteal.entities.Game;

public interface IWordstealApp {

	/** Set up to return the table number used within KombatGames. */
	int getTableNumber();
	
	/** Return the game. */
	Game getGame();

	/** Repaint board as needed now that updates have been made. */
	void repaintBoardAndRack();

	/** Keyboard access via this object. */
	AccessibilityController getAccessibilityController();

	/** Show status message. */
	void setStatus(String s);

	/** Refresh entire GUI. */
	void updateGUI();

	/** Be able to lock/unlock the GUI. */
	void lockUI(boolean b);

	/** Expose the timer. */
	//TimerController getTimerController();

	/** Determine whether the GUI has been locked or not. */
	boolean isLockedUI();

	/** Skipped turn. */
	void skipTurn();

}

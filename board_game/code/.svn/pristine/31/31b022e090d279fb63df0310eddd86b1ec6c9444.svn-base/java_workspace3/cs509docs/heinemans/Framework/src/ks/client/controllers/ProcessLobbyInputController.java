package ks.client.controllers;

import ks.client.UserContext;
import ks.client.interfaces.ILobby;
import ks.client.interfaces.ILobby2;
import ks.client.interfaces.IProcessClientMessage;
import ks.client.interfaces.IProcessLobbyInput;
import ks.client.ipc.Client;
import ks.client.lobby.LobbyPanel;
import ks.framework.common.Message;

import org.w3c.dom.Document;

/**
 * Attempt to process keyboard commands from the lobby text field.
 * <p>
 * Note that this controller is an Active-GUI controller which means that it 
 * does not implement {@link IProcessClientMessage} or any other interface.
 * Check out where this controller is accessed (from {@link LobbyPanel#getLobbyInput}).
 *  
 * @author George Heineman
 */
public class ProcessLobbyInputController implements IProcessLobbyInput{
	
	/** Lobby being controlled. */
	ILobby lobby;
	
	/**
	 * The Lobby Input processor needs to know the lobby to complete
	 * its tasks.
	 * 
	 * @param lobby
	 */
	public ProcessLobbyInputController (ILobby lobby) {
		this.lobby = lobby;
	}
	
	/**
	 * Process string entered by user.
	 *  
	 * @param s
	 */
	public void process(String s) {
		UserContext context = lobby.getContext();
		Client client = context.getClient();

		// must have been a chat command all along. 
		String cmd = Message.requestHeader() + "<chat>";
		cmd += "<text>" + s + "</text></chat></request>";
		Document d = Message.construct(cmd);
		Message m = new Message(d);
		client.sendToServer(m);
		
		String who = context.getUser();
		
		// Use new interface if it is available, otherwise resort to old one.
		if (!(lobby instanceof ILobby2) ){
			lobby.append(who + ": " + s);
		} else {
			((ILobby2) lobby).append(who, s, true);
		}
	}
}

package gui;

import gui.DuckCanvas;

import java.awt.Button;
import java.awt.Color;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Iterator;

import state.Duck;
import state.GameState;
import test.InteractiveTester;
import test.TestHarness;
import controller.CreateController;
import junit.framework.TestCase;

/**
 * Set of tests for validating core logic of the game when the ducks are moving.
 * 
 * @author heineman
 */
public class TestMoving extends TestCase implements InteractiveTester {

	/** harness. */
	TestHarness harness;
	
	/** Buffer at top. */
	int buffer = 100;
	
	/** determines if we are in a test case. */
	boolean active = false;
	
	/** success of last test case. */
	boolean result = false;
	 
	/** Active semaphore. */
	Object semaphore = new Object();
	
	/** The game through which we can inspect state. */
	DuckCanvas duckCanvas;
	
	/** State. */
	GameState state;
	
	/**
	 * Return the number of items in an Iterator of ducks.
	 * 
	 * @param it   the set of known ducks as an Iterator.
	 * @return     the number of ducks that are alive.
	 */
	public static int countNumberAlive (Iterator<Duck> it) {
		if (it == null) return 0;
		
		int ct = 0;
		while (it.hasNext()) {
			Duck d = it.next();
			if (d.isAlive()) {
				ct++;
			}
		}
		
		return ct;
	}
	
	protected void setUp() {
		// configure the viewer to be used. Make sure it is initialized before use!
		harness = new TestHarness();
		harness.addWindowListener(new WindowAdapter() {

			public void windowClosing(WindowEvent e) {
				testCaseDone(false);
				tearDown();
			}

			public void windowClosed(WindowEvent e) {
				testCaseDone(false);
				tearDown();
			}
		});
		
		// create the game
		CreateController cc = new CreateController();
		duckCanvas = cc.createPlayingArea();
		duckCanvas.setBackground(Color.lightGray);
		duckCanvas.setLocation(duckCanvas.getLocation().x, duckCanvas.getLocation().y + buffer);
		Button b = cc.createStartButton();
		b.setLocation(b.getLocation().x, b.getLocation().y + buffer);
		
		harness.add(duckCanvas);
		harness.add(b);
		harness.setVisible(true);
		
		// If we were configuring our initial game state, we would do it NOW and pass
		// it in as a second argument. As it is
		cc.createGame(harness);
		state = cc.getGameState();
	}
	
	/**
	 * At the close of each test, we remove the old harness.
	 */
	protected void tearDown () {
		harness.setVisible(false);
	}
	
	/**
	 * Shows the test case and instructions, and waits until user completes Success/Failure interaction.
	 * 
	 * @param testCaseName
	 * @param instructions
	 */
	public void waitUntilContact (String testCaseName, String instructions) {
		harness.setTest (this, testCaseName);
		harness.setInstructions (instructions);
		
		// not sure what to put here.	
		active = true;
		while (active) {
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// do nothing.
			}
		}
		
		// here is where we could generate problem.
		assertTrue ("result of test case: " + testCaseName + " is false.", result);
	}
	
	/**
	 * User has determined that test case succeeds.
	 */
	public void testSucceeds() {
		testCaseDone (true);
	}
	
	/**
	 * User has determined that test case fails.
	 */
	public void testFails() {
		testCaseDone (false);
	}
	
	/**
	 * When the test case has completed, invoke this method with success status.
	 * @param result
	 */
	public void testCaseDone(boolean result) {
		synchronized (semaphore) {
			active = false;
			this.result = result;
		}
	}
	
	/** Show how a shot on the duck only kills a single duck. */
	public void testShoot () {
		int numDucks = countNumberAlive (state.getDucks());

		waitUntilContact("testShoot", "shoot a duck, and click on Success if it goes away.");
		int numDucks2 = countNumberAlive (state.getDucks());
		assertEquals (numDucks-1, numDucks2);

	}
	
	/** Show how a missed shot works. */
	public void testMissedShot () {
		int numDucks = countNumberAlive (state.getDucks());
			
		waitUntilContact("testMissedShot", "Shoot in a space where there is no duck.");
	
		int numDucks2 = countNumberAlive (state.getDucks());
		assertEquals (numDucks, numDucks2);
		
	}
	
}

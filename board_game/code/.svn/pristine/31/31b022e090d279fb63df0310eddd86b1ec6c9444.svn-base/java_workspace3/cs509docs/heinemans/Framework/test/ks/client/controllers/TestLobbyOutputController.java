package ks.client.controllers;

import org.w3c.dom.Document;

import arch.ClientExtension;

import junit.framework.TestCase;
import ks.client.UserContext;
import ks.client.lobby.LobbyFrame;
import ks.client.processor.ClientProcessor;
import ks.framework.common.Configure;
import ks.framework.common.Message;
import ks.server.ipc.Server;

/** 
 * Test Lobby output controller. Although there seems to be no need to 
 * include the server, I show the full form here because most of the time
 * the client assumes it is "connected" to the server, so in this way we
 * are testing as close as possible to real life.
 * <p>
 * To be clear, a JUnit test case is defined in a single method that
 * is of the form:
 * 
 *   public void testXXXXX() {
 *      ...
 *   }
 *   
 * So in this class there is a single test case, called testValidOutput.
 * 
 * @author George Heineman
 */
public class TestLobbyOutputController extends TestCase {
	
	// host
	public static final String localhost = "localhost";
	
	// sample credentials (really meaningless in the testing case)
	public static final String user = "11323";
	public static final String password = "password";
	
	/** Constructed objects for this test case. */
	UserContext context;
	LobbyFrame lobby;
	
	// random port 8000-10000 to avoid arbitrary conflicts
	int port;
	
	/**
	 * setUp() method is executed by the JUnit framework prior to each 
	 * test case.
	 */
	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
		} catch (Exception e) {
			fail ("Unable to setup Message tests."); 
		}
		
		// Any non-standard controllers for client would need to be included here.
		// Specifically, the output response handler is non standard, so include
		// that one here.
		ClientControllerChain head = ClientProcessor.head();
		head.append(new ClientExtension());
		
		// create client to connect
		context = new UserContext();  // by default, localhost
		lobby = new LobbyFrame (context);
		lobby.setVisible(true);
		
		context.setPort(port);
		context.setUser(user);
		context.setPassword(password);
		context.setSelfRegister(false);
		
		// connect client to server
		assertTrue (new ConnectController(lobby).process(context));
		
		// wait for things to settle down. As your test cases become more
		// complex, we may find it necessary to include additional waiting 
		// times.
		waitASecond();
	}

	/**
	 * tearDown() is executed by JUnit at the conclusion of each individual
	 * test case.
	 */
	protected void tearDown() {
		// the other way to leave is to manually invoke controller.
		assertTrue (new DisconnectController (lobby).process(context));
		
		lobby.setVisible(false);
		lobby.dispose();
	}
	
	// helper function to sleep for a second.
	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	/**
	 * The actual test case. Note its structure, where expected inputs are 
	 * defined and then the execution of a message on the client occurs.
	 * finally the state on the client side is inspected.
	 * <p>
	 * Over time I may have to write additional helper methods to expose 
	 * lots of client-side state for the testers.
	 */
	public void testValidOutput() {
		// get existing text
		String existing = lobby.getInnerPanel().getLobbyOutput().getText();
		String text = "Hello";
		int uid = 192;
		
		// create OUTPUT message
		String cmd = Message.responseHeader(true) + "<output from='" + uid + "'>";
		cmd += "<text>" + text + "</text></output></response>";
		Document d = Message.construct(cmd);
		Message m = new Message(d);
		
		// process message on client
		context.getClient().process(m);
		
		// validate new text appended; trim excess when comparing output because of trailing carriage returns and the like.
		String newText = lobby.getInnerPanel().getLobbyOutput().getText().trim();
		String target = existing + uid + ": " + text;

		System.out.println(newText.length() + "," + target.length());
		assertEquals (target, newText);
	}
}

package wordsteal.entities;

/**
 * Interface abstracting away board/rack locations for the purposes of undo
 * @author Zach
 *
 */
public interface ITileLocation {

	/** Adds a tile to the location */
	void addTile(Tile tile);
	/** Removes a tile from the location and returns it */
	Tile removeTile();
}

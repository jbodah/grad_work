package ks.server.interfaces;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;

/**
 * Interface to declare the processing of a message on the server.
 * <p>
 * The message may be a request or a response. Sometimes the
 * class implementing this interface processes the message to generate
 * a request. Other times, the class implementing the interface is passing
 * along the message (without processing) along to another class who is
 * responsible for the actual processing.
 * 
 * @author George Heineman
 */
public interface IProcessServerMessage {
	
	/**
	 * Acts upon a message to be processed. If the message can be handled
	 * then return <code>true</code>.
	 *
	 * @param com  Communicator used for the transmission of the message.
	 * @param m    Message to be processed. 
	 */
	boolean process (Communicator com, Message m);
}

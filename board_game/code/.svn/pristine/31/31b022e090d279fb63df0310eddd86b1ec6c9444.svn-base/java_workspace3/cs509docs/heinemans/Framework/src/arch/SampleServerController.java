package arch;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.framework.debug.Debug;
import ks.server.interfaces.IProcessServerMessage;

import org.w3c.dom.Document;

/** Sample Server controller. */
public class SampleServerController implements IProcessServerMessage {

	public boolean process(Communicator com, Message m) {
		System.out.println(m);

		String id = m.id;
		String s = new String ("<response version='1.0' id='" + id + "' success='true'>\n" +
				"<playerResponse>\n" +
				"<player player='1213' realName='George Heineman'>\n" + 
				"<rating category='solitaire' value='229'/>\n" + 
				"<rating category='wordsteal' value='1234'/>\n" + 
				"</player>\n" + 
				"</playerResponse>\n" + 
				"</response>");

		Document d = Message.construct (s);
		Message r = new Message(d);

		// send right back to (and only to) originating client.
		r.setRecipient(m.getOriginator());
		com.distribute(r);
		return true;
	}
}
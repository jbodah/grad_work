You can run the sample framework by:

1. Launching arch.ServerArchitecture

   ** this starts up default KombatSolitaire server
   
2. Launching arch.ClientArchitecture

   ** this starts up default KombatSolitaire client
   
3. Easiest way to connect is to click 'register'. You don't even
   have to enter a password. 
   
You won't be able to do much other than chat.

To see a game behavior, launch the server and client. Then once connected
check out the menu bar at the top of the screen where you can select to
launch a sample solitaire Klondike implementation.  This works with the 
planned-for GameWindow interface (and GameManager). All code is in the 
Framework area and is in "beta" form.

-------------------------------------------------------------------------

What is the easiest way to get this project into your own space so you can 
begin updating it for your own purposes?

1. Select "Team -> Disconnect..." and you will be prompted "Are you sure you want
   to disconnect SVN from Framework?". 

   make sure you select "Also delete SVN meta information from the file system" to 
   remove all traces of SVN.
   
2. Rename the project. Right click on the (now disconnected) Framework project and select
    "Refactor --> Rename..." and give the project a new name.
    
3. Now you are free to "Team --> Share" this project into your own SVN repository from 
   which you can begin to complete all future work. There is no easy way to upload patches
   to Framework if and when they occur. I will do my best to alert everyone to any changes
   that now happen.
   
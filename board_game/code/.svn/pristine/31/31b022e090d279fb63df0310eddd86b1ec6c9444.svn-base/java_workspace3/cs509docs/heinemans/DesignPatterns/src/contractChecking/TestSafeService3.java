package contractChecking;

public class TestSafeService3 extends BaseTests {
	public IDuplicate getObject() { 
		return new SafeService3();
	}
}

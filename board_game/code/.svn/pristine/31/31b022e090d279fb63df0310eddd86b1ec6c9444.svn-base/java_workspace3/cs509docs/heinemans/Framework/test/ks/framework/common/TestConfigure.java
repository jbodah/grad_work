package ks.framework.common;

import org.w3c.dom.Document;

import junit.framework.TestCase;

public class TestConfigure extends TestCase {
	
	// guarantee local configuration works
	public void testLocal() {
		Message.unconfigure();
		assertTrue (Configure.configureLocal("ks.xsd"));
	}
	
	// guarantee local configuration works
	public void testBadLocal() {
		Message.unconfigure();
		assertFalse (Configure.configureLocal("ks-MISSING-MISSING.xsd"));
	}
	
	// guarantee URL configuration works
	public void testInternet() {
		Message.unconfigure();
		assertTrue (Configure.configure());
	}
	
	// guarantee URL configuration works
	public void testBadInternet() {
		Message.unconfigure();
		assertFalse (Configure.configureURL("garbage HTTP"));
		
		// valid URL but not a schema definition file. Can't detect on configure. Must 
		// wait for application
		Message.unconfigure();
		assertTrue (Configure.configureURL("http://www.wpi.edu/~heineman/xml/bad.html"));
		
		// note: this defaults to auto-load the local file, so no clear way
		// to test this is a valid or invalid schema. I can live with that.
		
	}
}

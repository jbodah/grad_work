package contractChecking;

public interface IDuplicate2 extends IDuplicate {

	/** Determine whether array has duplicates. */
	
	boolean hasDuplicates(int[]a);

}

package ks.framework.common;

import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.util.UUID;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import ks.framework.debug.Debug;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Wrapper class for an XML Document that conforms to a schema 
 * document configured at run-time.
 * <p>
 * The configuration is allowed only once and must be done before
 * any messages are constructed. 
 * <p>
 * The full set of commands, requests and adminCommands can be 
 * found at http://www.wpi.edu/~heineman/xml.
 * <p>
 * One could envision writing a series of subclasses, each representing
 * the different types of messages, requests and adminCommands. For now,
 * however, I am taking the lightweight approach and expecting that
 * the user of this class will be able to do the requisite XML
 * parsing to retrieve the desired information.
 * <p>
 * Every Message is from a specific user and is intended to be sent
 * to a specific user. 
 * <p>
 * If the message is to be broadcast, then it can be so marked. 
 * <p>
 * A Message is serializable to ensure transport over the network.
 * 
 * @author George Heineman
 */
public class Message implements java.io.Serializable {
	/**
	 * Serialization ID for consistency through upgrades.
	 */
	private static final long serialVersionUID = 3759474912651841363L;

	/**
	 * Message protocol versioning scheme.
	 */
	private static String protocolVersion = "1.0";
	
	/** Tag used to validate the XML fragment. From ks.xsd schema. */
	public static final String xsiString = "xsi:noNamespaceSchemaLocation";
	
	/** Valid schema definition. */
	private static String xsdNameString = null;
	
	/** URL for this schema. */
	private static URL xsdURL = null;
	
	/** Parent URL for this schema (as a string). */
	private static String xsdParent = null;
	
	/** Version tag name. */
	public static final String versionTAG = "version";
	
	/** ID tag name. */
	public static final String idTAG = "id";
	
	/** Success tag name. */
	public static final String successTAG = "success";
	
	/** Reason tag name. */
	public static final String reasonTAG = "reason";
	
	/** 
	 * Singleton Schema to be used for all message processing.
	 * <p>
	 * Lazy evaluation. Only created when needed. */
	private static Schema schema; 
	
	/** Validator for XML documents. Constructed as needed. */
	private static Validator validator = null;
	
	/** Determine whether initialization must be performed (in lazy evaluation). */
	private static boolean initialized = false;
	
	/** Builder to use when constructing Message objects. */
	private static DocumentBuilder builder = null;
	
	/** Type of this message. */
	public final MessageType type;
	
	/** Contents of this message. */
	final Node contents;
	
	/** Name of this command, request of adminCommand. */
	public final String name; 
	
	/** Version or protocol being spoken by message. */
	public final String version;
	
	/** If no version, then value defaults to this one. */
	public final String versionUnknown = "0.0";
	
	/** If no id, then ID value defaults to this one. */
	public final String idUnknown = "0";
	
	/** Standard fragment trailer. */
	public static final String fragTrailer = "</message>";

	/** Standard fragment header (can be determined once xsd* variables are set. */
	public static String fragHeader;

	
	/** 
	 * ID of message. While not unique globally, may be used within client
	 * to correlate a request with a command. 
	 */
	public final String id;
	
	/** Success of message, if a response. */
	public final boolean success;
	
	/** Reason, if response. */
	public final String reason;
	
	/** Is this a broadcast message? */
	boolean broadcast = false;
	
	/** The originator of the message. */
	String originator = null; 
	
	/** The recipient of the message. */
	String recipient = null;
	
	/** 
	 * Configure Message class to know of XSD schema definition file.
	 * <p>
	 * Note that URL should have at least a '/' in its path, but
	 * this should be acceptable.
	 * 
	 * If called multiple times, an {@link IllegalStateException} is raised.
	 * 
	 * @param name    name of xsd file
	 * @param xsd     URL to the xsd file 
	 */
	public static void configure (String name, URL xsd) throws IllegalStateException {
		if (xsdURL != null) {
			if (xsdURL.equals(xsd)) {
				// already done. Note that above equals method is COSTLY!
				return;
			}
			throw new IllegalStateException("Message already configured to use:" + xsdURL);
		}
		
		xsdNameString = name;
		String s = xsd.getPath();
		int idx = s.lastIndexOf('/');  // go back one level
		if (idx == -1) { idx = s.length(); }
		xsdParent = s.substring(0,idx);
		xsdURL = xsd;
		
		setFragmentHeader();
	}
	
	// helper method to enable testing to work properly by unconfiguring
	// what once was configured.
	public static void unconfigure() {
		xsdNameString = null;
		xsdURL = null;
		xsdParent = null;
		setFragmentHeader();
	}
	
	
	private static void setFragmentHeader() {
		 fragHeader = new String(
					"<?xml version=\"" + protocolVersion + "\" encoding=\"UTF-8\"?>\n" +
					"<message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" \n" +
					"xsi:schemaLocation='" + xsdParent + " \n" + xsdURL + "'\n" +
		            "xsi:noNamespaceSchemaLocation='" + xsdNameString + "'>");	
	}
	
	/** Helper enumerated type to keep track of the types of messages. */
	public enum MessageType {
		Unknown("Unknown"),
		Request("Request"),
		Response("Response");
		
		/** Record string information of the type, for toString(). */
		private String type;
		
		/** Record the type. */
		private MessageType (String type) {
			this.type = type;
		}
		
		/** Helper method to output String representation of type. */
		public String toString () {
			return type;
		}
		
		/** Method to easily compare against constants or other strings. */
		public boolean same (Object o) {
            if (o == null) { return false; }
            if (o instanceof MessageType) {
                return this == ((MessageType) o);
            }

            // compare strings?
            return (this.toString().equalsIgnoreCase(o.toString()));
        }
	}
	
	private static Schema compileSchema(URL schema) throws SAXException {
		//Get the SchemaFactory instance which understands W3C XML Schema language
		SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		
		return sf.newSchema(schema);
	}

	private static boolean initialize() {
		try {
			// parse schema first, see compileSchema function to see how Schema object is obtained.
			schema = compileSchema(xsdURL);
	
			// this "Schema" object is used to create "Validator" which
			// can be used to validate instance document against the schema
			// or set of schemas "Schema" object represents.
			validator = schema.newValidator();
			
			// set ErrorHandle on this validator
			validator.setErrorHandler(new MyErrorHandler());

            // now show how to access its information
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            builder = factory.newDocumentBuilder();
           
			initialized = true;
		} catch (Exception e) {
			initialized = false;
		}
		
		return initialized;
	}
	
	/**
	 * If the contents node has an Element child, this fetches the first Node
	 * object and returns it.
	 * 
	 * The first child is the actual command, request or admin-command
	 * 
	 * @return  Node which represents command, request or admin-command.
	 */
	public Node contentsChild() {
		
        NodeList children = contents.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node n = children.item(i);

            if (n.getNodeType() == Node.ELEMENT_NODE) {
            	return n;
            }
        }
        
        return null;
	}
	
	/**
	 * Return Document object that contains the Message as scanned.
	 * <p>
	 * Make method synchronized since parse() is not thread safe.
	 * Thus we ensure serialized access to the parsing routines.
	 * 
	 * @param    contents   the XML fragment to be encapsulated within a Message. 
	 * @return   Document object representing the Message or null if an error
	 *           occurs; also dump stack trace on error.
	 */
	public static synchronized Document construct (String contents) {
		Debug.println ("constructing:" + contents);
		
		if (!initialized) { 
			if (!initialize()) { return null; }
		}
		
		// HACK: TODO: FIX HERE
		
		try {
			StringBuilder combined = new StringBuilder(fragHeader);
			combined.append(contents).append(fragTrailer);
			InputSource is = new InputSource (new StringReader (combined.toString()));
			
			// validate
			validator.validate (new SAXSource (is));
			
			// now reopen and parse
			is = new InputSource (new StringReader (combined.toString()));
			return builder.parse(is);
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	/**
	 * Validates on construction.
	 * 
	 * @param doc
	 * @exception if doc isn't an XML fragment from the ks.xsd schema
	 */
	public Message (Document doc)  {
		try {
			Element msg = doc.getDocumentElement();
	        NamedNodeMap nnm = msg.getAttributes();
	        
	        Node xsi = nnm.getNamedItem(xsiString);
	
	        // must be ks.xsd
	        String s = xsi.getNodeValue();
	        if (s == null || !s.equals (xsdNameString)) {
	        	throw new RuntimeException ("Message received XML fragment (" + s + ") not validated by" + xsdNameString);
	        }
	        
            // since we have done some work, record the type of message
            MessageType t = MessageType.Unknown;
            Node c = null;
            NodeList children = msg.getChildNodes();
            for (int i = 0; i < children.getLength(); i++) {
                Node n = children.item(i);

                String name = n.getNodeName();
                 if (MessageType.Request.same(name)) {
                    t = MessageType.Request;
                    c = n;
                } else if (MessageType.Response.same(name)) {
                	t = MessageType.Response;
                	c = n;
                }
            }

            if (t == MessageType.Unknown) {
                throw new RuntimeException ("Message is still of unknown type somehow.");
            }
	        
            // get version and ID for message
            NamedNodeMap nnmc = c.getAttributes();
            Node nv = nnmc.getNamedItem(versionTAG);
            if (nv != null) {
            	this.version = nv.getNodeValue();
            } else {
            	this.version = versionUnknown;
            }
            Node ni = nnmc.getNamedItem(idTAG);
            if (ni != null) {
            	this.id = ni.getNodeValue();
            } else {
            	this.id = idUnknown;
            }
            
            Node ns = nnmc.getNamedItem(successTAG);
            if (ns != null) {
            	this.success = Boolean.valueOf(ns.getNodeValue());
            } else {
            	this.success = true; // default to this 
            }
            
            Node nr = nnmc.getNamedItem(reasonTAG);
            if (nr != null) {
            	this.reason = nr.getNodeValue();
            } else {
            	this.reason = "";
            }
            
	        // Finally! Retrieve the name of the enclosed content type.
	        children = c.getChildNodes();
	        String name = null;
	        Node n = null;
	        for (int i = 0; i < children.getLength(); i++) {
	        	n = children.item(i);
	        	
	        	// found it! There shall be only one
	        	if (n.getNodeType() == Node.ELEMENT_NODE) {
	        		name = n.getNodeName();
	        		break;
	        	}
	        }
	        
	        // set all final fields.
	        this.type = t;
	        this.name = name;
	        this.contents = n;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException ("Message received XML fragment not validated by " + xsdNameString);
		}
	}
	
	/** Return the contents of this message. */
	public Node contents() {
		return contents;
	}
	
	/** Return the name of command, request or adminCommand. */
	public String getName() {
		return name;
	}
	
	/**
	 * Is this a request message?
	 */
	public boolean isRequest() { 
		return (type == MessageType.Request);
	}
	
	/**
	 * Is this a response message?
	 */
	public boolean isResponse() { 
		return (type == MessageType.Response);
	}
	
	/**
	 * Is this a response successful.
	 * 
	 * Note: if this message is not a response at all, false is returned so please
	 * call {@link #isResponse()} first if you are unsure.
	 */
	public boolean getResponseSuccess() {
		if (type != MessageType.Response) {
			System.err.println("Invalid attempt to call getResponseSuccess on a non-response");
			return false;
		}
		
		return (success);
	}
	
	/** Determine the originator of the message. */
	public void setOriginator (String name) {
		this.originator = name;
	}
	
	/** Retrieve the originator of the message. */
	public String getOriginator () {
		return originator;
	}
	
	/**
	 * Determine the intended recipient of the message.
	 * <p>
	 * If one wishes a message to be broadcast, use the 
	 * setBroadcast() message.
	 */
	public void setRecipient (String name) {
		recipient = name;
		broadcast = false;
	}
	
	/**
	 * Assign the message to be broadcast.
	 * <p>
	 * If one wishes a message to be sent to a single recipient, use
	 * the setRecipient(String) method. This method has no impact on
	 * the recipient field.
	 */
	public void setBroadcast() {
		broadcast = true;
	}
	
	/** Is this message to be broadcast? */
	public boolean isBroadcast() {
		return broadcast;
	}

	
	/** Return the recipient (or null if a broadcast message). */
	public String getRecipient() {
		return recipient;
	}
	
	public String toString () {
		return "Message[" + type + "] " + name;
	}

	/**
	 * Helper method to retrieve the string value associated with the 
	 * given attribute. If the attribute does not exist, then null is 
	 * returned.
	 * 
	 * @param string   desired attribute to retrieve
	 */
	public String getAttribute(String string) {
		 NamedNodeMap atts = contents.getAttributes();
		 Node att = atts.getNamedItem(string);
		 if (att == null) { return null; }
		 
		 return att.getNodeValue();
	}

	/** 
	 * Generate response header with unique message id.
	 * 
	 */
	public static String responseHeader(boolean success) {
		String id = UUID.randomUUID().toString();
		return responseHeader (success, id);
	}
	
	/** 
	 * Generate response header using given is as the message id.
	 * 
	 * @param success  true for successful response; false otherwise.
	 * @param id    message to which this response is generated.
	 */
	public static String responseHeader(boolean success, String id) {
		return "<response version='" + protocolVersion + "' id='" + id + "' success='" + success + "'>";
	}

	/** 
	 * Generate response header using given is as the message id and specific reason.
	 * 
	 * @param success  true for successful response; false otherwise.
	 * @param id       message to which this response is generated.
	 * @param reason   failure (or success) reason to include with the message
	 */
	public static String responseHeader(boolean success, String id, String reason) {
		return "<response version='" + protocolVersion + "' id='" + id + "' success='" + success + "' reason='" + reason + "'>";
	}
	
	/**
	 * Generate request header with unique message id.
	 */
	public static String requestHeader() {
		String id = UUID.randomUUID().toString();
		return "<request version='" + protocolVersion + "' id='" + id + "'>";
		
	}
}

package ks.common.model;

import junit.framework.TestCase;

public class TestMutableString extends TestCase {

	public void testBasic() {
		MutableString ms = new MutableString("one");
		assertEquals ("one", ms.getValue());
		ms.setValue("two");
		assertEquals ("two", ms.getValue());
		
		// bad attempts
		ms.setValue(null);
		assertEquals ("two", ms.getValue());
		
		// no impact
		ms.setValue("two");
		assertEquals ("two", ms.getValue());
	}
	
	public void testNoArg() {
		MutableString ms = new MutableString("one");
		
		// with no name, the name becomes MutableString
		assertTrue (ms.getName().startsWith("MutableString"));
	}
	
	
	public void testNamed() {
		MutableString ms = new MutableString("myName", "one");
		
		// with no name, the name becomes MutableString
		assertEquals ("myName", ms.getName());
		assertEquals ("one", ms.getValue());
	}
	
	public void testNoNamed() {
		MutableString ms = new MutableString(null, "one");
		
		// with no name, the name becomes MutableString
		assertTrue (ms.getName().startsWith("MutableString"));
		assertEquals ("one", ms.getValue());
	}
	
	
	public void testToString() {
		MutableString ms = new MutableString("myName", "one");
		assertEquals ("ks.common.model.MutableString:myName=one", ms.toString());
	}
}

package dijordan.view;

import java.awt.event.MouseEvent;
import java.util.Enumeration;

import dijordan.PyramidGame;
import dijordan.model.PositionCard;
import dijordan.model.Pyramid;

import ks.client.gamefactory.GameWindow;
import ks.common.model.Card;
import ks.common.model.Column;
import ks.common.model.Deck;
import ks.common.model.Element;
import ks.common.model.Stack;
import ks.common.view.DeckView;
import ks.common.view.PileView;
import ks.common.view.RowView;
import ks.common.view.Widget;
import ks.launcher.Main;
import ks.tests.KSTestCase;

public class TestPyramidView extends KSTestCase {
	// this is the game under test.
	PyramidGame game;
	
	// window for game.
	GameWindow gw;
	
	// widget under inspection
	PyramidView pyramidView;
	
	DeckView deckView;
	PileView pileView;
	RowView rowView;
	
	// model backing this widget.
	Pyramid pyramid;
	
	protected void setUp() {
		game = new PyramidGame();
		
		// Because solitaire variations are expected to run within a container, we need to 
		// do this, even though the Container will never be made visible. Note that here
		// we select the "random seed" by which the deck will be shuffled. We use the 
		// special constant Deck.OrderBySuit (-2) which orders the deck from Ace of clubs
		// right to King of spades.
		gw = Main.generateWindow(game, Deck.OrderBySuit); 

		for (Enumeration<Widget> en = game.getWidgets(); en.hasMoreElements(); ) {
			Widget w = en.nextElement();
			System.out.println(w.getName());
			if (w.getName().equals ("thePyramid")) {
				pyramidView = (PyramidView) w;
				pyramid = (Pyramid) w.getModelElement();
			} else if (w.getName().startsWith("DeckView")) {
				deckView = (DeckView) w;
			} else if (w.getName().startsWith("PileView")) {
				pileView = (PileView) w;
			} else if (w.getName().startsWith("RowView")) {
				rowView = (RowView) w;
			}
		}
	}
	
	// clean up properly
	protected void tearDown() {
		gw.setVisible(false);
		gw.dispose();
	}
	
	public void testKingElimination() {
	
		assertTrue (pyramid.isCardThere(7,6));
		
		// This eliminates KING
		MouseEvent pr = createPressed (game, pyramidView, 414, 210);
		pyramidView.getMouseManager().handleMouseEvent(pr);
		
		assertFalse (pyramid.isCardThere(7,6));
		
		
	}
	
	public void testQueenSelection() {
		
		assertTrue (pyramid.isCardThere(7,7));
		
		// This selects Queen
		MouseEvent pr = createPressed (game, pyramidView, 444, 210);
		pyramidView.getMouseManager().handleMouseEvent(pr);
		
		assertTrue (pyramid.isCardThere(7,7));
		
		PositionCard pc = pyramid.peekSelected();
		assertEquals (Card.QUEEN, pc.getRank());
		
		// This deselects Queen
		pr = createPressed (game, pyramidView, 444, 210);
		pyramidView.getMouseManager().handleMouseEvent(pr);
		
		assertTrue (pyramid.isCardThere(7,7));
		
		assertTrue (null == pyramid.peekSelected());
	}
	
	public void testEliminateQueenACE() {
		
		assertTrue (pyramid.isCardThere(7,7));
	
		// This selects ACE and that makes a move
		MouseEvent pr = createPressed (game, pyramidView, 333, 210);
		pyramidView.getMouseManager().handleMouseEvent(pr);
		
		assertTrue (pyramid.isCardThere(7,7));
		
		PositionCard pc = pyramid.peekSelected();
		assertEquals (Card.ACE, pc.getRank());

		// This selects Queen
		pr = createPressed (game, pyramidView, 444, 210);
		pyramidView.getMouseManager().handleMouseEvent(pr);
		
		assertFalse (pyramid.isCardThere(7,7));
		assertFalse (pyramid.isCardThere(7,5));
		
		
		assertTrue(game.undoMove());
		
		assertTrue (pyramid.isCardThere(7,7));
		assertTrue (pyramid.isCardThere(7,5));
	}
	
	public void testDealAFewCards() {
		
		// click on the deck a few times
		MouseEvent pr = createPressed (game, deckView, 0, 0);
		deckView.getMouseManager().handleMouseEvent(pr);
		
		// select the discarded card.
		MouseEvent pr2 = createPressed (game, pileView, 0, 0);
		pileView.getMouseManager().handleMouseEvent(pr);
		
		// card gets selected
		
		// click on the deck a few times
		pr = createPressed (game, deckView, 0, 0);
		deckView.getMouseManager().handleMouseEvent(pr);
		
		// click on the deck a few times
		pr = createPressed (game, deckView, 0, 0);
		deckView.getMouseManager().handleMouseEvent(pr);
		
		assertTrue(game.undoMove());
		assertTrue(game.undoMove());
		assertTrue(game.undoMove());
	}
	
	public void testExtendeRowView() {
		
		// click on the deck once
		MouseEvent pr = createPressed (game, deckView, 0, 0);
		deckView.getMouseManager().handleMouseEvent(pr);
		
		// select the discarded card.
		MouseEvent pr2 = createPressed (game, pileView, 0, 0);
		pileView.getMouseManager().handleMouseEvent(pr);
		
		// card gets selected
		
		// click on the deck again to start filling up the extendedRowView
		pr = createPressed (game, deckView, 0, 0);
		deckView.getMouseManager().handleMouseEvent(pr);
		
		// click on the rowview, now
		pr = createPressed (game, rowView, 0, 0);
		rowView.getMouseManager().handleMouseEvent(pr);
		
		Column row  = (Column) rowView.getModelElement();
		Stack s = row.getSelected();
		assertTrue (s.count() > 0);
		
	}
	
}

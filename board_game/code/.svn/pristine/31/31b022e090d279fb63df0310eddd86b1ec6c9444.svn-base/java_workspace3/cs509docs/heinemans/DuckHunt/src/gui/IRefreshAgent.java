package gui;

/**
 * The entity capable of forcing a refresh from the most appropriate graphics entity, 
 * namely, the top-decorator in the chain.
 * 
 * @author heineman
 */
public interface IRefreshAgent {
	/**
	 * Force a repaint of the canvas.
	 * 
	 * Used when a thread needs to redraw the whole world.
	 */
	public void forceRepaint();
}

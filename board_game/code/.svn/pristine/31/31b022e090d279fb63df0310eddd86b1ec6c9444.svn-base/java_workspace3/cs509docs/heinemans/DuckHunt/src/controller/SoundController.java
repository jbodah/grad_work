package controller;

import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;

/**
 * This controller is a static one, since we may want to make sounds at any time.
 * 
 * By making static, we avoid having to pass around references...
 * 
 * @author George
 *
 */
public class SoundController {
	
	/** Sound of a gunshot. */
	static AudioClip gunShot;
	
	/** Sound of a duck quack. */
	static AudioClip quack;
	
	/*	
	 * Load up all sounds.
	 */
	public static void init () {
		URL u = new String().getClass().getResource("/sounds/gunshot.wav");
        gunShot = Applet.newAudioClip(u);

		u = new String().getClass().getResource("/sounds/duck-quack.wav");
		quack = Applet.newAudioClip(u);
	}
	
	/**
	 * Make the sound of a gunshot.
	 */
	public static void makeGunSound() {
		if (gunShot == null) return;
		
		new Thread() {
			public void run () {
				gunShot.play();
			}
		}.start();
	}

	/**
	 * Make the sound of a dying duck.
	 */
	public static void makeDyingDuckSound() {
		if (quack == null) return;
		
		new Thread() {
			public void run () {
				quack.play();
			}
		}.run();
	}
}

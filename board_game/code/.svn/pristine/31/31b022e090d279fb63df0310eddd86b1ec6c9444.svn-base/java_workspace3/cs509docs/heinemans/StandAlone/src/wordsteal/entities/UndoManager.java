package wordsteal.entities;

import java.util.Stack;

/**
 * Class that handles undo/redo functionality
 * @author zbrod
 *
 */
public class UndoManager {

	/** Undo stack of tile movement objects */
	Stack<TileMovement> undoStack = new Stack<TileMovement>();
	
	/** Redo stack of tile movement objects */
	Stack<TileMovement> redoStack = new Stack<TileMovement>();
	
	/**
	 * Initiates undo functionality
	 */
	public void undo() {
		
		if(!this.undoStack.empty()) {
			
			TileMovement tileMovement = this.undoStack.pop();
			tileMovement.undo();
			this.redoStack.push(tileMovement);
		}
			
	}
	
	/**
	 * Initiates redo functionality
	 */
	public void redo() {
		
		if(!this.redoStack.empty()) {
			
			TileMovement tileMovement = this.redoStack.pop();
			tileMovement.redo();
			this.undoStack.push(tileMovement);
		}
	}
	
	/**
	 * Add a movement to the undo stack
	 * @param tileMovement Movement to be added
	 */
	public void pushMovement(TileMovement tileMovement) {
		
		this.undoStack.push(tileMovement);
		this.redoStack.clear();
	}
	
	/**
	 * Clear the undo/redo stacks (such as when turn passes)
	 */
	public void clear() {
		
		this.undoStack.clear();
		this.redoStack.clear();
	}
}

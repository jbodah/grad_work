package puzzler.model;

import java.awt.Point;
import java.awt.Polygon;
import java.awt.Shape;

/**
 * Represents a puzzle piece in a puzzle.
 * <p>
 * Every puzzle piece maps to a specific (x,y) location in the free-form
 * puzzle manipulation area. You may find it odd to see that a {@link Shape}
 * is included as part of a piece declaration since that class belongs to
 * the java.awt package. However, this information is structural in nature
 * and thus belongs here.
 * <p>
 * Once a piece is properly located, it cannot be moved.
 * <p>
 * 
 * @author George Heineman
 */
public class PuzzlePiece {

	/** Proper X and Y locations. */
	public final int properX;
	public final int properY;
	
	/** Shape of the puzzle piece as a polygon. */
	public final Polygon shape;
	
	/** Each piece has a unique (within a puzzle) integer identifier. */
	public final int id;
	
	/** Current location which changes as user moves pieces. */
	int x;
	int y;
	
	/**
	 * Each puzzle piece knows of its final location.
	 * <p>
	 * The transient location ({@link #x}, {@link #y}) is manipulated
	 * as the player moves the pieces. The final location of the puzzle piece
	 * is going to be ({@link #properX}, {@link #properY}). The shape of the
	 * puzzle piece is provided. At no point does the puzzle piece know whether
	 * this shape is a reasonable one.
	 * <p>
	 * The initial location of the piece is (0,0). To alter this location, be
	 * sure to call {@link #setLocation(int, int)}.
	 * 
	 * @param id
	 * @param properX
	 * @param properY
	 * @param shape
	 */
	PuzzlePiece (int id, int properX, int properY, Polygon shape) {
		this.properX = properX;
		this.properY = properY;
		this.id = id;
		this.shape = shape;
		
		this.x = 0;
		this.y = 0;
	}

	
	/** Only enable pieces to be located by reassigning (x,y) simultaneously. */
	public void setLocation (int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Determines whether the puzzle piece contains the given
	 * x,y coordinate. Note that (x,y) are relative to the piece
	 * coordinates, not the absolute (x,y) values from whatever graphical
	 * puzzle being played.
	 * 
	 * @param x
	 * @param y
	 */
	public boolean contains (int x, int y) {
		return shape.contains(new Point (x,y));
	}

	/** Return the x coordinate for this piece. */
	public int getX(){ return x; }
	
	/** Return the y coordinate for this piece. */
	public int getY(){ return y; }

	/**
	 * Each piece can know if it has been properly placed.
	 * 
	 * @return
	 */
	public boolean isProperlyPlaced() { 
		return (properX == x && properY == y);
	}
}

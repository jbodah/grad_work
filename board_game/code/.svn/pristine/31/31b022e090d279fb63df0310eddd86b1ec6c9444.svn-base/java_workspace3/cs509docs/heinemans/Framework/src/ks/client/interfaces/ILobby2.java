package ks.client.interfaces;

/**
 * Extension to the ILobby interface
 * 
 * What happens when one wishes to change a published interface? The short answer
 * is that you don't modify an interface once it has been published, so you have 
 * to instead extend it and then force clients to dynamically check at runtime
 * whether the extension is being used. This model is used extensively, for 
 * example, in the Eclipse open source project.
 */
public interface ILobby2 extends ILobby {
	
	
	/** 
	 * Append string to the lobby output ('\n' is prepended prior to
	 * the insertion) for the given user.
	 * 
	 * @param who   the user on whose behalf the message is to be delivered
	 * @param s     the message to deliver
	 * @param isPublic   is this a public or private message.
	 */
	void append(String who, String s, boolean isPublic);
}

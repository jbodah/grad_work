package controller;


import java.awt.Point;

import gui.DecoratorPoints;
import gui.IRefreshAgent;


/**
 * Responsible for the assignment of points and the floating 'numbers' that
 *   appear above the ducks and float up, with different colors as they vanish
 *   with decreasing point size.
 *   
 * @author George
 *
 */
public class PointController {
	
	/** The decorator that we are controlling. */
	DecoratorPoints decorator;
	
	/** Ultimate agent responsible for global redraws. */
	IRefreshAgent refresh;
	
	/** Singleton point controller for ease of access. Needed still? */
	static PointController _instance = null;
	
//	 * @param refresh   the ultimate entity responsible for kicking off a global redraw

	// thread of control.
	UpdateThread thread;
	
	class UpdateThread extends Thread {
		public void run () {
			while (decorator.stillDrawing()) {
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// not much to do.
					break;
				}
				
				// We can't just tell our decorator to repaint (I mean, it might not
				// be the head of the chain) so we have to appeal to some external
				// entity that takes care of this.
				refresh.forceRepaint();
			}
			
			thread = null;
		}
	}
	
	/** Singleton constructor. */
	public static PointController instance() {
		return _instance;
	}
	
	/**
	 * Need access to the canvas.
	 * 
	 * @param decorator   Decorator we are controlling.
	 * @param refresh     ultimate entity we can appeal to when we require a global redraw
	 */
	public PointController(DecoratorPoints decorator, IRefreshAgent refresh) {
		this.decorator = decorator;
		this.refresh = refresh;
		
		_instance = this;
	}
	
	/** 
	 * Record a new score to be drawn.
	 * 
	 * Responsible for starting up the thread if this is the first one
	 * 
	 * Note that the thread goes away when there is no longer anything to draw from
	 * the point of view of points.
	 * 
	 * @param point
	 * @param loc
	 */
	public void addScore (int point, Point loc) {
		// create thread, if none being drawn right now.
		if (!decorator.stillDrawing()) {
			startup();
		}
		
		// go ahead and add to the decorator.
		decorator.addScore (point, loc);
	}

	/** 
	 * Start up the calculating thread when there is at least one score to be processed.
	 */
	private void startup() {
		thread = new UpdateThread();
		thread.start();		
	}

}

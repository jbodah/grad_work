package puzzler.constructor;

import java.awt.Polygon;

import puzzler.model.Puzzle;

public class PuzzleConstructor {
	
	/**
	 * Simplicity itself. Break into 2x3 region and form paired
	 * triangle pieces. Remaining get placed into chunks
	 * 
	 * @param img
	 * @return
	 */
	public Puzzle construct (int width, int height, int gridSize, int unitSize) {
		Puzzle puzzle = new Puzzle();
		int numW = width/unitSize;
		int numH = height/unitSize;

		int numThreeW = numW/3;
		int numTwoH = numH/2;

		int widthLeftOver  = width - unitSize * numThreeW * 3;
		int heightLeftOver = height - unitSize * numTwoH * 2; 
		
		Polygon lowerEl = new Polygon();
		lowerEl.addPoint(0,0);
		lowerEl.addPoint(unitSize, 0);
		lowerEl.addPoint(unitSize, unitSize);
		lowerEl.addPoint(unitSize*2, unitSize);
		lowerEl.addPoint(unitSize*2, unitSize*2);
		lowerEl.addPoint(0, unitSize*2);
		
		Polygon upperEl = new Polygon();
		upperEl.addPoint(0,0);
		upperEl.addPoint(2*unitSize,  0);
		upperEl.addPoint(2*unitSize,2*unitSize);
		upperEl.addPoint(unitSize,2*unitSize);
		upperEl.addPoint(unitSize,unitSize);
		upperEl.addPoint(0,unitSize);
		
		for (int w = 0; w < numThreeW; w++) {
			for (int h = 0; h < numTwoH; h++) {
				// no need to close polygon since that is done for us
				puzzle.addPiece(w*3*unitSize+0, h*2*unitSize+0, lowerEl);
				
				// second one
				puzzle.addPiece(w*3*unitSize+unitSize, h*2*unitSize+0, upperEl);
			}
		}
		
		Polygon rightSquare = new Polygon();
		rightSquare.addPoint(0,0);
		rightSquare.addPoint(widthLeftOver,  0);
		rightSquare.addPoint(widthLeftOver,unitSize);
		rightSquare.addPoint(0, unitSize);
		
		// leftovers along the right edge. Just make 1xn or nx1 squares (HACK) with appropriate
		// remnant measures.
		int numToAdd = numH - 1;
		if (numThreeW == 0) { numToAdd++; }
		
		for (int h = 0; h < numToAdd; h++) {
			// right column of squares.
			// no need to close polygon since that is done for us
			puzzle.addPiece(3*numThreeW*unitSize+0, h*unitSize, rightSquare);
		}

		if (numThreeW > 0) {
			Polygon lowerSquare = new Polygon();
			lowerSquare.addPoint(0,0);
			lowerSquare.addPoint(unitSize,  0);
			lowerSquare.addPoint(unitSize,heightLeftOver);
			lowerSquare.addPoint(0, heightLeftOver);
			
			// leftovers. Just make 1xn or nx1 squares (HACK) with appropriate
			// remnant measures.
			for (int w = 0; w < numW; w++) {
				// lower base column of squares.
				// no need to close polygon since that is done for us
				puzzle.addPiece(w*unitSize, 2*numTwoH*unitSize, lowerSquare);
			}
		}
		
		// lower right square
		Polygon lowerRightSquare = new Polygon();
		lowerRightSquare.addPoint(0,0);
		lowerRightSquare.addPoint(widthLeftOver,  0);
		lowerRightSquare.addPoint(widthLeftOver,heightLeftOver);
		lowerRightSquare.addPoint(0, heightLeftOver);
		
		puzzle.addPiece(3*numThreeW*unitSize+0, 2*numTwoH*unitSize, lowerRightSquare);
		
		return puzzle;
	}
}

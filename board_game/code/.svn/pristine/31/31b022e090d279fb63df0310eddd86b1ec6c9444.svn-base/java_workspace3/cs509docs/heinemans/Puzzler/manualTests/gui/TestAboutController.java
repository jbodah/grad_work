package gui;


import puzzler.PuzzlerApplication;
import puzzler.controller.AboutController;
import junit.framework.TestCase;

/**
 * Validate about controller works.
 * 
 * @author George Heineman
 */
public class TestAboutController extends TestCase {
	
	PuzzlerApplication app;
	
	@Override
	protected void setUp() {
		app = new PuzzlerApplication();
	}

	@Override
	protected void tearDown() {
		app.setVisible(false);
		app.dispose();
	}
	
	public void testShow() {
		System.out.println("Click on OK in About Dialog");
		AboutController ac = new AboutController(app);
		ac.process();
	}

}

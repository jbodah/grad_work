package state;

import java.awt.Point;

import state.Gun;
import junit.framework.TestCase;

/**
 * Set of tests for validating the Gun class.
 * 
 * @author heineman
 */
public class TestGun extends TestCase {

	/*
	 * Test method for 'Gun'
	 */
	public void testGun() {
		Gun g = new Gun();
		assertTrue (g.isFullyCharged());
	}
	
	/*
	 * Test method for 'state.Gun.setAim(Point)'
	 */
	public void testSetAim() {
		Gun g = new Gun();
		Point p = new Point (20, 30);
		g.setAim(p);
		p.x += 1;
		assertEquals (new Point (20, 30), g.getAim());
	}

	/*
	 * Test method for 'state.Gun.getAim()'
	 */
	public void testGetAim() {
		Gun g = new Gun();
		Point p = g.getAim();
		Point copy = new Point (p);
		p.x += 1;
		assertEquals (copy, g.getAim());
	}

	/*
	 * Test method for 'state.Gun.fullyCharged()'
	 */
	public void testFullyCharged() {
		Gun g = new Gun();
		assertTrue (g.isFullyCharged());
		g.discharge();
		assertFalse (g.isFullyCharged());
	}

	/*
	 * Test method for 'state.Gun.increaseCharge()'
	 */
	public void testIncreaseCharge() {
		Gun g = new Gun();
		assertTrue (g.isFullyCharged());
		g.discharge();
		
		// new max value is lower of (10+newCharge, 100);
		int newCharge = g.getCharge();
		int newValue = newCharge + 10;
		if (newValue > 100) { newValue = 100; }
		
		g.increaseCharge();
		assertEquals (newValue, g.getCharge());
	}

	/*
	 * Test method for 'state.Gun.sufficientlyCharged()'
	 * 
	 * Shoot gun once, then increase once. This goes over 50% limit.
	 */
	public void testSufficientlyCharged() {
		Gun g = new Gun();
		assertTrue (g.isFullyCharged());
		g.discharge();
		assertEquals (50, g.getCharge());
		assertFalse (g.isSufficientlyCharged());
		g.increaseCharge();
		assertTrue (g.isSufficientlyCharged());
	}

	/*
	 * Test method for 'state.Gun.discharge()'
	 */
	public void testDischarge() {
		Gun g = new Gun();
		assertTrue (g.isFullyCharged());
		g.discharge();
		assertEquals (50, g.getCharge());
	}

}

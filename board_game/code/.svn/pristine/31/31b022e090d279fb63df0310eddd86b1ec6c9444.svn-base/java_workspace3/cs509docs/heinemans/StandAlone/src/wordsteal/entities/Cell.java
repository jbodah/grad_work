package wordsteal.entities;

import wordsteal.util.BoardLocation;


/**
 * Class representing a cell on the board
 * @author zbrod
 *
 */
public class Cell {

	/** The color of the cell */
	public final CellColor color;
	/** The tile contained in the cell */
	Tile tile;
	
	/** Object representing the cell's position on the board */
	BoardLocation boardLocation = null;
	
	/**
	 * Constructor
	 * @param boardLocation Location of the cell
	 * @param color Color of the cell
	 */
	public Cell(BoardLocation boardLocation, CellColor color) {
		this.boardLocation = boardLocation;
		this.color = color;
	}

	/**
	 * 
	 * @return Tile contained in the cell
	 */
	public Tile getTile() {
		return tile;
	}

	/**
	 * 
	 * @param tile The tile to insert into the cell
	 */
	public void setTile(Tile tile) {
		this.tile = tile;
	}
}

package gui;

import gui.BaseDrawing;
import gui.DecoratorDucks;
import gui.DecoratorGun;
import gui.DecoratorPoints;
import gui.DecoratorScore;
import gui.DefaultDuckDrawer;
import gui.DuckCanvas;
import gui.DuckDrawer;
import gui.IRefreshAgent;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;

import state.Duck;
import state.GameState;
import state.Gun;
import test.TestHarness;
import controller.CreateController;
import controller.GunController;
import controller.PointController;
import junit.framework.TestCase;

/**
 * Set of tests for validating core logic of the game, without any movement.
 * 
 * @author heineman
 */
public class TestNonMoving extends TestCase {

	/** Canvas. */
	DuckCanvas duckCanvas;
	
	/** harness: This is going to be another Decorator! */
	TestHarness harness;
	
	/** Controller of everything. */
	CreateController controller;
	
	/** The game state. */
	GameState gameState;
	
	/**
	 * Return the number of items in an Iterator of ducks.
	 * 
	 * @param it   the set of known ducks as an Iterator.
	 * @return     the number of ducks that are alive.
	 */
	public static int countNumberAlive (Iterator<Duck> it) {
		if (it == null) return 0;
		
		int ct = 0;
		while (it.hasNext()) {
			Duck d = it.next();
			if (d.isAlive()) {
				ct++;
			}
		}
		
		return ct;
	}
	
	protected void setUp() {
		// configure the viewer to be used. Make sure it is initialized before use!
		harness = new TestHarness();
		harness.setVisible(true);
		
		// create the game
		controller = new CreateController();
		
		// Return the head of a decorator chain.
		duckCanvas = controller.createPlayingArea();
		controller.createStartButton();

		// so now we know the entity doing the drawing. From this we can get width/height
		// of each individual duck.  Make sure it is initialized before use!
		DuckDrawer drawer = new DefaultDuckDrawer(duckCanvas);
		drawer.init();
		
		// create the desired game state.
		Gun gun = new Gun();
		gun.setAim(new Point(100, 100));
		
		ArrayList<Duck> al = new ArrayList<Duck>();
		for (int i = 0; i < 10; i++) {
			Point p = new Point (100, 100);
			Duck d = new Duck(p, drawer.getWidth(), drawer.getHeight());
			
			// These ducks don't move
			d.setMovement(0,0);
			
			al.add(d);
		}
		gameState = new GameState(gun, al.iterator());
		
		// now that we have the game state, we can create the decorators.
		// create point controller, as a registered handler.
		BaseDrawing bd = new BaseDrawing();
		DecoratorPoints dp = new DecoratorPoints(bd);
		DecoratorDucks dd = new DecoratorDucks (dp, gameState, drawer);
		Rectangle rect = new Rectangle (40, duckCanvas.getHeight()-80,100,20);
		DecoratorGun   dg = new DecoratorGun (dd, gameState, rect);
		Point loc = new Point (duckCanvas.getWidth() - 60, duckCanvas.getHeight() - 80);
		DecoratorScore ds = new DecoratorScore (dg, gameState, loc);

		// note that this is going to be a singleton, so we don't use it here. Check
		// out GunController for how it is used/accessed.
		new PointController (dp, new IRefreshAgent() {

			// on refresh, go to the canvas. Note that we don't let the decorator 
			// know of the canvas, hence this anonymous class.
			public void forceRepaint() {
				duckCanvas.redrawState();
			}
		});
		
		// so the drawer is now  DecoratorPoints(BaseDrawing())
		duckCanvas.setDrawers(ds);		
		
		controller.createGame(harness, gameState);
	}
	
	protected void tearDown () {
		harness.setVisible(false);
	}
	
	/** Show how a shot on the duck only kills a single duck. */
	public void testSingleShot () {
		int numDucks = TestNonMoving.countNumberAlive (gameState.getDucks());
		GunController gc = controller.getGunController();
		gc.fireGun(new Point (100,100));
		int numDucks2 = TestNonMoving.countNumberAlive (gameState.getDucks());
		assertEquals (numDucks-1, numDucks2);
		
		// nowhere near ducks
		gc.fireGun(new Point (300,300));
		int numDucks3 = TestNonMoving.countNumberAlive (gameState.getDucks());
		assertEquals (numDucks2, numDucks3);		
	}
	
}

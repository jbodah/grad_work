package ks.client.game.sudoku;

import interfaces.IShareState;

import java.awt.Color;
import java.awt.Component;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.GroupLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

import edu.wpi.sudoku.gui.SudokuPlayingPanel;
import edu.wpi.sudoku.gui.music.SoundManager;

import wordsteal.boundaries.main.MainJPanel;
import wordsteal.entities.Player;

import ks.client.game.GameFrame;
import ks.client.game.GameInformation;
import ks.client.game.wordsteal.RemovePlayerController;

// notes for sudoku.
public class SudokuGameInformation extends GameInformation implements IShareState {

	int difficulty;
	
	/** Enclosing game frame. */
	GameFrame frame;
	
	/** Game container. */
	SudokuPlayingPanel sudokuContainer = null;
	
	/** Controls. */
	JPanel controlPanel = null;
	
	/** Is game complete? reset in start. Set in stop. */
	boolean isGameComplete = false;
	
	/**
	 * Options for solitaire include:
	 * 
	 * pink<boolean>     determine whether board clears on Pink play.
	 * noS<boolean>      prevent or allow S extensions to words
	 * turnTime<int>     time for each turn
	 * pointsToWin<int>  score at which game finishes
	 * 
	 * @param options
	 * @param gameOptions
	 */
	public SudokuGameInformation(Properties options, Properties gameOptions) {
		super(options);
		
		// set pink option
		String difficultyS = gameOptions.getProperty("difficulty");
		if (difficultyS == null) {
			difficulty = 1;
		} else {
			try {
				difficulty = Integer.valueOf(difficultyS);
			} catch (Exception e) {
				e.printStackTrace();
				difficulty = 1;
			}
		}
		
	}

	/**
	 * Non-turn based game with synchronized state and head-to-head moves 
	 */
	@Override
	public boolean start(GameFrame frame) {
		this.frame = frame;
		frame.setVisible(true);
		frame.setTitle("Sudoku by George Heineman");
		frame.setSize (800, 768);
		
		isGameComplete = false;
		return true;
	}

	@Override
	public Component getGameControls() {

		if (controlPanel == null) {
			controlPanel = new JPanel();
				
			GroupLayout layout = new GroupLayout(controlPanel);
			controlPanel.setLayout(layout);
			layout.setAutoCreateGaps(true);
			layout.setAutoCreateContainerGaps(true);
			
			// not sure what controls to put here
			JLabel lab = new JLabel("what controls?");
			layout.setHorizontalGroup(layout.createSequentialGroup()
					.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
							.addComponent(lab))
					);
			
			layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					.addGroup(layout.createSequentialGroup()
							.addComponent(lab))
					);
							
		}
		
		return controlPanel;
	}

	@Override
	public Component getGameContainer() {
		if (sudokuContainer == null) {
			sudokuContainer = new SudokuPlayingPanel();
			sudokuContainer.setUpdateSharedState (this);
			sudokuContainer.setPreferredSize(new java.awt.Dimension(490,490));
			sudokuContainer.setName("sudokuPanel");
		}
		
		return sudokuContainer;
	}

	@Override
	public void initialize() {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Stop sudoku game. Future attempts to activate turns for
	 * this game will be denied.
	 * 
	 * make sure to shut down player thread (if active).
	 */
	@Override
	public void stop() {
		SoundManager.enableSound(false);
		isGameComplete = true;
	}

	/**
	 * Extract points in preparation for returning to kombatGames.
	 * 
	 * @param players
	 * @return
	 */
	public static Properties extractScores(ArrayList<Player> players) {
		Properties props = new Properties();
		for (Player p : players) {
			// of the form "jsaldjljd [id]". Extract id.
			int idx = p.name.indexOf('[');
			int end = p.name.indexOf(']');
			
			String id = p.name.substring(idx+1, end);
			props.setProperty(id, "" + p.getPoints());
		}
		
		return props;
	}

	/**
	 * Acts by locking/unlocking interface for user action.
	 * <p>
	 * The player is the one whose turn is becoming active.
	 * <p>
	 * @param playerID   player whose turn has become active.
	 * @return <code>false</code> if game is over; <code>true</code> otherwise.
	 */
	@Override
	public boolean activateTurn(String playerID) {
		System.out.println("Not expecting to activate turn in solitaire-based games");
		return false;
	}

	@Override
	public boolean makeTurn(String playerID, String moveString) {
		System.out.println("Not expecting to make turn in solitaire-based games");
		return false;
	}

	// can't just ignore this playerID, right?
	@Override
	public boolean skipTurn(String playerID) {
		System.out.println("Not expecting to skip turn in solitaire-based games");
		return false;
	}

	/**
	 * Properly deal with in internal game as well.
	 * 
	 * Must pass in full name since that is used internally in the game.
	 */
	@Override
	public boolean requestLeave(String playerID) {
		
		boolean rc = new RemovePlayerController((MainJPanel)getGameContainer()).process(callback, fullName(playerID));
		rc = rc & super.requestLeave(playerID);
		return rc;
	}

	// when response comes in from remote client must make move on my local sudoku game
	@Override
	public boolean updateScores(Properties updatedScores, Properties updatedGame) {
		System.err.println("SERVER SENDS REMOVE MOVE NOT YET WORKING");;
		return false;
	}

	// WHEN local client makes a move in sudoku then request must go out to the server
	@Override
	public void updateState(Properties state, int score) {
		System.out.println("CLIENT MAKES MOVE LOCALLY: " + state);	
	}
}

package wordsteal.entities;

public enum ReqTilesPerTurn {

	Two,
	Three,
	Normal
	
}

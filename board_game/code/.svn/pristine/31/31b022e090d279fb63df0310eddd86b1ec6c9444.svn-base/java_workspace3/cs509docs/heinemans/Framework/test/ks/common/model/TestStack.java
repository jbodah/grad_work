package ks.common.model;

import junit.framework.TestCase;

public class TestStack extends TestCase {

	public void testBasic () {
		Stack st = new Stack();
		
		assertTrue (st.empty());
		assertEquals (0, st.count());
		
		// can't get from empty stack.
		assertTrue (st.get() == null);
		
		Card c = new Card (2, Card.HEARTS);
		st.add(c);
		assertEquals (1, st.count());
		assertFalse (st.empty());
		assertEquals (c, st.peek());
		assertEquals (c, st.get());
		assertTrue (st.empty());
	}
	
	public void testDescending() {
		Stack st = new Stack();
		assertTrue (st.descending());
		Card c3 = new Card (7, Card.HEARTS);
		Card c2 = new Card (6, Card.HEARTS);
		Card c1 = new Card (5, Card.HEARTS);
		Card cBad = new Card (10, Card.DIAMONDS);
		Card cBadDesc = new Card (9, Card.DIAMONDS);
		
		st.add(c3);
		assertTrue (st.descending());
		st.add(c2);
		assertTrue (st.descending());
		st.add(c1);
		assertTrue (st.descending());
		
		assertEquals (3, st.count());
		
		st.add(cBad);
		assertFalse (st.descending());
		
		// however... bottom three are descending
		assertTrue (st.descending(0,st.count()-1));
		
		st.add(cBadDesc);
		assertFalse (st.descending());
		
		// however... top most two cards are descending
		assertTrue (st.descending(3,5));
		
		// all same color
		assertTrue (st.sameColor());
	}
	
	public void testAscending() {
		Stack st = new Stack();
		assertTrue (st.ascending());
		Card c3 = new Card (2, Card.HEARTS);
		Card c2 = new Card (3, Card.HEARTS);
		Card c1 = new Card (4, Card.HEARTS);
		Card cBad = new Card (10, Card.SPADES);
		Card cBadDesc = new Card (11, Card.SPADES);
		
		st.add(c3);
		assertTrue (st.ascending());
		st.add(c2);
		assertTrue (st.ascending());
		st.add(c1);
		assertTrue (st.ascending());
		
		assertEquals (3, st.count());
		
		st.add(cBad);
		assertFalse (st.ascending());
		
		// however... bottom three are ascending and same color
		assertTrue (st.ascending(0,st.count()-1));
		assertTrue (st.sameColor(0,st.count()-1));
		
		st.add(cBadDesc);
		assertFalse (st.ascending());
		
		// however... top most two cards are ascending
		assertTrue (st.ascending(3,5));
	
		
		// same color
		assertTrue (st.sameColor(3,5));
	}
	
	public void testRank() {
		Stack st = new Stack();
		assertTrue (st.sameRank());
		try {
			st.rank();
			fail ("Can't return rank on empty stack.");
		} catch (Exception e) {
			// success
		}
		Card c3 = new Card (7, Card.HEARTS);
		Card c2 = new Card (6, Card.HEARTS);
		
		st.add(c3);
		assertEquals (7, st.rank());
		assertTrue (st.sameRank());
		st.add(c2);
		assertEquals (6, st.rank());
		
		assertFalse (st.sameRank());
		st.get(); // remove top card [6] and add another 7
		st.add(new Card (7, Card.DIAMONDS));
		assertTrue (st.sameRank());
	}
	
	public void testSuit() {
		Stack st = new Stack();
		assertTrue (st.sameSuit());
		try {
			st.suit();
			fail ("Can't return rank on empty stack.");
		} catch (Exception e) {
			// success
		}
		Card c3 = new Card (7, Card.HEARTS);
		Card c2 = new Card (6, Card.HEARTS);
		Card cBadDesc = new Card (9, Card.DIAMONDS);
		
		st.add(c3);
		assertEquals (Card.HEARTS, st.suit());
		assertTrue (st.sameSuit());
		st.add(c2);
		assertEquals (Card.HEARTS, st.suit());
		
		assertTrue (st.sameSuit());
		st.add (cBadDesc);
		assertFalse (st.sameSuit());
	}
	
	public void testAlternatingColors() {
		Stack st = new Stack();
		assertTrue (st.alternatingColors());
		
		Card c3 = new Card (7, Card.HEARTS);
		Card c2 = new Card (6, Card.SPADES);
		Card cBad = new Card (10, Card.DIAMONDS);
		Card cBadDesc = new Card (9, Card.CLUBS);
		
		st.add(c3);
		assertTrue (st.alternatingColors());
		st.add(c2);
		assertTrue (st.alternatingColors());
		st.add(cBadDesc);
		assertFalse (st.alternatingColors());
		st.add(cBad);
		assertFalse (st.alternatingColors());
		
		assertTrue (st.alternatingColors(3,4));
	}
	
	public void testSelectedStatus() {
		Stack st = new Stack();
		
		Stack s = st.getSelected();
		assertEquals (0, s.count());
		
		// can't select more than we have
		assertFalse (s.select());
		assertFalse (s.select(10));
		
		Card c3 = new Card (2, Card.HEARTS);
		Card c2 = new Card (3, Card.HEARTS);
		Card c1 = new Card (4, Card.HEARTS);
		Card cBad = new Card (10, Card.SPADES);
		Card cBadDesc = new Card (11, Card.SPADES);
		
		st.add(c3);
		st.add(c2);
		st.add(c1);
		st.add(cBad);
		st.add(cBadDesc);
		
		assertEquals (0, st.getNumSelectedCards());
		
		// now select
		assertTrue (st.select());
		assertEquals (1, st.getNumSelectedCards());
		
		s = st.getSelected();
		assertEquals (1, s.count());
		assertEquals (4, st.count());
		assertEquals (new Card (11, Card.SPADES), s.peek());
		
		// when multiple cards are selected, we must make sure that the 
		// retrieved 'selected stack' is formed in proper order.
		// stack now has 4 cards
		st.select(3);
		s = st.getSelected();
		assertEquals (3, s.count());
		assertEquals (new Card (3, Card.HEARTS), s.peek(0));  // bottom card
		assertEquals (new Card (4, Card.HEARTS), s.peek(1));  // bottom card
		assertEquals (new Card (10, Card.SPADES), s.peek(2));  // bottom card
		
		// none of these cards are selected anymore.
		assertEquals (0, s.getNumSelectedCards());
		
		st.select(1);  // last one
		s = st.getSelected();
		assertTrue (st.empty());
		assertEquals (1, s.count());
		
		s.select(1);
		s.deselect();
		assertEquals (0, s.getNumSelectedCards());
	}
	
	public void testPushAndManipulation() {
		Stack st = new Stack();
		st.removeAll();
		assertTrue (st.empty());
		
		st.add(new Card (2, Card.HEARTS));
		st.add(new Card (4, Card.HEARTS));
		
		Stack st2 = new Stack();
		
		
		// base case
		st.push(st2);
		assertEquals (2, st.count());
		
		st.push(null);
		assertEquals (2, st.count());
		
		// construct stack.
		st2.add(new Card (2, Card.SPADES));
		st2.add(new Card (4, Card.SPADES));
		
		
		// put these cards on top
		st.push(st2);
		assertEquals (4, st.count());
		
		assertEquals (new Card (4, Card.SPADES), st.peek());
		
		st.removeAll();
		assertTrue (st.empty());
	}
	
	// deal with large stacks
	public void testLargeStacks() {
		Stack st = new Stack();
		Card c = new Card (2, Card.HEARTS);
		for (int i = 0; i < 50; i++) {
			st.add(c);
		}
		
		assertEquals (50, st.count());
	}
	
	public void testToString() {
		Stack st = new Stack();
		assertEquals ("[Stack:<empty>]", st.toString());
		st.add (new Card (2, Card.HEARTS));
		assertEquals ("[Stack:2H]", st.toString());
		st.add (new Card (3, Card.HEARTS));
		assertEquals ("[Stack:2H,3H]", st.toString());
	}
	
}

package arch;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Properties;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import ks.client.game.GameManager;
import ks.client.interfaces.IGameInterface;
import ks.client.interfaces.ILobby;
import ks.client.interfaces.ILobbyInitialize;
import ks.client.lobby.LobbyFrame;

/**
 * My sample shows how to integrate the client code with the GameManager I am
 * providing.
 * 
 * Note: Don't edit this class here. Rather copy this sample code into your
 * own project and (1) rename it; and (2) modify as you need
 * 
 * @author George Heineman
 */
public class MyLobbyInitialization implements ILobbyInitialize, IGameInterface {
	
	/** Panels. */
	JPanel tmgui;
	JPanel umgui;
	
	/** Enclosing lobby. */
	ILobby lobby;
	
	public MyLobbyInitialization (JPanel tm, JPanel um) {
		this.tmgui = tm;
		this.umgui = um;
	}
	
	@Override
	public void initializeLobby(final LobbyFrame frame) {
		// remember this lobby for later use
		this.lobby = frame;
		
		// install the two manager GUIs and callback
		frame.setUserManagerGUI(umgui);
		frame.setTableManagerGUI(tmgui);
		frame.setLobbyInitialization(this);
		
		// callback object will likely need to know about things.
		frame.getContext();
		
		// grab the menu bar and make an update 
		JMenuBar menu = frame.getJMenuBar();
		JMenu help = new JMenu("Debug");
		JMenuItem game = new JMenuItem("sample solitaireGameWindow...");
		game.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				GameManager gm = GameManager.instance();
				Properties options = new Properties();
				// default ones from message
				options.setProperty("seed", "1234");
				options.setProperty("game", "heineman.Idiot");
				//options.setProperty("game", "heineman.Klondike");
				
				// game specific ones for solitaire variations.
				Properties gameOptions = new Properties();
				gameOptions.setProperty("time", "20");
				gameOptions.setProperty("undo", "true");
				gameOptions.setProperty("newHand", "true");
				
				// player ids and real names (example where one has no real name)
				Properties players = new Properties();
				players.setProperty("982", "George Heineman");
				//players.setProperty("1124", "Paul Simon");
				//players.setProperty("135", "");
				
				// forgot that Properties has no guaranteed ordering.
				ArrayList<String> order = new ArrayList<String>();
				order.add("982");
				//order.add("1124");
				//order.add("135");
				
				// request creation of game window. Will start automatically.
				gm.createGameWindow(13, "982", options, gameOptions, order, players, MyLobbyInitialization.this);
			}
			
		});
		help.add(game);
		
		// now wordsteal
		JMenuItem ws = new JMenuItem("sample wordSteal...");
		ws.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				GameManager gm = GameManager.instance();
				Properties options = new Properties();
				// default ones from message
				options.setProperty("seed", "1234");
				options.setProperty("game", "wordsteal.Wordsteal");
			
				// game specific ones for wordsteal variations. note
				// that the pointsToWin of 4 means any word played of
				// four or more letters will win the game.
				Properties gameOptions = new Properties();
				gameOptions.setProperty("noS", "true");
				gameOptions.setProperty("pink", "true");
				gameOptions.setProperty("turnTime", "10");
				gameOptions.setProperty("pointsToWin", "4");
				
				// player ids and real names (example where one has no real name)
				Properties players = new Properties();
				players.setProperty("982", "George Heineman");
				//players.setProperty("1124", "Paul Simon");
				//players.setProperty("135", "");
				
				// note that for the purpose of this demonstration, I am assuming
				// that I am the moderator. This need not be the case. Indeed, 
				// getting this bit of logic right will be a partnership between
				// myself and all other groups.
				
				// forgot that Properties has no guaranteed ordering.
				ArrayList<String> order = new ArrayList<String>();
				order.add("982");
				//order.add("1124");
				//order.add("135");
				
				// request creation of game window. Will start in locked mode.
				gm.createGameWindow(13, "982", options, gameOptions, order, players, MyLobbyInitialization.this);
				
				// go ahead and activate this person's turn (presumably as moderator).
				gm.activateTurn("982");
			}
		});
		help.add(ws);
		
		// now sudoku
		ws = new JMenuItem("sample sudoku...");
		ws.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				GameManager gm = GameManager.instance();
				Properties options = new Properties();
				// default ones from message
				options.setProperty("seed", "1234");
				options.setProperty("game", "sudoku.Sudoku");
			
				// game specific ones for sudoku variations. note
				// that the pointsToWin of 4 means any word played of
				// four or more letters will win the game.
				Properties gameOptions = new Properties();
				gameOptions.setProperty("difficulty", "2");
				
				// player ids and real names (example where one has no real name)
				Properties players = new Properties();
				players.setProperty("982", "George Heineman");
				//players.setProperty("1124", "Paul Simon");
				//players.setProperty("135", "");
				
				// note that for the purpose of this demonstration, I am assuming
				// that I am the moderator. This need not be the case. Indeed, 
				// getting this bit of logic right will be a partnership between
				// myself and all other groups.
				
				// forgot that Properties has no guaranteed ordering.
				ArrayList<String> order = new ArrayList<String>();
				order.add("982");
				//order.add("1124");
				//order.add("135");
				
				// request creation of game window. Will start in locked mode.
				gm.createGameWindow(13, "982", options, gameOptions, order, players, MyLobbyInitialization.this);
				
			}
		});
		help.add(ws);
		
		
		JMenuItem cons = new JMenuItem("Show consolidated controller...");
		cons.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				new ConsolidatedClientProfileController(lobby).process();
			}
			
		});
		help.add(cons);
		
		
		menu.add(help);
	}

	@Override
	public void sendTableChat(int tableID, String text) {
		System.err.println("Table Chat request:" + text);	
		System.err.println("Do something about it!");
	}

	@Override
	public void update(int tableID, int score, String game, boolean complete) {
		System.err.println("Update request:" + score + ", complete=" + complete);
		System.err.println("Do something about it!");
	}

	@Override
	public void leaveGame(int tableID) {
		System.err.println("Player leaves table " + tableID);
		System.err.println("Do something about it!");
	}

	@Override
	public void turn(int tableID, Properties scores, String move, boolean complete) {
		System.err.println("Player makes move, complete=" + complete);
		System.err.println("Move:" + move);
		for (Object p : scores.keySet()) {
			String value = scores.getProperty((String)p);
			System.err.println("player " + p + ", score=" + value);
		}
		System.err.println("Do something about it!");
	}

	@Override
	public void skip(int tableNumber) {
		System.err.println("Player has skipped on table " + tableNumber);
		System.err.println("Do something about it!");
	}

	@Override
	public void connected(boolean status) {
		if (!status) {
			lobby.append("Server connection lost");
		} else {
			lobby.append("My Initializer welcomes you");
		}
		
	}
}

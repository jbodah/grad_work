package wordsteal.util;

public class BoardLocation {
	
	public final int row;
	public final int col;
	
	public BoardLocation(int row, int col) {
		this.row = row;
		this.col = col;
	}
	
	/**
	 * Extract board location information from (row/col).
	 * 
	 * @param s
	 */
	public BoardLocation(String s) {
		int left = 1;
		int mid = s.indexOf('/');
		int right = s.indexOf(')', mid);
		row = Integer.valueOf(s.substring(left, mid));
		col = Integer.valueOf(s.substring(mid+1, right));
	}
	
	public String toString() {
		return "<" + row + "," + col + ">";
	}
	
	public int hashCode() {
		return this.row + this.col;
	}
	
	public boolean equals(Object o) {
		BoardLocation bl = (BoardLocation)o;
		if(bl != null &&
		   this.row == bl.row &&
		   this.col == bl.col) {
			return true;
		} else {
			return false;
		}
	}
}

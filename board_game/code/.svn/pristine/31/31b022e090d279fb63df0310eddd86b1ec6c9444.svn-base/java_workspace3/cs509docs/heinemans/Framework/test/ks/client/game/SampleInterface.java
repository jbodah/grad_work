package ks.client.game;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

import ks.client.interfaces.IGameInterface;

/**
 * Sample interface used exclusively for testing purposes.
 * <p>
 * Each 'element' in the queue is tagged with a ID: prefix
 * and then the rest of the info comes after that.
 * <p>
 * You can dequeue messages from this queue to reflect the order of 
 * events from this point of view. 
 * 
 * @author George Heineman
 */
public class SampleInterface implements IGameInterface {
	
	String[] prefixes = { "TableChat:", "Update:", "LeaveGame:", "Turn:", "Skip:" };
	
	/** Queue of actions. */
	ArrayList<String> queue = new ArrayList<String>(); 
	
	
	@Override
	public void sendTableChat(int tableID, String text) {
		synchronized (queue) {
			queue.add(prefixes[0] + tableID + "," + text);
		}		
	}

	@Override
	public void update(int tableID, int score, String game, boolean complete) {
		synchronized (queue) {
			queue.add(prefixes[1] + tableID + "," + score + "," + game + "," + complete);
		}	
	}

	@Override
	public void leaveGame(int tableID) {
		synchronized (queue) {
			queue.add(prefixes[2] + tableID );
		}	
	}

	@Override
	public void turn(int tableID, Properties scores, String move, boolean complete) {
		
		// linearize the scores.
		String sc = "[";
		for (Enumeration<?> en = scores.keys(); en.hasMoreElements(); ) {
			String key = (String) en.nextElement();
			String value = (String) scores.getProperty(key);
			sc += key + "," + value;
			if (en.hasMoreElements()) { sc += ","; }
		}
		
		sc += "]";
		synchronized (queue) {
			queue.add(prefixes[3] + tableID + "," + move + "," + complete + "," + sc);
		}	
	}

	@Override
	public void skip(int tableID) {
		synchronized (queue) {
			queue.add(prefixes[4] + tableID );
		}	
	}
	
	public boolean isSkip (String s) { 
		return s.startsWith(prefixes[4]);
	}

	/** retrieve the next string in the queue. */
	public String dequeue() {
		
		synchronized (queue) {
			return queue.remove(0);
		}
		
	}

	public boolean isTurn(String s) {
		return s.startsWith(prefixes[3]);
	}

	public boolean isUpdate(String s) {
		return s.startsWith(prefixes[1]);
	}
}

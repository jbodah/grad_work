package ks.server.controllers;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.server.interfaces.IProcessServerMessage;

/**
 * Generic ControllerChain registered with server-side processor.
 * 
 * This class enables us to design a "Chain of Responsibilities" where 
 * extensibility is gained by appending additional agents to a list.
 * The processor locates the first controller in the chain that handles
 * the given message.
 * 
 * @author George Heineman
 */
public class ServerControllerChain implements IProcessServerMessage {

	/** The next agent in the chain. */
	protected ServerControllerChain next;
	
	/** 
	 * The terminal agent in the chain is constructed using this constructor.
	 */
	public ServerControllerChain () {
		
	}

	/** 
	 * Helper function for constructing chain by appending given agent as the next
	 * one to execute.
	 * 
	 * @param next   Next agent to manage controllers.
	 */
	public ServerControllerChain (ServerControllerChain next) {
		this();
		append(next);
	}
	
	/**
	 * Add agent to be the last one in the controller chain.
	 * 
	 * @param agent
	 */
	public void append (ServerControllerChain agent) {
		if (next == null) {
			next = agent;
			return;
		} 
		
		// append to next.
		next.append(agent);
	}
	
	/**
	 * Appeal to the next agent in the chain to process given message.
	 * 
	 * If there is no such agent then false is returned, otherwise that 
	 * agent is directed to process the message
	 * 
	 * @param com  {@link Communicator} from which message came
	 * @param m    {@link Message} object to be processed.
	 * @return <code>true</code> if someone took ownership of the message otherwise <code>false</code>
	 * 
	 */
	protected boolean next(Communicator com, Message m) {
		if (next == null) {
			return false;
		}
		
		return next.process(com, m);
	} 
	
	/**
	 * An agent in the chain processes the message if it can, but if not
	 * then the next agent in the chain has its turn.
	 * 
	 * Entities that extend this class should override this method appropriately.
	 */
	@Override
	public boolean process(Communicator com, Message m) {
		return next(com, m);
	} 
	
}

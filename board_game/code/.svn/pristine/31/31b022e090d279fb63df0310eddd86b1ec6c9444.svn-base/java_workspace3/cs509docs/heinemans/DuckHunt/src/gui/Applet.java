package gui;

import controller.CreateController;

/**
 * Applet for encapsulating the DuckHunt game within a browser.
 * 
 * @author heineman
 **/
public class Applet extends java.applet.Applet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8298684580527809616L;

	/**
	 * Construct the applet
	 * 
	 */
	public Applet() {
		super();
		
	}

	/**
	 * Initialize the game.
	 * 
	 * Use a CreateController to properly add the relevant GUI items to the screen.
	 */
	public void init() {
        this.setSize(new java.awt.Dimension(638,542));
			
		// set things up, according to the creation controller.
		CreateController controller = new CreateController();
			this.setBackground(java.awt.Color.lightGray);
			this.setLayout(null);
		add(controller.createPlayingArea(), null);
		add(controller.createStartButton(), null);
	}

}  //  @jve:decl-index=0:visual-constraint="10,10"

package ks.framework.common;

import ks.framework.debug.Debug;

/**
 * SAX parser needs an error handler. This satisfies.
 */
class MyErrorHandler implements org.xml.sax.ErrorHandler {

	/** Creates a new instance of MyErrorHandler */
	public MyErrorHandler() { }

	public void error(org.xml.sax.SAXParseException sAXParseException) throws org.xml.sax.SAXException {
		Debug.println("ERROR: " + sAXParseException.toString());
	}

	public void fatalError(org.xml.sax.SAXParseException sAXParseException) throws org.xml.sax.SAXException {
		Debug.println("FATAL ERROR: " + sAXParseException.toString());
	}

	public void warning(org.xml.sax.SAXParseException sAXParseException) throws org.xml.sax.SAXException {
		Debug.println("WARNING: " + sAXParseException.toString());
	}

}

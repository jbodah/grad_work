package controller;

import gui.Main;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


/**
 * Launch a stand-alone application version of the game.
 * @author heineman
 *
 */
public class Launcher {
	public static void main (String args[]) {
		final Main m = new Main();
		CreateController controller = new CreateController();
		
		// set things up, according to the creation controller.
		m.setup (controller);
		
		// Set up the window listener 
		m.addWindowListener(new WindowAdapter() {

			public void windowClosing(WindowEvent e) {
				m.setVisible (false);
				System.exit(0);
			}

			public void windowClosed(WindowEvent e) {
				m.setVisible (false);
				System.exit(0);
			}
		});

		// get things GOING!
		m.setVisible(true);
	}
}

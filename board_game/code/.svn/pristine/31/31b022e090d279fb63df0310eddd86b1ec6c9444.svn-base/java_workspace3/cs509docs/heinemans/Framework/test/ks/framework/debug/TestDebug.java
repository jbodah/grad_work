package ks.framework.debug;

import junit.framework.TestCase;

public class TestDebug extends TestCase {
	public void testDebug() {
		Debug.print("testing");
		Debug.setDebugging(true);
		Debug.println("testing");
		Debug.setDebugging(false);
		Debug.print("testing");		
		Debug.setDebugging(true);
		Debug.print("testing");
	}
}

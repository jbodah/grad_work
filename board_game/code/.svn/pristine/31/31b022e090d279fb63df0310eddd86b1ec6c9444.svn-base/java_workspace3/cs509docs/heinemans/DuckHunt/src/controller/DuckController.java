package controller;

import gui.DuckCanvas;

import java.awt.Dimension;
import java.awt.Point;
import java.util.Iterator;

import state.Duck;
import state.GameState;

/**
 * Responsible for updating the duck positions, in timely fashion.
 * 
 * Needs to know of the canvas so it can properly bounce the ducks around
 * and then refresh as needed.
 * 
 * @author George
 */
public class DuckController {
	
	/** State of the game. */
	GameState state;
	
	/** Canvas within which to play. */
	DuckCanvas canvas;
	
	/** Updater. */
	UpdateThread updater;
	
	/** Is the game active? */
	boolean active = false;
	
	/**
	 * Operate ducks within the given Canvas and game state.
	 * 
	 * @param canvas
	 * @param state
	 */
	public DuckController (DuckCanvas canvas, GameState state) {
		this.canvas = canvas;
		this.state = state;
	}
	
	// updater.
	class UpdateThread extends Thread {
		public void run () {
			while(active) {
				
				// pause between movement.
				try {
					Thread.sleep (100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			
				for (Iterator<Duck> it = state.getDucks(); it.hasNext(); ) {
					Duck d = it.next();
					if (d.isAlive()) {
						Point p = d.getLocation();
						Dimension dm = d.getMovement();
						p.x += dm.width;
						p.y += dm.height;
					
						if (p.x < 0) {
							p.x -= dm.width;
							dm.width = - dm.width;   // bounce off wall.
						} else if (p.x + d.getWidth() > canvas.getWidth()) {
							p.x -= dm.width;
							dm.width = -dm.width;
						} 
						
						if (p.y < 0) {
							p.y -= dm.height;
							dm.height = -dm.height;
						} else if (p.y + d.getHeight() > canvas.getHeight()) {
							p.y -= dm.height;
							dm.height = -dm.height;
						} 

						d.setLocation(p);
						d.setMovement(dm);
					}
				}
				
				// force a redraw.
				canvas.redrawState();
			}
		}
	}

	
	/**
	 * Start things off.
	 */
	public void begin() {
		active = true;
		updater = new UpdateThread();
		updater.start();
	}
	
	/**
	 * Complete the game.
	 */
	public void complete() {
		active = false;
	}
}

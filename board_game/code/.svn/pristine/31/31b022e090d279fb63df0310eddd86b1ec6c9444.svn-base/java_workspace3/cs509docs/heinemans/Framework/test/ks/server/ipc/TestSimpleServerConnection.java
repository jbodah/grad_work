package ks.server.ipc;

import junit.framework.TestCase;
import ks.server.ipc.Server;

// show that two servers trying to start with same port
// will cause second to fail
public class TestSimpleServerConnection extends TestCase {
	
	// helper function to sleep for a second.
	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	public void testBadServers() {
		Server s = new Server (9998);
		assertTrue (s.activate());
		
		waitASecond();
		waitASecond();
		assertTrue (s.listener.isRunning());
		
		Server bad = new Server(9998);
		assertFalse (bad.activate());
		
		waitASecond();
		
		s.deactivate();
		waitASecond();
		assertTrue(s.listener == null);
	}
	
	// Note: if you have left your server running on the default 
	// port, then this will fail. Make sure you exit all servers
	// prior to running this test case.
	public void testBadServersDefault() {
		Server s = new Server ();
		assertTrue (s.activate());
		
		waitASecond();
		waitASecond();
		assertTrue (s.listener.isRunning());
		
		Server bad = new Server();
		assertFalse (bad.activate());
		
		waitASecond();
		
		s.deactivate();
		waitASecond();
		assertTrue(s.listener == null);
	}
	
	
	public void testNormalServer() {
		Server s = new Server (9998);
		assertTrue (s.activate());
		
		waitASecond();
		waitASecond();
		assertTrue (s.listener.isRunning());
		
		Server bad = new Server(9998);
		assertFalse (bad.activate());
		
		waitASecond();
		
		s.deactivate();
		waitASecond();
		assertTrue(s.listener == null);
	}
}

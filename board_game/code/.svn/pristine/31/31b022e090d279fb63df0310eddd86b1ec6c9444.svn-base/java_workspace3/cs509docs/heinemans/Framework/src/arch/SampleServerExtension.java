package arch;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.server.controllers.ChatController;
import ks.server.controllers.ServerControllerChain;

public class SampleServerExtension extends ServerControllerChain {
	/**
	 * This extension understands "getProfile" as a start
	 */
	@Override
	public boolean process(Communicator com, Message m) {
		if (m.getName().equals ("getProfile")) {
			return new SampleServerController().process(com, m);
		}
		
		// try the next one in the chain...
		return next (com, m);
	}
}

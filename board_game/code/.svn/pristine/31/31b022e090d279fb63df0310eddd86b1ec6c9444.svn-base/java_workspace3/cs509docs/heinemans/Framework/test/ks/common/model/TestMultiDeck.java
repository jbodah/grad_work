package ks.common.model;

import junit.framework.TestCase;

// nothing much to test since logic is internalized.
public class TestMultiDeck extends TestCase {

	public void testConstruct() {
		// invalid
		try {
			new MultiDeck(-4);
			fail("Can't allow negative argument to MultiDeck.");
		} catch (Exception e) {
			
		}
		
		
		Deck d = new MultiDeck("sample", 2);
		d.create(97);
		
		Deck d2 = new MultiDeck("sample", 2);
		d2.create(97);
		
		// assert all cards are the same
		while (!d.empty()) {
			Card c = d.get();
			Card c2 = d2.get();
			
			assertEquals (c, c2);
		}
		
		assertTrue (d2.empty());
	}
	
	// however, there are two special deals: -1 (OrderByRank) and -2 (OrderBySuit)
	public void testSpecial() {
		Deck d = new MultiDeck("sample", 1);
		d.create(-1);
		assertEquals (52, d.count());
		
		// get four and all same rank
		while (!d.empty()) {
			Card []cards = { d.get(), d.get(), d.get(), d.get() };
			
			for (int i=  1; i < cards.length; i++) {
				assertTrue (cards[0].sameRank(cards[i]));
			}
		}
		
		d = new MultiDeck(2);
		d.create(-2);
		assertEquals (104, d.count());
		
		// get four and all same suit
		while (!d.empty()) {
			Card []cards = { d.get(), d.get(), d.get(), d.get(), d.get(), d.get(), d.get(), d.get(), d.get(), d.get(), d.get(), d.get(), d.get() };
			
			for (int i=  1; i < cards.length; i++) {
				assertTrue (cards[0].sameSuit(cards[i]));
			}
		}
	}
	
	
}

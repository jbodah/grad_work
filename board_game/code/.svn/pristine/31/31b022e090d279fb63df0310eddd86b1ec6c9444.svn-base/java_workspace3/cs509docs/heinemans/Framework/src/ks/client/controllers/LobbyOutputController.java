package ks.client.controllers;

import org.w3c.dom.Node;

import ks.client.interfaces.ILobby;
import ks.client.interfaces.ILobby2;
import ks.client.interfaces.IProcessClientMessage;
import ks.framework.common.Message;

/**
 * Shows how to process Output requests from server.
 * 
 * @author George Heineman
 */
public class LobbyOutputController implements IProcessClientMessage {

	/** Process message. */
	public boolean process(ILobby lobby, Message m) {
		Node output = m.contents();
		
		// retrieve high-level attribute value, if it exists, otherwise
		// null is returned.
		String from = m.getAttribute("from");
		String txt = output.getTextContent();
		if (from == null) {
			// it is optional so this could be from the system
			lobby.append(txt);
		} else {
			boolean publicMessage;
			
			if (m.getAttribute("public") != null) {
				publicMessage = m.getAttribute("public").equals("true"); // CHANGED!...
			}
			else {
				publicMessage = true;
			}
			
			// pre-pend from id.
			if (lobby instanceof ILobby2) {
				((ILobby2)lobby).append(from, txt, publicMessage); // CHANGED!
			}
			else {
				lobby.append(txt);
			}
		}
		
		return true;
	}

}

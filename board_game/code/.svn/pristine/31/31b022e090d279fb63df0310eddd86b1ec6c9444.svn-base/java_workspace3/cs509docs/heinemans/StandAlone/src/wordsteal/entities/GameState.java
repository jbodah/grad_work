package wordsteal.entities;

import java.util.ArrayList;
import java.util.Hashtable;


/**
 * Class representing the current game state
 * @author Dan
 *
 */
public class GameState {
	
	/** Requires a handle to the game */
	Game game = null;
	
	/** The current player who has the turn */
	int activePlayer = 0;
	
	/** The points held by all players currently in the game */
	Hashtable<Integer, Integer> playerPoints  = new Hashtable<Integer, Integer>();
	
	/** The bonus points held by all players currently in the game */
	Hashtable<Integer, Integer> playerBonuses  = new Hashtable<Integer, Integer>();
	
	/** The new words created on the board this turn */
	ArrayList<String> newWords = null;
	
	/** The amount of time the player has left in their turn */
	int playerTime = 0;
	
	/** The status message resulting from the turn */
	String playerAction = null;
	
	/**
	 * Constructor, creates new GameState object and sets its fields
	 */
	public GameState(Game g, String status, int time, ArrayList<String> words) {
		this.game = g;
		this.playerAction = status;	
		this.playerTime = time;
		this.newWords = words;
		
		// Get the current active player and save that player in the game state
		//this.activePlayer = this.getGame().getCurrentPlayer();
		
		// Save all of the current player points
		for (int i = 0; i < this.game.getPlayers().size(); i++) {
			playerPoints.put(i, this.game.getPlayers().get(i).getPoints());
		}
		
		// Save all of the current player bonus points
		for (int i = 0; i < this.game.getPlayers().size(); i++) {
			playerBonuses.put(i, this.game.getPlayers().get(i).getBonusPoints());
		}
		
	}	
	
	/**
	 * returns the current game
	 * @return
	 */
	public Game getGame() {
		return game;
	}
	
	/**
	 * Returns the active player in this game state
	 * @return
	 */
	public int getActivePlayer() {
		return activePlayer;
	}

	/**
	 * Sets the active player in this game state
	 * @param activePlayer
	 */
	public void setActivePlayer(int activePlayer) {
		this.activePlayer = activePlayer;
	}

	/**
	 * Returns the hash table with all of the player points in this game state
	 * @return
	 */
	public Hashtable<Integer, Integer> getPlayerPoints() {
		return playerPoints;
	}

	/**
	 * Sets the hash table with all of the player points in this game state
	 * @param playerPoints
	 */
	public void setPlayerPoints(Hashtable<Integer, Integer> playerPoints) {
		this.playerPoints = playerPoints;
	}

	/**
	 * Returns the hash table with all of the player bonuses in this game state
	 * @return
	 */
	public Hashtable<Integer, Integer> getPlayerBonuses() {
		return playerBonuses;
	}

	/**
	 * Sets the hash table with all of the player bonuses in this game state
	 * @param playerBonuses
	 */
	public void setPlayerBonuses(Hashtable<Integer, Integer> playerBonuses) {
		this.playerBonuses = playerBonuses;
	}

	/**
	 * Returns the array list of new words created by the player in this game state
	 * @return
	 */
	public ArrayList<String> getNewWords() {
		return newWords;
	}

	/**
	 * Returns the amount of time left for the player in this game state
	 * @return
	 */
	public int getPlayerTime() {
		return playerTime;
	}

	/**
	 * Returns a string containing the action performed during this turn
	 * @return
	 */
	public String getPlayerAction() {
		return playerAction;
	}
	
}

package ks.client.game;

import java.util.ArrayList;
import java.util.Properties;

import junit.framework.TestCase;

public class TestGameInformation extends TestCase {

	Properties props;
	Properties options;
	GameInformation game;
	
	/** Create Klondike variations. */
	protected void setUp() {
		props  = new Properties();
		String s = "heineman.Klondike";
		props.setProperty("game", s);
		
		options = new Properties();
	}
	
	public void testSeed() {
		props.setProperty("seed", "17");
		game = Factory.create(props, options);
		
		assertEquals (17, game.seed);
	}
	
	public void testBadSeed() {
		props.setProperty("seed", "asdadsad");
		try {
			game = Factory.create(props, options);
			fail ("should prevent invalid seed.");
		} catch (Exception e) {
			// success
		}
	}
	
	public void testDefaultSeed() {
		game = Factory.create(props, options);
		
		assertEquals (GameInformation.defaultSeed, game.seed);
	}
	
	public void testPlayers() {
		game = Factory.create(props, options);
		
		assertEquals (GameInformation.defaultSeed, game.seed);
		
		Properties players = new Properties();
		players.setProperty("982", "George Heineman");
		players.setProperty("1124", "Paul Simon");
		players.setProperty("135", "");
		
		// forgot that Properties has no guaranteed ordering.
		ArrayList<String> order = new ArrayList<String>();
		order.add("982");
		order.add("1124");
		order.add("135");
		
		game.setPlayers(order, players);
		
		assertEquals ("George Heineman", game.players.getProperty("982"));
	}
	
	public void testName() {
		game = Factory.create(props, options);
		game.setCurrentUser("me");
		assertEquals ("me", game.player);
	}
	
}

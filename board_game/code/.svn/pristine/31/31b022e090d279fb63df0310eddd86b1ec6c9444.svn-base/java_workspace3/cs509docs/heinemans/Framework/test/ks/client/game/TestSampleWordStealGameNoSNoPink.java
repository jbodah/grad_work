package ks.client.game;

import java.util.ArrayList;
import java.util.Properties;

import com.sun.org.apache.xpath.internal.axes.SelfIteratorNoPredicate;

import wordsteal.boundaries.main.MainJPanel;
import wordsteal.entities.Board;
import wordsteal.entities.Cell;
import wordsteal.entities.Game;
import wordsteal.entities.Rack;
import wordsteal.entities.RackTileLocation;
import wordsteal.entities.Tile;
import wordsteal.entities.TileMovement;
import wordsteal.interfaces.IWordstealApp;
import wordsteal.util.BoardLocation;

import junit.framework.TestCase;
import ks.client.game.wordsteal.SkipSelfTurnController;
import ks.client.game.wordsteal.SubmitWordController;
import ks.client.game.wordsteal.WordstealGameInformation;

public class TestSampleWordStealGameNoSNoPink extends TestCase {

	GameManager gm;
	
	int tableID = 13;
	String me = "982";
	Properties options;
	Properties gameOptions;
	Properties playerIDs;
	SampleInterface sample;
	
	String player1 = "1124";
	String player2 = "997";
	
	/** My info. */
	WordstealGameInformation info;
	
	/** internal info. */
	Game game;
	
	// create the wordsteal game/app
	protected void setUp() {
		gm = GameManager.instance();
		Properties options = new Properties();
		// default ones from message
		options.setProperty("seed", "1234");
		options.setProperty("game", "wordsteal.Wordsteal");
	
		sample = new SampleInterface();
		
		// game specific ones for wordsteal variations. note
		// that the pointsToWin of 4 means any word played of
		// four or more letters will win the game.
		Properties gameOptions = new Properties();
		gameOptions.setProperty("noS", "true");
		gameOptions.setProperty("pink", "false");
		gameOptions.setProperty("turnTime", "80");
		
		// make score low enough that we can actually win a game, but
		// high enough that we can try it out
		gameOptions.setProperty("pointsToWin", "10");
		
		// player ids and real names (example where one has no real name)
		Properties players = new Properties();
		players.setProperty(me,  "George Heineman");
		players.setProperty(player1, "Paul Simon");
		players.setProperty(player2,  "");
		
		// note that for the purpose of this demonstration, I am assuming
		// that I am the moderator. This need not be the case. Indeed, 
		// getting this bit of logic right will be a partnership between
		// myself and all other groups.
		
		// forgot that Properties has no guaranteed ordering.
		ArrayList<String> order = new ArrayList<String>();
		order.add("982");
		order.add(player1);
		order.add(player2);
		
		// request creation of game window. Will start in locked mode.
		assertTrue (gm.createGameWindow(tableID, me, options, gameOptions, order, players, sample));
		
		// extract constructed info.
		info = (WordstealGameInformation) gm.frame.getGameInformation();
		MainJPanel mjp = (MainJPanel) info.getGameContainer();
		game = mjp.getGame();
	}
	
	protected void tearDown() {
		gm.frame.setVisible(false);
		gm.frame.dispose();
	}
	
	/**
	 * Test a sample game.
	 * 
	 * Using seed '1234' 
	 */
	public void testSample() {
		
		// me (0) starts as moderator
		gm.activateTurn(me); 
		assertEquals (3, info.players.size());
		//assertEquals (0, game.getCurrentPlayer()); 

		// me: manually skip turn
		new SkipSelfTurnController((IWordstealApp) info.getGameContainer()).process((WordstealGameInformation)gm.frame.info, sample);
		
		// assert message retrieved ONLY for our turn.
		String s = sample.dequeue();
		assertTrue (sample.isSkip(s));
		
		// we have advanced 
		//assertEquals (1, game.getCurrentPlayer()); 
		
		// player1: place initial SHOE
		assertTrue (gm.makeTurn(player1, "(6/8)=E,(6/7)=O,(6/6)=H"));
		
		// player 2 turn
		place("S", new BoardLocation(6, 9));
		place("A", new BoardLocation(5, 9));
		place("H", new BoardLocation(7, 9));
		
		// now issue move. This should fail because of noS
		assertFalse (new SubmitWordController((IWordstealApp) info.getGameContainer()).process(info, sample));
		
		// player1: the above has advanced turn as well as reset timer
		//assertEquals (2, game.getCurrentPlayer());
		assertTrue (gm.makeTurn(player1, "(6/5)=S,(5/5)=A,(7/5)=H"));
		
		// me: back to original player. We manually activate just as would be done
		// in live version. Note that because we use makeTurn there is no subsequent
		// turn message emitted.
		//assertEquals (0, game.getCurrentPlayer());
		gm.activateTurn(me); 
		gm.makeTurn(me, "(5/8)=I,(4/8)=L");
		
		// player1: now player1 turn
		//assertEquals (1, game.getCurrentPlayer());

		// player1: Instead, let's interrupt and state that player2 
		gm.requestLeave(player2);
		
		// player1: this doesn't affect total number of people on the game.
		assertEquals (2, info.players.size());
		
		// player1: player2 is now inactive
		assertTrue (game.isInactive(2));
		
		// player1: skip turn
		assertTrue(gm.skipTurn(player1));
		
		// now moved on over to me (skipping now defunct player2).
		//assertEquals (0, game.getCurrentPlayer());
		gm.activateTurn(me); 

		// this makes a bunch of simply invalid moves

		place("U", new BoardLocation(6, 10));
		place("O", new BoardLocation(7, 10));
		place("A", new BoardLocation(8, 10));
		
		// now issue move. This should fail because of noS
		assertFalse (new SubmitWordController((IWordstealApp) info.getGameContainer()).process(info, sample));
	}

	private void place(String letter, BoardLocation location) {
		Board b = game.getBoard();
		Rack r = game.getRack();
		ArrayList<Tile> tiles = r.getTiles();
		for (Tile t : tiles) {
			if (t.letter.equals(letter)) {
				
				Cell cell = b.getCell(location);
				cell.setTile(t);
					
				RackTileLocation rackLocation = new RackTileLocation(r.getTiles().indexOf(t), r);
				TileMovement movement = new TileMovement(rackLocation, rackLocation);
				
				game.getUndoManager().pushMovement(movement);
				r.removeTile(t);
				break;
			}
		}
	}
	
}

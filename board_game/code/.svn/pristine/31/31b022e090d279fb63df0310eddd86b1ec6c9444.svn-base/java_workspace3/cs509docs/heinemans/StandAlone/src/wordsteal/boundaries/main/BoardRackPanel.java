package wordsteal.boundaries.main;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Iterator;


import javax.swing.JPanel;

import wordsteal.entities.Cell;
import wordsteal.entities.Tile;
import wordsteal.interfaces.IWordstealApp;


/**
 * This class is responsible for drawing the game board, rack, and tiles
 * @author Zach
 *
 */
public class BoardRackPanel extends JPanel {

	/** Version number */
	private static final long serialVersionUID = 1L;
	
	/** 
	 * Array representation of the board.
	 * 0 means white, 1 means green, 2 means pink, and 3 means orange
	 */
	public static final int[][] boardStructure = {{2,0,0,0,0,0,2,0,0,0,0,0,2},
												  {0,0,0,0,0,3,0,3,0,0,0,0,0},
												  {0,0,0,0,3,0,0,0,3,0,0,0,0},
												  {0,0,0,3,0,0,0,0,0,3,0,0,0},
												  {0,0,3,0,0,0,0,0,0,0,3,0,0},
												  {0,3,0,0,0,0,0,0,0,0,0,3,0},
												  {2,0,0,0,0,0,1,0,0,0,0,0,2},
												  {0,3,0,0,0,0,0,0,0,0,0,3,0},
												  {0,0,3,0,0,0,0,0,0,0,3,0,0},
												  {0,0,0,3,0,0,0,0,0,3,0,0,0},
												  {0,0,0,0,3,0,0,0,3,0,0,0,0},
												  {0,0,0,0,0,3,0,3,0,0,0,0,0},
												  {2,0,0,0,0,0,2,0,0,0,0,0,2}};
	
	/** Number of cells in each row/column of the board */
	public static final int numBoardCells = boardStructure.length;
	
	/** Number of slots in the rack */
	public static final int numRackCells = 7;
	
	/** Length and width in pixels of a cell on the board */
	public static final int boardCellLength = 30;
	
	/** Length and width of the entire board */
	public static final int boardLength = boardCellLength * numBoardCells;
	
	/** Space in pixels from edge of panel to start of board */
	public static final int boardOffsetX = 5;
	
	/** Space in pixels from top of panel to start of board */
	public static final int boardOffsetY = 0;
	
	/** Size of font for a board tile */
	public static final int boardTileFontSize = 24;
	
	/** Offset in pixels from edge of tile to letter drawn on it */
	public static final int boardTileLetterXOffset = 11;
	
	/** Offset in pixels from bottom of tile to letter drawn on it */
	public static final int boardTileLetterYOffset = 20;
	
	/** Width in pixels of the rack */
	public static final int rackWidth = boardLength;
	
	/** Spacing in pixels between tiles on rack */
	public static final int rackSpacing = rackWidth / 100;
	
	/** Length and width of tiles on the rack */
	public static final int rackTileLength = (rackWidth - rackSpacing * (numRackCells + 1)) /
												numRackCells;
	/** Height of rack in pixels */
	public static final int rackHeight = rackTileLength + rackSpacing * 2;
	
	/** X position of rack */
	public static final int rackPositionX = boardOffsetX;
	
	/** Y position of rack */
	public static final int rackPositionY = boardOffsetY + boardLength;
	
	/** Font size of letters drawn on tiles in the rack */
	public static final int rackTileFontSize = 48;
	
	/** Offset in pixels from edge of tile to letter drawn on it */
	public static final int rackTileLetterXOffset = 20;
	
	/** Offset in pixels from bottom of tile to letter drawn on it */
	public static final int rackTileLetterYOffset = 47;
	
	/** Preferred width of entire panel */
	public static final int boardRackPanelPreferredWidth = boardOffsetX + boardLength;
	
	/** Preferred height of entire panel */
	public static final int boardRackPanelPreferredHeight = boardOffsetY + boardLength + rackHeight;
	
	/** Handle to mainframe maintained by the panel */
	IWordstealApp mainFrame = null;
	
	/** Decorator for the board */
	IDrawLayer drawBoard;
	
	/** Decorator for the rack */
	IDrawLayer drawRack;
	
	/** Decorator for the tiles on the board */
	IDrawLayer drawTilesOnBoard;
	
	/** Decorator for the tiles on the rack */
	IDrawLayer drawTilesOnRack;
	
	/** Decorator for the tile currently grabbed by the player */
	IDrawLayer drawGrabbedTile;

	/** Decorator description. */
	private String description;
	
	@Override
	public void paint(Graphics g) {
		
		super.paint(g);
		
		Graphics2D g2D = (Graphics2D) g;
	
		// Draw decorator chain
		drawBoard.draw(g2D);
	}


	/**
	 * Constructor
	 * @param mf Handle to main application object
	 */
	public BoardRackPanel(IWordstealApp mf) {
		
		super();
		
		this.mainFrame = mf;
		
		// Setup decorator chain
		drawGrabbedTile = new DrawGrabbedTile(null, this);
		drawTilesOnRack = new DrawTilesOnRack(drawGrabbedTile, this);
		drawTilesOnBoard = new DrawTilesOnBoard(drawTilesOnRack, this);
		drawRack = new DrawRack(drawTilesOnBoard, this);
		drawBoard = new DrawBoard(drawRack, this);
		
		description = drawBoard.getDescription();
	}
	
	/**
	 * 
	 * @return Handle to the main application object
	 */
	public IWordstealApp getMainFrame() {
		return this.mainFrame;
	}
	
	/**
	 * Determines if a given coordinate (relative to the panel) is within the
	 * board object
	 * @param x X position of the point
	 * @param y Y position of the point
	 * @return Whether or not the point is within the board object
	 */
	public boolean isWithinBoard(int x, int y) {
		
		return BoardRackPanel.getBoardRect().contains(x, y);
	}
	
	/**
	 * Determines if a given coordinate (relative to the panel) is within the
	 * 
	 * @param x X position of the point
	 * @param y Y position of the point
	 * @return Whether or not the point is within the rack object
	 */
	public boolean isWithinRack(int x, int y) {
		
		return BoardRackPanel.getRackRect().contains(x, y);
	}
	
	/**
	 * Determines if the given coordinate (relative to the panel) is within the
	 * game area (rack + board). This method assumes that a tile is currently
	 * grabbed by the player, which means this point (the mouse position) will
	 * be in the middle of the tile. Thus, this method makes sure that the entire
	 * tile with center x,y is within the game bounds.
	 * @param x X position of the point
	 * @param y Y position of the point
	 * @return Whether or not the tile is within the game area
	 */
	public boolean isGrabbedTileWithinGameArea(int x, int y) {
		
		// The size of the tile varies depending on where it is
		if(isWithinBoard(x,y)) {
			
			// Construct a rectangle that is smaller than the game area by half
			// a tile on each side
			Rectangle rect = new Rectangle(
					BoardRackPanel.boardOffsetX , // + BoardRackPanel.boardCellLength / 2
					BoardRackPanel.boardOffsetY , // + BoardRackPanel.boardCellLength / 2
					BoardRackPanel.boardLength,   //  -	BoardRackPanel.boardCellLength,
					BoardRackPanel.boardLength  + BoardRackPanel.rackHeight); // BoardRackPanel.boardCellLength);
			
			return rect.contains(x,y);
			
		} else if(isWithinRack(x, y)) {
			
			// Construct a rectangle that is smaller than the game area by half
			// a tile on each side
			Rectangle rect = new Rectangle(
					BoardRackPanel.boardOffsetX + BoardRackPanel.rackTileLength / 2,
					BoardRackPanel.boardOffsetY + BoardRackPanel.rackTileLength / 2,
					BoardRackPanel.boardLength -
						BoardRackPanel.rackTileLength,
					BoardRackPanel.boardLength + BoardRackPanel.rackHeight -
						BoardRackPanel.rackTileLength/2);
			
			return rect.contains(x,y);
			
		} else {
			// We are not in the board or the rack
			return false;
		}
	}
	
	/**
	 * Retrieves the Cell of the board at mouse click x,y
	 * @param x X position of the point
	 * @param y Y position of the point
	 * @return Cell at position x,y on the board
	 */
	public Cell getClickedCell(int x, int y) {
		// Make sure it is within the board
		if(isWithinBoard(x,y)) {
			
			// Loop through cells and see if any match the position
			for(int r = 0; r < BoardRackPanel.numBoardCells; r++) {
				for(int c = 0; c < BoardRackPanel.numBoardCells; c++) {
				
					// Get rectangle representing cell and check for collision
					if(BoardRackPanel.getBoardCellRect(r, c).contains(x,y)) {
						// Return the cell at that position
						return this.mainFrame.getGame().getBoard().getCell(r, c);
					}
				}
			}
		}
		
		// Return null if no cell is clicked
		return null;
	}
	
	/**
	 * Retrieves the tile on either the board or the rack where the mouse was clicked
	 * @param x X position of the point
	 * @param y Y position of the point
	 * @return The tile at position x,y
	 */
	public Tile getClickedTile(int x, int y) {
		
		// Check whether the click is over the rack
		if(isWithinRack(x,y)) {
			
			// Loop through tiles and see if any were clicked
			Iterator<Tile> rackIter = this.mainFrame.getGame().getRack().getTiles().iterator();
			int tileIndex = 0;
			
			while(rackIter.hasNext()) {
				
				Tile tile = rackIter.next();
				
				// Construct a rectangle representing the tile and check for collision
				if(BoardRackPanel.getRackTileRect(tileIndex).contains(x,y)) {
					return tile;
				}
				
				tileIndex++;
			}
		} else {
			// If this is on the board, just get the tile from the cell
			Cell cell = getClickedCell(x,y);
			if (cell == null) { return null; }
			return cell.getTile();
		}
		
		return null;
	}
	
	/**
	 * Retrieves the index into the array of tiles on the rack coinciding with a
	 * mouse click at x,y. This is used to determine where to insert a tile when
	 * the user drags one onto the rack. The middle of each tile is used as the
	 * horizontal boundaries--so for example, if the x,y is between the halfway
	 * point of the tile at index 1 and the tile at index 2, the method will return 2.
	 * @param x X position of the point
	 * @param y Y position of the point
	 * @return Index into the tile array of the rack
	 */
	public int getRackIndex(int x, int y) {
		
		// Make sure the point is within the rack first
		if(isWithinRack(x,y)) {
			
			ArrayList<Tile> tiles = this.mainFrame.getGame().getRack().getTiles();
			
			// Construct rectangles consisting of the full rack height and
			// widths from one tile's midpoint to the next, then use that
			// rectangle to check for collision.
			for(int i = 0; i < tiles.size(); i++) {
				Rectangle rect = new Rectangle(
						BoardRackPanel.rackPositionX + 
							i * BoardRackPanel.rackSpacing +
							i * BoardRackPanel.rackTileLength -
							BoardRackPanel.rackTileLength / 2,
						BoardRackPanel.rackPositionY,
						BoardRackPanel.rackTileLength + BoardRackPanel.rackSpacing,
						BoardRackPanel.rackHeight);
				
				if(rect.contains(x,y)) {
					return i;
				}
			}	
		}
		
		// If not in the rack, just return last index
		return this.mainFrame.getGame().getRack().getTiles().size();
	}
	
	/**
	 * 
	 * @return Returns the rectangular area occupied by the board
	 */
	public static Rectangle getBoardRect() {
		return new Rectangle(
				BoardRackPanel.boardOffsetX,
				BoardRackPanel.boardOffsetY,
				BoardRackPanel.boardLength,
				BoardRackPanel.boardLength);
	}
	
	/**
	 * 
	 * @return Returns the rectangular area occupied by the rack
	 */
	public static Rectangle getRackRect() {
		return new Rectangle(
				BoardRackPanel.rackPositionX,
				BoardRackPanel.rackPositionY,
				BoardRackPanel.rackWidth,
				BoardRackPanel.rackHeight);
	}
	
	/**
	 * 
	 * @param r Row of the desired cell
	 * @param c Column of the desired cell
	 * @return Returns the rectangle representing the area occupied by the cell
	 * at position r,c
	 */
	public static Rectangle getBoardCellRect(int r, int c) {
		return new Rectangle(
				BoardRackPanel.boardOffsetX + 
					c * BoardRackPanel.boardCellLength,
				BoardRackPanel.boardOffsetY + 
					r * BoardRackPanel.boardCellLength,
				BoardRackPanel.boardCellLength,
				BoardRackPanel.boardCellLength);
	}
	
	/**
	 * 
	 * @param tileIndex Index into the array of tiles on the rack
	 * @return Returns the rectangle representing the area occupied by a tile on the
	 * rack at position tileIndex
	 */
	public static Rectangle getRackTileRect(int tileIndex) {
		return new Rectangle(
				BoardRackPanel.rackPositionX + 
				(tileIndex + 1) * BoardRackPanel.rackSpacing +
				tileIndex * BoardRackPanel.rackTileLength,
			BoardRackPanel.rackPositionY + BoardRackPanel.rackSpacing,
			BoardRackPanel.rackTileLength,
			BoardRackPanel.rackTileLength);
	}
}

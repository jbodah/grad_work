package gui;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

import state.GameState;
import state.Gun;

/**
 * Responsible for drawing gun sights on the playing field.
 */
public class DecoratorGun extends DrawingDecorator {
	
	/** Know the state of the game so we can draw the ducks. */
	private GameState state = null;
	
	/** Size of sights. */
	int aimSize = 40;

	/** Where gun charge is to be drawn. */
	private Rectangle gunCharge;

	/**
	 * Build Decoration on top of an existing chain (or the concrete one).
	 * 
	 * @param inner     Next decorator in the chain
	 * @param state     The state of the game
	 * @param gunCharge where to draw the charge for the gun.
	 */
	public DecoratorGun (DrawingCanvas inner, GameState state, Rectangle gunCharge) {
		super(inner); 
		
		this.state = state;
		this.gunCharge = gunCharge;
	}
	
	/** 
	 * Redraw the state.
	 * 
	 * Take care not to update (by mistake) the color in the graphics.
	 * 
	 * @param   Graphics entity into which we are drawn
	 */
	public void drawState(Graphics g) {
		
		java.awt.Color original = g.getColor();
		super.drawState(g);
		
		// draw gun sights
		Gun gun = state.getGun();
		int charge;
		boolean ready;
		synchronized (gun) {
			 charge = gun.getCharge();
			 ready = gun.isSufficientlyCharged();
		}
		
		Point center = gun.getAim();
		g.drawOval(center.x - aimSize, center.y - aimSize, 2*aimSize, 2*aimSize);
		
		// draw gun charges at lower part of screen.
		// different colors for status.
		if (ready) {
			g.setColor(Color.green);
		} else {
			g.setColor(Color.red);
		}
		
		// proportionally draw the charge within this rectangle
		float percent = gunCharge.width;
		percent = percent * charge / 100.0f;
		g.fillRect(gunCharge.x, gunCharge.y, (int) percent, gunCharge.height);
	
		// draw boundary in black
		g.setColor(Color.black);
		g.drawRect(gunCharge.x, gunCharge.y, gunCharge.width, gunCharge.height);
		
		// Ok, let other decorators do their work. NOTE: if this had been a "post drawer"
		// decorator, then the gun sights would sometimes be BEHIND the duck, if not careful!
		g.setColor (original);
		//super.drawState(g);
	}
}

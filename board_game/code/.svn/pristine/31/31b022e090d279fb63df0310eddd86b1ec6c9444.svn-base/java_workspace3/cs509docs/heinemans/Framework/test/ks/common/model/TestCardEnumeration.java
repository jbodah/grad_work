package ks.common.model;

import junit.framework.TestCase;

public class TestCardEnumeration extends TestCase {

	public void testEnumeration() {
		CardEnumeration ce = new CardEnumeration();
		assertTrue (ce.hasMoreElements());
		
		Deck d = new Deck();
		d.create(Deck.OrderBySuit);
		
		// note this proper deck is BACKWARDS so we reverse
		Stack st = new Stack();
		while (!d.empty()) {
			st.add(d.get());
		}
		
		
		while (ce.hasMoreElements()) {
			assertEquals (st.get(), ce.nextElement());
		}
		
		assertFalse (ce.hasMoreElements());
		assertTrue (st.empty());
		
	}
}

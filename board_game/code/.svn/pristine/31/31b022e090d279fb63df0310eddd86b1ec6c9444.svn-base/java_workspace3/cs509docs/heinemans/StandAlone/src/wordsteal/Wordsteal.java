package wordsteal;

/**
 * Placeholder class to simply use within Factory found within framework. 
 * 
 * @author George Heineman
 *
 */
public class Wordsteal {

}

package puzzler.constructor;

import java.awt.Polygon;

/**
 * Represents a piece in the solution space.
 * 
 * @author George Heineman
 */
public class Region {
	
	/** Destination of final piece. */
	public final int finalX;
	
	/** Destination of final piece. */
	public final int finalY;
	
	/** Shape. */
	public final Polygon shape;

	/**
	 * Construct the piece at given location.
	 * 
	 * @param finalX  destination x-coordinate of piece.
	 * @param finalY  destination y-coordinate of piece.
	 * @param shape   polygon location
	 */
	public Region (int finalX, int finalY, Polygon shape) {
		this.finalX = finalX;
		this.finalY = finalY;
		
		this.shape = shape;
	}
}

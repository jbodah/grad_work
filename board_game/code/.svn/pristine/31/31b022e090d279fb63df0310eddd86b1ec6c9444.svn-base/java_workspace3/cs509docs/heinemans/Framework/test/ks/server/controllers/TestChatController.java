package ks.server.controllers;

import org.w3c.dom.Document;

import junit.framework.TestCase;
import ks.framework.common.Configure;
import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.framework.communicator.SampleOutput;

/**
 * Here's an example to show how you might go about writing test cases for your
 * controllers.
 * <p>
 * <xs:element name="chat">
 *   <xs:complexType>
 *     <xs:sequence>
 *       <xs:element ref="player-id" minOccurs='0' maxOccurs='unbounded'/>
 *       <xs:element ref="text"/>
 *     </xs:sequence>
 *   </xs:complexType>
 * </xs:element>
 *
 * @author heineman
 *
 */
public class TestChatController extends TestCase {

	/** Controller under test. */
	ChatController controller;

	/** Communicator that facilitates server-side communication. */
	Communicator com;

	/** Three connected people on the system. */
	SampleOutput original;
	SampleOutput alice;
	SampleOutput bob;
	SampleOutput charlie;
	
	/** Ids. */
	String originalID = "113355";
	String aliceID = "12345";
	String bobID = "13131";
	String charlieID = "873";

	protected void setUp() {
		controller = new ChatController();
		com = new Communicator();

		original = new SampleOutput();
		alice = new SampleOutput();
		bob = new SampleOutput();
		charlie = new SampleOutput();
		com.connectUser(originalID, original);
		com.connectUser(aliceID, alice);
		com.connectUser(bobID, bob);
		com.connectUser(charlieID, charlie);

		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
	}

	// one test method per case
	public void testGlobalChat() {
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\">" +
		"<chat><text>This is a test</text></chat>" + 
		"</request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);
		m1.setOriginator(originalID);

		controller.process(com, m1);

		// alice, bob and charlie got something but original did not.
		assertTrue (alice.hasObject());
		assertTrue (bob.hasObject());
		assertTrue (charlie.hasObject());
		assertFalse (original.hasObject());
	}


	// single chat to alice
	public void testSinglePrivateChat() {
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\">" +
		"<chat><player-id player='" + aliceID + "'/><text>This is a test</text></chat>" + 
		"</request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);
		m1.setOriginator(originalID);

		controller.process(com, m1);

		// alice got something but original, bob and charlie did not.
		assertTrue (alice.hasObject());
		assertFalse (bob.hasObject());
		assertFalse (charlie.hasObject());
		assertFalse (original.hasObject());
	}

	public void testMultiplePrivateChat() {
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\">" +
		"<chat>" + 
	  	  "<player-id player='" + aliceID + "'/>" +
		  "<player-id player='" + bobID + "'/>" +
		  "<text>This is a test</text></chat>" + 
		"</request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);
		m1.setOriginator(originalID);

		controller.process(com, m1);

		// alice and bob got something but original and charlie did not.
		assertTrue (alice.hasObject());
		assertTrue (bob.hasObject());
		assertFalse (charlie.hasObject());
		assertFalse (original.hasObject());
	}

}

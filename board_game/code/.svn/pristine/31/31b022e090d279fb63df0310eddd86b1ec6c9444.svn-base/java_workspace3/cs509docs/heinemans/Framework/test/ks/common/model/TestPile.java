package ks.common.model;

import junit.framework.TestCase;

// nothing much to test
public class TestPile extends TestCase {

	public void testToString() {
		Pile p = new Pile("sample");
		assertEquals ("[Pile:sample:<empty>]", p.toString());
		p.add (new Card (2, Card.HEARTS));
		assertEquals ("[Pile:sample:2H]", p.toString());
		p.add (new Card (3, Card.HEARTS));
		assertEquals ("[Pile:sample:2H,3H]", p.toString());
	}
	
	public void testConstruct() {
		Pile p = new Pile(null);
		
		assertTrue (p.getName().startsWith("Pile"));
	}
	
}

package puzzler.controller;

import javax.swing.JOptionPane;
import puzzler.PuzzlerApplication;

/**
 * About the application controller.
 * 
 * @author George Heineman
 */
public class AboutController {

	/** Controller will need app to manage it properly. */
	PuzzlerApplication app;


	/** Construct puzzle controller with application in mind. */
	public AboutController(PuzzlerApplication pa) {
		this.app = pa;

	}

	/**
	 * Load up a puzzle.
	 */
	public void process() {

		// Alert user
		JOptionPane.showMessageDialog(app, 
				"This Puzzler Application was developed\nas a small case study for CS509.\n(c) 2010, George Heineman", 
				"About Puzzler",
				JOptionPane.INFORMATION_MESSAGE);
	}

}

package ks.client;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

/**
 * Utility class for window management classes.
 * 
 * @author George Heineman
 */
public class WindowManager {

	/**
	 * Center window on the screen.
	 * 
	 * @param frame
	 */
	public static final void centerWindow (JFrame frame) {
		// Get the size of the screen
	    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	    
	    // Determine the new location of the window
	    int w = frame.getSize().width;
	    int h = frame.getSize().height;
	    int x = (dim.width-w)/2;
	    int y = (dim.height-h)/2;
	    
	    // Move the window
	    frame.setLocation(x, y);
	}
}

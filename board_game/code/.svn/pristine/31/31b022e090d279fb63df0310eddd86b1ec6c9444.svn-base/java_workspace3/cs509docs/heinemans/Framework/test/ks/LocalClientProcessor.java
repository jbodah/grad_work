package ks;

import java.util.ArrayList;

import ks.client.interfaces.ILobby;
import ks.client.processor.ClientProcessor;
import ks.framework.common.Message;
import ks.framework.interfaces.IClientProcessor;

/**
 * A LocalClientProcessor is used during testing to construct a queue of messages
 * being delivered back from the server to the client.
 * <p>
 * Using this instantiation of a {@link IClientProcessor} it becomes possible 
 * to test a wide variety of client-side behaviors.
 * 
 * @author George Heineman
 */
public class LocalClientProcessor extends ClientProcessor {

	public LocalClientProcessor(ILobby lob) {
		super(lob);
	}

	boolean connected = false;
	
	/** Store all messages in queue to be inspected, retrieved. */
	ArrayList<Message> queue = new ArrayList<Message>(); 
	
	// helper method to reset state
	public void reset() {
		queue.clear();
		connected = false;
	}
	
	@Override
	public boolean process(Message m) {
		synchronized (queue) {
			queue.add(m);
		}
		
		return true;
	}

	/** retrieve the next message to be processed. */
	public Message dequeue() {
		Message m;
		
		synchronized (queue) {
			m = queue.remove(0);
		}
		
		return m;
	}

	/** Determine whether a message is waiting. */
	public boolean hasMessage() {
		
		synchronized (queue) {
			return !queue.isEmpty();
		}
		
	}

	
	@Override
	public void connected(boolean status) {
		this.connected = status;
	}

	/** Expose connected state. */
	public boolean isConnected() {
		return connected;
	}

}

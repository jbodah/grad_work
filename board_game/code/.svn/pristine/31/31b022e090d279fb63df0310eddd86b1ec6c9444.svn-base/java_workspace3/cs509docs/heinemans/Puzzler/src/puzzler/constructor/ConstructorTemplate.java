package puzzler.constructor;

import java.awt.Polygon;
import java.awt.geom.Area;
import java.util.ArrayList;
import java.util.Set;

import puzzler.model.Puzzle;

/**
 * Example template method for puzzle construction.
 * 
 * @author George Heineman
 */
public abstract class ConstructorTemplate {
	
	/** Every puzzle has a fixed rectangular width and height. */
	int width;
	int height;
	
	/** 
	 * Template method for a rectangular puzzle shape.
	 * 
	 * @param width     width of puzzle
	 * @param height    height of puzzle
	 */
	public ConstructorTemplate (int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	/** 
	 * Subclass is responsible for returning iterator of all constructed pieces.
	 * 
	 * @return
	 */
	abstract Set<Region> pieces();
	
	/**
	 * Set up the approach to decomposing rectangular puzzle into non-overlapping 
	 * shapes.
	 * <p>
	 * This makes sure all pieces are non-overlapping and that the full 
	 * puzzle is completely represented.
	 * 
	 * @param img
	 * @return Puzzle or null if the construction failed.
	 */
	public final Puzzle construct () {
		Puzzle puzzle = new Puzzle();
		
		// construct each piece and add to set
		Polygon p = new Polygon();
		p.addPoint(0,0);
		p.addPoint(width, 0);
		p.addPoint(width, height);
		p.addPoint(0, height);
		
		// full size.
		Area area = new Area(p);
		ArrayList<Polygon> regions = new ArrayList<Polygon>();
		
		for (Region r : pieces()) {
			puzzle.addPiece (r.finalX, r.finalY, r.shape);
			Polygon pr = new Polygon(r.shape.xpoints, r.shape.ypoints, r.shape.npoints);
			pr.translate(r.finalX, r.finalY);
			regions.add(pr);
			area.subtract(new Area(pr));
		}
		
		// if area is empty then all pieces cover the space
		if (!area.isEmpty()) {
			System.err.println("Puzzle pieces do not cover entire area");
			//return (null);
		}
		
		// validate that no two pieces intersect each other.
		for (int i = 0; i < regions.size() - 1; i++) {
			Area a1 = new Area (regions.get(i));
			for (int j = i+1; j < regions.size(); j++) {
				Area a2 = new Area (regions.get(j));
				
				a1.intersect(a2);	
				if (!a1.isEmpty()) {
					System.err.println("Two puzzles pieces intersect.");
					System.err.println("   p1:" + regions.get(i));
					System.err.println("   p2:" + regions.get(j));
					return (null);
				}
			}
		}

		return puzzle;
	}
}

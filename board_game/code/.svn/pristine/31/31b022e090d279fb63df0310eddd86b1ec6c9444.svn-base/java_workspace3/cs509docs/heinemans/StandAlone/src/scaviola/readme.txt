Converted to Eclipse: 11-4-2003
Verified functioning: 11-4-2003
  * Works fine.
  
  * when undoing a card move to/from an empty row, the left hand side cards 
    shows border *way* to the left.

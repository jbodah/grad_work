package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

import java.util.*;

/**
 * Responsible for the assignment of points and the floating 'numbers' that
 * appear above the ducks and float up, with different colors as they vanish
 * with decreasing point size. This is a more complex decorator, because it
 * involves a threaded computation. However, the threaded part of the computation
 * is left out in the PointController object.
 * 
 * @author George
 */
public class DecoratorPoints extends DrawingDecorator {
	
	/** order of colors that flash when score is announced. */
	static Color rainbow[] = {
		Color.red, Color.orange, Color.yellow, Color.green, Color.blue, Color.lightGray
	};
	
	/** Fonts to be used when drawing the scores. */
	static Font fonts[] = new Font[rainbow.length];

	/** length of hovering time. */
	long hoverTime = 375;   // 3/8 of a second.
	
	/** collection of active scores */
	Scores scores;

	/**
	 * Build Decoration on top of an existing chain (or the concrete one).
	 * 
	 * @param inner     next decoration in the chain
	 */
	public DecoratorPoints (DrawingCanvas inner) {
		super(inner); 
		
		// initialize fonts
		fonts[0] = new Font("Arial Bold", Font.BOLD, 48);
		fonts[1] = new Font("Arial Bold", Font.BOLD, 32);
		fonts[2] = new Font("Arial Bold", Font.BOLD, 20);
		fonts[3] = new Font("Arial Bold", Font.BOLD, 16);
		fonts[4] = new Font("Arial Bold", Font.BOLD, 12);
		fonts[5] = new Font("Arial Bold", Font.BOLD, 10);
		
		// initialize as empty.
		scores = new Scores();
	}
	
	/**
	 * Determines if there still is a need to draw points, 
	 * @return
	 */
	public boolean stillDrawing() {
		return !scores.isEmpty();
	}
	
	/** 
	 * Record a score at the location, with specific points.
	 * @param point
	 * @param loc
	 */
	public void addScore (int point, Point loc) {
		scores.addScore(point, loc);
	}

	/** 
	 * Redraw the state.
	 * 
	 * Note how the graphics entity is simply taken from the most concrete one in the chain.
	 */
	public void drawState(Graphics g) {
		
		// we are going to be a "post drawer" in that we let the chain redraw.
		super.drawState(g);
		
		if (scores.isEmpty()) return;
		Color lastColor = g.getColor();
		long now = System.currentTimeMillis();

		synchronized (scores) {
			for (Iterator<Score> it = scores.iterator(); it.hasNext(); ) {
				Score s = it.next();
				
				int dist = (int) (now - s.now);
				if (dist > hoverTime) {
					it.remove();
					continue;
				}
				
				// otherwise, draw
				int idx = (int)((now-s.now)/(hoverTime/rainbow.length));
				if (idx >= rainbow.length) { idx = rainbow.length-1; }  // fix rounding errors.
				g.setFont(fonts[idx]);
				g.setColor(rainbow[idx]);
				g.drawString("" + s.value, s.location.x, s.location.y - (dist/rainbow.length));
			}
			
			g.setColor(lastColor);  // reset colors
		}
	}
}

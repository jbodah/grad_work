package ks.client.interfaces;

import ks.client.lobby.LobbyFrame;

/**
 * I need to provide a way for all client-side projects to get a chance to
 * initialize the lobby once it is created.
 * <p>
 * This interface allows the lobby to make a "callback" after it has been
 * created.
 * 
 * @author George Heineman
 */
public interface ILobbyInitialize {

	/** 
	 * When lobby is initialized, this method is called so you can perform
	 * necessary customizations on the client end.
	 * 
	 * @param frame
	 */
	void initializeLobby(LobbyFrame frame);
	
	/**
	 * When connection to server is initiated (true) or lost (false), this method is invoked.
	 */
	void connected (boolean status);
}

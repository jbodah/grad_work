package ks.server.controllers;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.framework.debug.Debug;
import ks.server.interfaces.IProcessServerMessage;

import org.w3c.dom.Document;

/**
 * Handle the login command for users.
 * 
 * @author George Heineman
 */
public class LoginController implements IProcessServerMessage {

	public boolean process(Communicator com, Message m) {
		Debug.println ("Observe login by: " + m.getOriginator());
		
		 // produce request to go to the client
		StringBuilder sb = new StringBuilder(Message.responseHeader(true, m.id));
        sb.append("<output system='true'><text>");
        sb.append(m.getOriginator()).append(" logged in");
        sb.append("</text></output></response>");
        Document d = Message.construct (sb.toString());
        
        // send to all clients...
        Message r = new Message (d);
        r.setBroadcast();
        
        // send out players info. Note this won't contain player ranking information but I have no 
        // easy way to get that unless we normalize some standard interface on the server.

        com.distribute(r);
        return true;
	}
}
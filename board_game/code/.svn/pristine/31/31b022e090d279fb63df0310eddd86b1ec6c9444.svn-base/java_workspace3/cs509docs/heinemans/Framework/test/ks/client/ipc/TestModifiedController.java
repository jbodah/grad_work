package ks.client.ipc;

import org.w3c.dom.Document;


import junit.framework.TestCase;
import ks.client.UserContext;
import ks.client.controllers.ConnectController;
import ks.client.interfaces.IController;
import ks.client.interfaces.ILobby;
import ks.client.lobby.LobbyFrame;
import ks.framework.common.Configure;
import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.server.controllers.ServerControllerChain;
import ks.server.ipc.Server;
import ks.server.processor.ServerProcessor;

/**
 * Validate IController interface
 */
public class TestModifiedController extends TestCase {

	// host
	public static final String localhost = "localhost";
	
	// sample credentials
	public static final String user = "11323";
	public static final String password = "password";
	
	int specialPort;
	
	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
			
			// validate a simple tables
			String s = Message.requestHeader() + "<chat><text>Here is the message</text></chat></request>";
			Document d = Message.construct(s);
			assertTrue (d != null);
			
			// random port
			specialPort = (int)(8000 + Math.random()*1000);
			
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
	}

	
	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	public void testClient() {
		Server s = new Server(specialPort);
		
		// here is where you can augment the chain of server-side controllers
		ServerProcessor.resetControllers();
		ServerControllerChain head = ServerProcessor.head();
				
		// create a 'server-side controller' that responds to the message with a chat
		head.append(new ServerControllerChain() {
			@Override
			public boolean process(Communicator com, Message m) {
				String s = Message.responseHeader(true, m.id) + "<output from='119398' public='false'><text>Output</text></output></response>";
				Document d = Message.construct(s);
				Message response = new Message (d);
				response.setRecipient(m.getOriginator());
				return com.distribute(response);
			} 
		});
		
		assertTrue (s.activate());
		
		waitASecond();
		
		// create client to connect
		UserContext context = new UserContext();  // by default, localhost
		context.setPort(specialPort);
		LobbyFrame lobby = new LobbyFrame (context);
		lobby.setVisible(true);
		
		context.setUser(user);
		context.setPassword(password);
		context.setSelfRegister(false);
		
		assertTrue (new ConnectController(lobby).process(context));
		
		waitASecond();
		
		String str = Message.requestHeader() + "<tables/></request>";
		Document d = Message.construct(str);
		Message m = new Message (d);
		
		final boolean[] received = new boolean [1];
		
		IController special = new IController() {

			@Override
			public void process(ILobby lobby, Message request, Message response) {
				received[0]= true; 
			}
			
		};
		
		context.getClient().sendToServer(lobby, m, special);
		
		// make sure it was received.
		int count = 100;
		while (count > 0) {
			try { Thread.sleep(1000); } catch (InterruptedException e) { count = 0;	}
			
			if (received[0]) {
				break;
			}
		}
		
		assertTrue (received[0]);
		
		//assertTrue (new DisconnectController (lobby.getRoom()).process(context));
		assertTrue (lobby.tryToDisconnect());
		
		s.deactivate();
	
		lobby.setVisible(false);
		lobby.dispose();
	}	
	
	
}

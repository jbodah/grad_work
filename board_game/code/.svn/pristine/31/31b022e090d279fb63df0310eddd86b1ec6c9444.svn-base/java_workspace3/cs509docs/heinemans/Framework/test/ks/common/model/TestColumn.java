package ks.common.model;

import junit.framework.TestCase;

// nothing much to test
public class TestColumn extends TestCase {

	
	public void testConstruction() {
		Stack st = new Stack();
		st.add (new Card (2, Card.HEARTS));
		
		Column c = new Column(st);
		assertFalse (c.empty());
		assertEquals (1, c.count());
	}
	
	public void testConstructionTwo() {
		Stack st = new Stack();
		st.add (new Card (2, Card.HEARTS));
		
		Column c = new Column(st, "sample");
		assertFalse (c.empty());
		assertEquals (1, c.count());
	}
	
	public void testToString() {
		Column c = new Column("sample");
		assertEquals ("[Column:sample:<empty>]", c.toString());
		c.add (new Card (2, Card.HEARTS));
		assertEquals ("[Column:sample:2H]", c.toString());
		c.add (new Card (3, Card.HEARTS));
		assertEquals ("[Column:sample:2H,3H]", c.toString());
	}
	
}

package darrent;

import java.awt.event.MouseEvent;

import ks.client.gamefactory.GameWindow;
import ks.common.model.Card;
import ks.common.model.Deck;
import ks.common.view.CardImages;
import ks.launcher.Main;
import ks.tests.KSTestCase;

public class TestFreeCell extends KSTestCase {
	// this is the game under test.
	FreeCell game;
	
	// window for game.
	GameWindow gw;
	
	// card images for offset.
	CardImages images;
	
	protected void setUp() {
		game = new FreeCell();
		
		// Because solitaire variations are expected to run within a container, we need to 
		// do this, even though the Container will never be made visible. Note that here
		// we select the "random seed" by which the deck will be shuffled. We use the 
		// special constant Deck.OrderBySuit (-2) which orders the deck from Ace of clubs
		// right to King of spades.
		gw = Main.generateWindow(game, Deck.OrderBySuit); 
		
		images = game.getCardImages();
	}
	
	// clean up properly
	protected void tearDown() {
		gw.setVisible(false);
		gw.dispose();
	}
	
	public void testMove() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());

		// HACK. get to the bottom.
		MouseEvent dbl = createDoubleClicked (game, game.columnViews[7], 0, images.getOverlap()*6);
		game.columnViews[7].getMouseManager().handleMouseEvent(dbl);
		
		assertEquals (new Card (Card.TWO, Card.CLUBS), game.columns[7].peek());
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.baseCells[0].peek());
	}
	
	// spot check deal 11982. Must verify against real freecell player.
	// 
	//	AH AS 4H AC 2D 6S TS JS     // note these are SORTED and thus are
	//	3D 3H QS QC 8S 7H AD KS     // different from the ACTUAL
	//	KD 6H 5S 4D 9H JH 9S 3C     // game that you would play, but that
	//	JC 5D 5C 8C 9D TD KH 7C     // sorted order is irrelevant to 
	//	6C 2C TH QH 6D TC 4S 7S     // game play.
	//	JD 7D 8H 9C 2H QD 4C 5H 
	//	KC 8D 2S 3S             
	public void testDeal11982() {
		gw.setVisible(false);
		gw.dispose();
		gw = Main.generateWindow(game, 11982); 
		assertEquals (new Card (Card.KING, Card.CLUBS), game.columns[0].peek());
		assertEquals (new Card (Card.EIGHT, Card.DIAMONDS), game.columns[1].peek());
		assertEquals (new Card (Card.TWO, Card.SPADES), game.columns[2].peek());
		assertEquals (new Card (Card.THREE, Card.SPADES), game.columns[3].peek());
		assertEquals (new Card (Card.TWO, Card.HEARTS), game.columns[4].peek());
		assertEquals (new Card (Card.QUEEN, Card.DIAMONDS), game.columns[5].peek());
		assertEquals (new Card (Card.FOUR, Card.CLUBS), game.columns[6].peek());
		assertEquals (new Card (Card.FIVE, Card.HEARTS), game.columns[7].peek());
		
	}
	
	// move card to FreeCell
	public void testMoveFreeCell2FreeCell() {
		assertEquals (new Card (Card.SEVEN, Card.SPADES), game.columns[0].peek());

		// HACK. get to the bottom.
		MouseEvent dbl = createDoubleClicked (game, game.columnViews[0], 0, images.getOverlap()*6);
		game.columnViews[0].getMouseManager().handleMouseEvent(dbl);
		
		assertEquals (new Card (Card.SEVEN, Card.SPADES), game.freeCells[0].peek());
		
		// now move to the next free cell spot
		MouseEvent pr = createPressed (game, game.freeCellViews[0], 0,  0);
		game.freeCellViews[0].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.freeCellViews[1], 0,  0);
		game.freeCellViews[1].getMouseManager().handleMouseEvent(rel);
		
		assertTrue(game.freeCells[0].peek() == null);
		
		assertEquals (new Card (Card.SEVEN, Card.SPADES), game.freeCells[1].peek());
	}
	
	// move card to FreeCell
	public void testMoveColumn2Column() {
		assertEquals (new Card (Card.QUEEN, Card.DIAMONDS), game.columns[3].peek());

		// now move to the next column
		MouseEvent pr = createPressed (game, game.columnViews[3], 0,  6*images.getOverlap());
		game.columnViews[3].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.columnViews[5], 0,  0);
		game.columnViews[5].getMouseManager().handleMouseEvent(rel);
		
		assertEquals (new Card (Card.QUEEN, Card.DIAMONDS), game.columns[5].peek());
	}
	
	
	// move card to base
	public void testMoveAce() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());

		// now move to the next column
		MouseEvent pr = createPressed (game, game.columnViews[7], 0,  6*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.baseCellViews[0], 0,  0);
		game.baseCellViews[0].getMouseManager().handleMouseEvent(rel);
		
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.baseCells[0].peek());
	}
	
	// move card to base
	public void testMoveCardToFreeCell() {
		assertEquals (new Card (Card.SEVEN, Card.SPADES), game.columns[0].peek());

		// now move to the next column
		MouseEvent pr = createPressed (game, game.columnViews[0], 0,  6*images.getOverlap());
		game.columnViews[0].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.freeCellViews[0], 0,  0);
		game.freeCellViews[0].getMouseManager().handleMouseEvent(rel);
		
		assertEquals (new Card (Card.SEVEN, Card.SPADES), game.freeCells[0].peek());
	}
	
	// drag columns of two cards
	public void testMoveColumn() {
		for (int i =0; i < 8; i++) {
			System.out.println(game.columns[i].peek());
		}
		assertEquals (new Card (Card.SIX, Card.DIAMONDS), game.columns[4].peek());

		// now move to the next column
		MouseEvent pr = createPressed (game, game.columnViews[4], 0,  6*images.getOverlap());
		game.columnViews[4].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.columnViews[6], 0,  0);
		game.columnViews[6].getMouseManager().handleMouseEvent(rel);
		
		// ace auto moves
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.baseCells[3].peek());
		
		// move two cards to free cells, getting ready for my next move
		// now move to the next column
		MouseEvent dbl = createDoubleClicked(game, game.columnViews[6], 0,  6*images.getOverlap());
		game.columnViews[6].getMouseManager().handleMouseEvent(dbl);
		dbl = createDoubleClicked(game, game.columnViews[6], 0,  5*images.getOverlap());
		game.columnViews[6].getMouseManager().handleMouseEvent(dbl);
		
		// now move column
		// now move to the next column
		pr = createPressed (game, game.columnViews[6], 0,  6*images.getOverlap());
		game.columnViews[6].getMouseManager().handleMouseEvent(pr);
		
		rel = createReleased (game, game.columnViews[6], 0,  0);
		game.columnViews[6].getMouseManager().handleMouseEvent(rel);
	}
	
	// move card to FreeCell and back
	public void testMoveAndBack() {
		for (int i=  0 ; i < 8; i++) {
			System.out.println(game.columns[i].peek());
		}
		assertEquals (new Card (Card.SIX, Card.HEARTS), game.columns[2].peek());

		// HACK. get to the bottom.
		MouseEvent dbl = createDoubleClicked (game, game.columnViews[2], 0, images.getOverlap()*6);
		game.columnViews[2].getMouseManager().handleMouseEvent(dbl);
		
		assertEquals (new Card (Card.SIX, Card.HEARTS), game.freeCells[0].peek());
		
		// now move to the next free cell spot
		MouseEvent pr = createPressed (game, game.freeCellViews[0], 0,  0);
		game.freeCellViews[0].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.columnViews[0], 0,  0);
		game.columnViews[0].getMouseManager().handleMouseEvent(rel);
		
		assertTrue(game.freeCells[0].peek() == null);
		
		assertEquals (new Card (Card.SIX, Card.HEARTS), game.columns[0].peek());
	}
	
	// move card to base
	public void testClickTwoToFreeCellThenToFoundation() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());

		// now move to the next column
		MouseEvent dbl = createDoubleClicked(game, game.columnViews[7], 0,  6*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(dbl);
		
		MouseEvent pr = createPressed (game, game.columnViews[7], 0,  5*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.freeCellViews[0], 0,  0);
		game.freeCellViews[0].getMouseManager().handleMouseEvent(rel);
		
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.baseCells[0].peek());
		
		// move 2 to free cell
		pr = createPressed (game, game.columnViews[7], 0,  4*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(pr);

		rel = createReleased (game, game.freeCellViews[0], 0,  0);
		game.freeCellViews[0].getMouseManager().handleMouseEvent(rel);
		
		// dbl click to foundation
		// now move to the next column
		dbl = createDoubleClicked(game, game.freeCellViews[0], 0, 0);
		game.freeCellViews[0].getMouseManager().handleMouseEvent(dbl);
		
		assertEquals (new Card (Card.TWO, Card.CLUBS), game.baseCells[0].peek());
		
		assertTrue (game.freeCells[0].count() == 0);
	
	}
	
	// move card to base
	public void testDragTwoToFreeCellThenToFoundation() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());

		// now move to the next column
		MouseEvent dbl = createDoubleClicked(game, game.columnViews[7], 0,  6*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(dbl);
		
		MouseEvent pr = createPressed (game, game.columnViews[7], 0,  5*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.freeCellViews[0], 0,  0);
		game.freeCellViews[0].getMouseManager().handleMouseEvent(rel);
		
		assertEquals (new Card (Card.TWO, Card.CLUBS), game.freeCells[0].peek());
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.baseCells[0].peek());
		
		// move 2 to free cell
		pr = createPressed (game, game.freeCellViews[0], 0,  4*images.getOverlap());
		game.freeCellViews[0].getMouseManager().handleMouseEvent(pr);

		rel = createReleased (game, game.baseCellViews[0], 0,  0);
		game.baseCellViews[0].getMouseManager().handleMouseEvent(rel);
		
		assertTrue (game.freeCells[0].count() == 0);
	
	}
	
	// move card to base
	public void testDragTwoToFoundation() {
		assertEquals (new Card (Card.ACE, Card.CLUBS), game.columns[7].peek());

		// now move to the next column
		MouseEvent dbl = createDoubleClicked(game, game.columnViews[7], 0,  6*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(dbl);
		
		MouseEvent pr = createPressed (game, game.columnViews[7], 0,  5*images.getOverlap());
		game.columnViews[7].getMouseManager().handleMouseEvent(pr);
		
		MouseEvent rel = createReleased (game, game.baseCellViews[0], 0,  0);
		game.baseCellViews[0].getMouseManager().handleMouseEvent(rel);
		
		assertEquals (new Card (Card.TWO, Card.CLUBS), game.baseCells[0].peek());
		
		assertEquals (new Card (Card.THREE, Card.CLUBS), game.columns[7].peek());
		
	}
}

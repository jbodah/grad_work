package iteratorPoem;

public class ContentString implements Contents<Integer> {
	public void add(Integer s) {
		
	}
}

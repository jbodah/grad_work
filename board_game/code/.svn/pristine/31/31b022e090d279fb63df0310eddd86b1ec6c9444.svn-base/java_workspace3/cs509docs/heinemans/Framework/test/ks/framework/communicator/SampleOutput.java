package ks.framework.communicator;

import java.util.ArrayList;

import ks.framework.interfaces.ICommunicator;

/**
 * Helper class for test cases.
 * <p>
 * Made public for use by other groups.
 * @author heineman
 */
public class SampleOutput implements ICommunicator {

	boolean open = true;

	// store objects in queue
	ArrayList<Object> queue = new ArrayList<Object>();

	public void clear() {
		queue.clear();
	}

	@Override
	public void close() {
		open = false;
	}

	public boolean hasObject() {
		boolean status;
		synchronized (queue) {
			status = !queue.isEmpty();
		}
		
		return status;
	}
	
	@Override
	public Object readObject() {
		if (!open) { return null; }

		Object o;
		synchronized(queue) {
			o = queue.remove(0);
		}

		return o;
	}

	@Override
	public boolean writeObject(Object o) {
		if (!open) { return false; }

		synchronized (queue) {
			queue.add(o);
		}

		return true;
	}

}
package ks.server.controllers;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;
import ks.framework.debug.Debug;
import ks.server.interfaces.IProcessServerMessage;

import org.w3c.dom.Document;

/** Controller to handle logouts. */
public class LogoutController implements IProcessServerMessage {

	public boolean process(Communicator com, Message m) {
		Debug.println ("Observe logout by: " + m.getOriginator());
		
		 // produce request.
        StringBuilder sb = new StringBuilder(Message.responseHeader(true, m.id));
        sb.append("<output><text>");
        sb.append(m.getOriginator()).append(" logged out");
        sb.append("</text></output></response>");
        Document d = Message.construct (sb.toString());
        
        // send to all clients...
        Message r = new Message (d);
        r.setBroadcast();
        
        com.distribute(r);
        return true;
	}
}
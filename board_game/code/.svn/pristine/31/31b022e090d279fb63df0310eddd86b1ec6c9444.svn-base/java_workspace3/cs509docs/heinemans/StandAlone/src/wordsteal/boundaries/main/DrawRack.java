package wordsteal.boundaries.main;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 * Decorator that draws the rack
 * @author Zach
 *
 */
public class DrawRack extends DrawLayerBase {

	public DrawRack(IDrawLayer next, BoardRackPanel brp) {
		super(next, brp);
	}

	@Override
	public void draw(Graphics2D g2D) {
		g2D.setStroke(new BasicStroke());
		
		Rectangle rect = BoardRackPanel.getRackRect();
		
		g2D.setColor(Color.WHITE);
		g2D.fill(rect);
		
		g2D.setColor(Color.BLACK);
		g2D.draw(rect);

		next(g2D);
	}

	@Override
	public String getDescription() {
		
		if(this.nextLayer != null) {
			return this.nextLayer.getDescription() + ", " + this.getClass().getName();
		} else {
			return this.getClass().getName();
		}
	}

}

package contractChecking;

public class TestSafeService2 extends BaseTests {
	public IDuplicate getObject() { 
		return new SafeService2();
	}
	
}

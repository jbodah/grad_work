package ks.client.processor;

import ks.client.controllers.ClientControllerChain;
import ks.client.controllers.DefaultClientChain;
import ks.client.controllers.LoginResponseController;
import ks.client.interfaces.ILobby;
import ks.framework.common.Message;
import ks.framework.debug.Debug;
import ks.server.controllers.DefaultServerChain;

/**
 * Client-side processor of messages received from Server.
 * <p>
 * 
 * @author George Heineman
 */
public class ClientProcessor  {

	/** The core Processor knows about the Lobby for which it is in control. */
	ILobby lobby;

	/** 
	 * Head of the chain of processors. Defaults to one built in. 
	 */
	protected static ClientControllerChain head = new DefaultClientChain();

	/** Return the head of the chain of agents managing the server-side controllers. */
	public static ClientControllerChain head() {
		return head;
	}
	
	/** NOTE: Only to be called by testing code. */
	public static void resetControllers() {
		head = new DefaultClientChain();
	}
	
	/** 
	 * The processor knows the lobby for which it is responsible.
	 * 
	 * @param lob
	 */
	public ClientProcessor (ILobby lob) {
		this.lobby = lob;
	}

	/**
	 * Process the message.
	 * 
	 * @param m
	 * @return
	 */
	public boolean process(Message m) {

		Debug.println("Received:" + m.toString());
		if (m.getName().equals("loginResponse")) {
			return new LoginResponseController().process(lobby, m);
		}
		
		// delegate the processing on to the chain of agents that know of 
		// all controllers on the client side.
		return head.process(lobby, m);
	}

	/**
	 * Connection has been made. Tell lobby.
	 * 
	 * @param status
	 */
	public void connected(boolean status) {
		lobby.connected(status);
		
		if (!status) {
			lobby.append("You have lost your server connection.");
		}
		
	}
}

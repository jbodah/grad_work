package ks.client.interfaces;

import ks.framework.common.Message;

public interface IController {

	/** Process the server response given the original request. */
	void process (ILobby lobby, Message request, Message response);
}


package ks.client.interfaces;

public interface IProcessLobbyInput {
	/**
	 * Process string entered by user.
	 *  
	 * @param s
	 */
	public void process(String s);
}

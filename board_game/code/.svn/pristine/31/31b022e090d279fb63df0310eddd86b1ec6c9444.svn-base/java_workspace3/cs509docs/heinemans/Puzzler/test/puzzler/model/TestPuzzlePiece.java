package puzzler.model;

import java.awt.Polygon;

import junit.framework.TestCase;

public class TestPuzzlePiece extends TestCase {

	public void testPuzzleConstruction() {
		Polygon p = new Polygon();
		PuzzlePiece pp = new PuzzlePiece(10, 100, 200, p);
		
		assertEquals (10, pp.id);
	}
	
	public void testPuzzleLocation() {
		Polygon p = new Polygon();
		PuzzlePiece pp = new PuzzlePiece(10, 100, 200, p);
		pp.setLocation(18,20);
		assertEquals (18, pp.getX());
		assertEquals (20, pp.getY());
		
		// not placed properly
		assertFalse (pp.isProperlyPlaced());
		
		// move X to be proper but not Y
		pp.setLocation(100,300);
		assertFalse (pp.isProperlyPlaced());
		
		// move Y to be proper but not X
		pp.setLocation(70,100);
		assertFalse (pp.isProperlyPlaced());
		
		// now both
		pp.setLocation(100,200);
		assertTrue (pp.isProperlyPlaced());
	}
	
	public void testPuzzleContainment() {
		Polygon p = new Polygon();
		p.addPoint(0,0);
		p.addPoint(99,0);
		p.addPoint(99,99);
		p.addPoint(0,99);
		//p.addPoint(0,0);
		PuzzlePiece pp = new PuzzlePiece(10, 100, 200, p);
		
		assertTrue (pp.contains(45, 50));
		assertFalse (pp.contains(245,50));
		assertFalse (pp.contains(24,520));
		
	}
}

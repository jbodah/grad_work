package gui;

import java.awt.Frame;
import java.awt.Panel;

import controller.CreateController;

public class SampleMain {
	public static void main(String[] args) {

		Frame f = new Frame();
		Panel p = new Panel();
		// set things up, according to the creation controller.
		CreateController controller = new CreateController();
		p.setBackground(java.awt.Color.lightGray);
		p.setLayout(null);
		p.add(controller.createPlayingArea(), null);
		p.add(controller.createStartButton(), null);
		f.add(p);
		f.setSize(800, 400);
		f.setVisible(true);
	}
}

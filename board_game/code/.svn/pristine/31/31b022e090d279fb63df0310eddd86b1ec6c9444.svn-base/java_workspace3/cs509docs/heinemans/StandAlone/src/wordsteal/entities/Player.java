package wordsteal.entities;

import java.awt.Color;
import java.util.ArrayList;

/**
 * Entity representing a player of the game
 * @author zbrod
 *
 */
public class Player {

	/** The player's name */
	public final String name;
	/** The color representing the player on the game board */
	public final Color color;
	
	/** The amount of points the player has won */
	int points = 0;
	/** The amount of bonus points the player has won */
	int bonusPoints = 0;
	/** The list of words the player has placed on the board */
	ArrayList<String> words = new ArrayList<String>();
	
	/**
	 * Constructor
	 * @param name - Player's name
	 * @param color - Player's color
	 */
	public Player(String name, Color color) {
		this.name = name;
		this.color = color;
	}
	
	/**
	 * 
	 * @return Amount of points player has won
	 */
	public int getPoints() {
		return this.points;
	}
	
	/**
	 * 
	 * @param delta Amount to modify point total (can be negative)
	 */
	public void modifyPoints(int delta) {
		this.points += delta;
	}
	
	/**
	 * 
	 * @return Amount of bonus points player has won
	 */
	public int getBonusPoints() {
		return this.bonusPoints;
	}
	
	/**
	 * 
	 * @param points Amount of points to add to player's bonus
	 */
	public void addBonusPoints(int points) {
		this.bonusPoints += points;
	}
	
	/**
	 * Sets player's bonus points back to 0
	 */
	public void clearBonusPoints() {
		this.bonusPoints = 0;
	}
	
	/**
	 * 
	 * @return List of words player has placed on the board
	 */
	public ArrayList<String> getWords() {
		return this.words;
	}
	
	/**
	 * 
	 * @param word Word to be added to player's list
	 */
	public void addWord(String word) {
		this.words.add(word);
	}
	
}

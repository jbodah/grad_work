package dijordan;

import java.awt.event.MouseEvent;
import java.util.Enumeration;

import dijordan.model.PositionCard;
import dijordan.model.Pyramid;
import dijordan.model.SelectionManager;
import dijordan.view.PyramidView;

import ks.client.gamefactory.GameWindow;
import ks.common.model.Card;
import ks.common.model.Column;
import ks.common.model.Deck;
import ks.common.model.Pile;
import ks.common.view.CardImages;
import ks.common.view.DeckView;
import ks.common.view.PileView;
import ks.common.view.RowView;
import ks.common.view.Widget;
import ks.launcher.Main;
import ks.tests.KSTestCase;

public class TestPyramid extends KSTestCase {
	// this is the game under test.
	PyramidGame game;

	// window for game.
	GameWindow gw;

	// widget under inspection
	PyramidView pyramidView;

	DeckView deckView;
	PileView pileView;
	RowView rowView;

	// model backing this widget.
	Pyramid pyramid;
	CardImages images;

	protected void setUp() {
		game = new PyramidGame();

		// Because solitaire variations are expected to run within a container, we need to 
		// do this, even though the Container will never be made visible. Note that here
		// we select the "random seed" by which the deck will be shuffled. We use the 
		// special constant Deck.OrderBySuit (-2) which orders the deck from Ace of clubs
		// right to King of spades.
		gw = Main.generateWindow(game, Deck.OrderBySuit); 

		for (Enumeration<Widget> en = game.getWidgets(); en.hasMoreElements(); ) {
			Widget w = en.nextElement();
			System.out.println(w.getName());
			if (w.getName().equals ("thePyramid")) {
				pyramidView = (PyramidView) w;
				pyramid = (Pyramid) w.getModelElement();
			} else if (w.getName().startsWith("DeckView")) {
				deckView = (DeckView) w;
			} else if (w.getName().startsWith("PileView")) {
				pileView = (PileView) w;
			} else if (w.getName().startsWith("RowView")) {
				rowView = (RowView) w;
			}
		}

		images = game.getCardImages();
	}

	// clean up properly
	protected void tearDown() {
		gw.setVisible(false);
		gw.dispose();
	}


	public void testPyramidAndDiscard() {

		// click on deck until K goes to discard
		for (int i = 0; i < 2; i++) {
			MouseEvent pr = createPressed (game, deckView, 0, 0);
			deckView.getMouseManager().handleMouseEvent(pr);
		}

		// top of rowview
		Column column = (Column) rowView.getModelElement();
		assertEquals (new Card (Card.JACK, Card.DIAMONDS), column.peek());

		// select 2H on the board
		pyramid.select(7, 4);
		game.selectionManager.setSelected(SelectionManager.PYRAMID);

		PositionCard sel = pyramid.peekSelected();
		assertEquals (2, sel.getRank());
		assertEquals (Card.HEARTS, sel.getSuit());

		// click on the row view
		MouseEvent pr = createPressed(game, rowView, 2*images.getOverlap(), 0);
		rowView.getMouseManager().handleMouseEvent(pr);

		// validate moves are done
		assertEquals (2, game.getScoreValue());

		game.undoMove();
		assertEquals (0, game.getScoreValue());

	}

	public void testDiscardAndPyramid() {

		// click on deck until K goes to discard
		for (int i = 0; i < 2; i++) {
			MouseEvent pr = createPressed (game, deckView, 0, 0);
			deckView.getMouseManager().handleMouseEvent(pr);
		}

		// top of rowview
		Column column = (Column) rowView.getModelElement();
		assertEquals (new Card (Card.JACK, Card.DIAMONDS), column.peek());

		// click on the row view
		MouseEvent pr = createPressed(game, rowView, 2*images.getOverlap(), 0);
		rowView.getMouseManager().handleMouseEvent(pr);

		// select 2H on the board MUST go through mouse this time
		pr = createPressed(game, pyramidView, 4*images.getWidth()-20, 5+6*images.getOverlap());
		pyramidView.getMouseManager().handleMouseEvent(pr);

		// validate moves are done
		assertEquals (2, game.getScoreValue());

		game.undoMove();
		assertEquals (0, game.getScoreValue());

	}
	
	public void testPyramidAndJustDrawn() {
		
		// click on deck until K goes to discard
		for (int i = 0; i < 1; i++) {
			MouseEvent pr = createPressed (game, deckView, 0, 0);
			deckView.getMouseManager().handleMouseEvent(pr);
		}
		
		// top of pile
		Pile pile = (Pile) pileView.getModelElement();
		assertEquals (new Card (Card.JACK, Card.DIAMONDS), pile.peek());

		// select 2H on the board
		pyramid.select(7, 4);
		game.selectionManager.setSelected(SelectionManager.PYRAMID);
		
		PositionCard sel = pyramid.peekSelected();
		assertEquals (2, sel.getRank());
		assertEquals (Card.HEARTS, sel.getSuit());

		// click on the row view
		MouseEvent pr = createPressed(game, pileView, 0, 0);
		pileView.getMouseManager().handleMouseEvent(pr);
				
		// validate moves are done
		assertEquals (2, game.getScoreValue());
		
		game.undoMove();
		assertEquals (0, game.getScoreValue());
		
	}

	public void testJustDrawnAndPyramid() {
		
		// click on deck until K goes to discard
		for (int i = 0; i < 1; i++) {
			MouseEvent pr = createPressed (game, deckView, 0, 0);
			deckView.getMouseManager().handleMouseEvent(pr);
		}

		// click on the row view
		MouseEvent pr = createPressed(game, pileView, 0, 0);
		pileView.getMouseManager().handleMouseEvent(pr);
				
		// top of pile
		Pile pile = (Pile) pileView.getModelElement();
		assertEquals (new Card (Card.JACK, Card.DIAMONDS), pile.peek());

		// select 2H on the board MUST go through mouse this time
		pr = createPressed(game, pyramidView, 4*images.getWidth()-20, 5+6*images.getOverlap());
		pyramidView.getMouseManager().handleMouseEvent(pr);
		
		// MOVE is made. now check scores.
		
    	// validate moves are done
		assertEquals (2, game.getScoreValue());
		
		game.undoMove();
		assertEquals (0, game.getScoreValue());
		
	}
}

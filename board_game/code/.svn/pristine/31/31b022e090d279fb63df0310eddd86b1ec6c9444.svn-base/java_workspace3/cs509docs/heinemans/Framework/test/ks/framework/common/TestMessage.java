package ks.framework.common;

import org.w3c.dom.Document;
import org.w3c.dom.Node;


import junit.framework.TestCase;
import ks.framework.common.Message.MessageType;

public class TestMessage extends TestCase {

	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}

	}
	
	/**
	 * Reset back to normal.
	 * <p>
	 * Be careful when using this unconfigure method. It enables testing
	 * but could prove dangerous
	 */
	protected void tearDown() {
		Message.unconfigure();
	}
	
	public void testMessageConfigure() {
		// validate a simple tables
		String s = Message.requestHeader() + "<tables/></request>";
		Document d = Message.construct(s);
		assertTrue (d != null);
		
		Message m = new Message (d);
		assertEquals ("tables", m.getName());
	}
	
	public void testMessageContents() {
		// validate a simple chat
		String s = Message.requestHeader() + "<chat><text>Here is the message</text></chat></request>";
		Document d = Message.construct(s);
		assertTrue (d != null);
		
		// access CHAT
		Message m = new Message (d);
		Node n = m.contents();
		assertEquals ("chat", n.getNodeName());
		
		// access its child, TEXT
		m = new Message (d);
		n = m.contentsChild();
		assertEquals ("text", n.getNodeName());
		
		// this is a request
		assertTrue (m.isRequest());
	}
	
	public void testMessageMetaData() {
		// validate a simple chat
		String s = Message.requestHeader() + "<chat><text>Here is the message</text></chat></request>";
		Document d = Message.construct(s);
		assertTrue (d != null);
		
		Message m = new Message (d);
		
		String orig = "heineman";
		String dest = "admin";
		m.setOriginator(orig);
		m.setRecipient(dest);
		
		assertEquals (dest, m.getRecipient());
		assertEquals (orig, m.getOriginator());
		
		// by default, no message is a broadcast message.
		assertFalse (m.isBroadcast()); 
		
		m.setBroadcast();
		
		assertTrue (m.isBroadcast());
		
		// note that setting of broadcast MUST NOT lose originator or recipient
		assertEquals (dest, m.getRecipient());
		assertEquals (orig, m.getOriginator());
	}
	
	// validate misguided attempts to reconfigure
	public void testReconfigure() {
		try {
			assertTrue (Configure.configure());
			// succeed is let through ok
		} catch (Exception e) {
			fail("This should work");
		}
		
		try {
			Message.configure("ks.xsd", null);
			fail ("Must detect bad configurations.");
		} catch (Exception e) {
			// success
		}
		
	}
	
	// test the inner MessageType class
	public void testMessageType() {
		MessageType m = MessageType.Request;
		MessageType n = MessageType.Response;
		assertTrue (MessageType.Request.same(m));
		
		assertFalse (m.same(null));
		assertTrue (m.same(m));
		assertFalse (n.same(m));
	}
}
package gui;

import java.awt.Graphics;

/**
 * Subclasses should override this class to manage details of how a duck is drawn.
 * 
 * 
 * Because of java.awt requirements on MediaTracker, we must have access to
 * some GUI object so the images can be loaded. Thus the DuckDrawer requires
 * a java.awt.Component object in its constructor. 
 */
public abstract class DuckDrawer {

	/** Perform necessary initialization. */
	public abstract void init();
	
	/** 
	 * Return calculated width of the image.
	 * 
	 * Only meaningful after loadImage() called.
	 */
	public abstract int getWidth();
	
	/** 
	 * Return calculated height of the image.
	 * 
	 * Only meaningful after loadImage() called.
	 */
	public abstract int getHeight();
	
	/**
	 * Place the duck at the given location.
	 * 
	 * @param g   Graphics object into which we will draw.
	 * @param x   upper-left corner X
	 * @param y   upper-left corner Y
	 */
	public abstract void draw (Graphics g, int x, int y);
	
}

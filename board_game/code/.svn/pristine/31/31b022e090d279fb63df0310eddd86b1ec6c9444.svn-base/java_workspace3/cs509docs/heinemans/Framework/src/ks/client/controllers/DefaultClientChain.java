package ks.client.controllers;

import ks.client.interfaces.ILobby;
import ks.framework.common.Message;

public class DefaultClientChain extends ClientControllerChain {

	/**
	 * An agent in the chain processes the message if it can, but if not
	 * then the next agent in the chain has its turn.
	 * 
	 * Entities that extend this class should override this method appropriately.
	 * Check out the ClientChain example
	 */
	@Override
	public boolean process(ILobby lobby, Message m) {
		
		// try someone else...
		return next(lobby, m);
	} 
}

package arch;

import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;

import ks.client.controllers.ClientControllerChain;
import ks.client.interfaces.ILobbyInitialize;
import ks.client.lobby.ConnectFrame;
import ks.client.processor.ClientProcessor;
import ks.framework.common.Configure;

/**
 * This is a sample class that shows how to configure the client to function.
 * Copy (and rename) this into your appropriate location and then you can 
 * begin the process of building up your own server implementation.
 * <p>
 * Note that you will have to provide your response to requests to close the 
 * window. Here it just exits but that may not be what you want.
 * 
 * @author George Heineman
 */
public class ClientArchitecture {
	
	/** Entity created for client. */
	static ConnectFrame cf;
	
	/**
	 * Launch client app.
	 * 
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// Determine the XML schema we are going to use
		if (!Configure.configure()) {
			System.err.println("Unable to configure Message XML");
			return;
		}
		
		// create mock-User manager now outside. You should replace with 
		// the appropriate class construction on your end.
		JPanel tempUserManagerGUI = new JPanel();
		JLabel jLabel = new JLabel();
		jLabel.setText("UMGUI To Be Inserted");
		tempUserManagerGUI.setLayout(new FlowLayout());
		tempUserManagerGUI.add(jLabel, null);
		
		// create mock-Table manager now outside. You should replace with 
		// the appropriate class construction on your end.
		JPanel tempTableManagerGUI = new JPanel();
		JLabel jLabel1 = new JLabel();
		jLabel1.setText("TMGUI To Be Inserted");
		tempTableManagerGUI.setLayout(new FlowLayout());
		tempTableManagerGUI.add(jLabel1, null);
				
		// initialization callback. Client-side groups can pass in 
		// an object that provides this interface into the ConnectFrame
		// constructor and it will be called at the proper time.
		ILobbyInitialize init = new MyLobbyInitialization(tempTableManagerGUI, tempUserManagerGUI);
		
		// all action on this (default) local host. Should there be a need
		// to connect to a different host computer, then you would need 
		// to pass in command-line argument values from 'args' into the 
		// constructor of UserContext so the client knows to which server
		// to connect.
		cf = new ConnectFrame(init);
		cf.addWindowListener(new WindowAdapter() {

			// Override the closing method to exit from the VM.
			// we need no check because this is before user 
			// has actually connected.
			@Override
			public void windowClosing(WindowEvent arg0) {
				System.exit(0);			
			}

		});
		
		// here is where you can augment the chain of client-side controllers
		ClientControllerChain head = ClientProcessor.head();
		head.append(new ClientExtension());
		

		
		cf.setVisible(true);
		
		// running...
	}
}

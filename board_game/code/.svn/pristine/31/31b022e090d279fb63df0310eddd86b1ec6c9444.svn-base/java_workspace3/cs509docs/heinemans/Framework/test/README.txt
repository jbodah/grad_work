I started writing tests for TestMessage first. Seemed easiest to get
started. Stopped at 80%

Then wanted to test Communicator class. This uncovered some problems 
in the implementation (exactly the point, right?). Realized I needed
my own local implementation of ICommunicator which is why the SampleOutput
class was created.

Then moved on to write code to test server. To make this happen I needed
to get some client/server interaction so the ks.server.ipc test package
actually contains code showing how clients and servers connect together.

Status right now (as described in EclEmma):

arch:                          0 
ks.client.controllers:         0
ks.client.ipc:                75.6
ks.client.lobby:               0
ks.client.parser:              0
ks.client.processor:           0
ks.framework.common:          75.5
ks.framework.common.network:  74.3
ks.framework.communicator:   100.0
ks.framework.debug:           47.8
ks.server.controllers:        94.5
ks.server.ipc:                86.7
ks.server.processor:          96.5

Not bad. The goal is to reach for 80% coverage.

Continued reports in EclEmmaReport day-by-day

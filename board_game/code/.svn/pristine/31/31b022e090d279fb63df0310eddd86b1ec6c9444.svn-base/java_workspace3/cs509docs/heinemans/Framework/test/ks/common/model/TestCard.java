package ks.common.model;

import junit.framework.TestCase;

public class TestCard extends TestCase {

	public void testSample() {
		Card c = new Card(10, Card.CLUBS);
		assertEquals (10, c.getRank());
		assertEquals (Card.CLUBS, c.getSuit());
		
		Card c2 = new Card (c);
		assertEquals (c, c2);
		assertEquals (c2, c);
	}
	
	public void testBadNumbers() {
		try {
			new Card(-1, Card.CLUBS);
			fail ("Invalid number should fail.");
		} catch (Exception e) {
			
		}
		
		try {
			new Card(6, -1);
			fail ("Invalid suit should fail.");
		} catch (Exception e) {
			
		}
		try {
			new Card(51, Card.CLUBS);
			fail ("Invalid number should fail.");
		} catch (Exception e) {
			
		}
		
		try {
			new Card(6, 9);
			fail ("Invalid suit should fail.");
		} catch (Exception e) {
			
		}
		
		// make sure no null
		try {
			new Card(null);
			fail ("must protect against null card.");
		} catch (Exception e) {
			
		}
	}
	
	// validate compareTo
	public void testCompareTo() {
		Card c1 = new Card (8, Card.HEARTS);
		Card c2 = new Card (9, Card.SPADES);
		Card c3 = new Card (10, Card.DIAMONDS);
		Card c4 = new Card (10, Card.CLUBS);
		
		assertEquals (-1, c1.compareTo(c2));
		assertEquals (1, c2.compareTo(c1));
		
		assertEquals (0, c3.compareTo(c4));
		
		assertEquals (2, c4.compareTo(c1));
		
		// error case. handled properly
		assertEquals (Integer.MAX_VALUE, c1.compareTo(null));
	}
	
	public void testEquals () {
		Card c1 = new Card (8, Card.HEARTS);
		Card c3 = new Card (10, Card.DIAMONDS);
		Card c4 = new Card (10, Card.CLUBS);
		
		// also do equals check
		assertFalse (c3.equals (c4));
		assertTrue (c1.equals (new Card (8, Card.HEARTS)));
		
		assertFalse (c3.equals (null));
		assertFalse (c3.equals("garbage"));
		
		// test hash
		assertEquals (c1.hashCode(), new Card(8, Card.HEARTS).hashCode());
	}
	
	// face cards
	public void testFaceCardDetection() {
		for (int i = 1; i <= 13; i++) {
			Card c = new Card (i, Card.SPADES);
			if (i >= 11) {
				assertTrue (c.isFaceCard());
			} else {
				assertFalse (c.isFaceCard());
			}
		}
		
		Card c = new Card (1, Card.HEARTS);
		assertTrue (c.isAce());
		
		Card c2 = new Card (2, Card.HEARTS);
		assertFalse (c2.isAce());
	}
	
	// colors
	// face cards
	public void testCardColors() {
		
		
		Card[] cards = new Card[] { new Card (8, Card.HEARTS),
									new Card (9, Card.SPADES),
									new Card (10, Card.DIAMONDS),
									new Card (10, Card.CLUBS) };

		for (int i = 0 ; i < cards.length; i++) {
			for (int j = 0; j < cards.length; j++) {
				if (i %2 == j % 2) { 
					assertTrue (cards[i].sameColor(cards[j]));
					assertFalse (cards[i].oppositeColor(cards[j]));
				} else {
					assertFalse (cards[i].sameColor(cards[j]));
					assertTrue (cards[i].oppositeColor(cards[j]));
				}
				
			}
		}
		
		// invalid
		assertFalse (cards[0].sameColor(null));
		assertFalse (cards[0].oppositeColor(null));
		
		int[] colors = { -5, 77, -5, 77 };
		for (int c : colors) {
			try {
				assertFalse (cards[0].sameColor(c));
				fail ("must prevent ambiguous statement.");
			} catch (IllegalArgumentException iae) {
				// right
			}
			
			try {
				assertFalse (cards[0].oppositeColor(c));
				fail ("must prevent ambiguous statement.");
			} catch (IllegalArgumentException iae) {
				// right
			}
		}
		
	}

	// validate namings
	public void testNames() {
		String[] names = { Card.CLUBSname, Card.DIAMONDSname, Card.HEARTSname, Card.SPADESname };
		
		for (int i = 0; i < names.length; i++) {
			assertEquals (names[i], Card.getSuitName(i+1));  // +1 for card suits
		}
		
		// invalid
		try {
			Card.getSuitName(-1);
			fail ("invalid arg access.");
		} catch (IllegalArgumentException iae) {
			
		}
		
		// invalid
		try {
			Card.getSuitName(99);
			fail ("invalid arg access.");
		} catch (IllegalArgumentException iae) {
			
		}
	}
	
	// testing selected status
	public void testSelections () {
		Card c = new Card (2, Card.HEARTS);
		assertFalse (c.isSelected());
		c.setSelected(true);
		assertTrue (c.isSelected());
		c.setSelected(false);
		assertFalse (c.isSelected());
		
	}
	
	// colors
	// face cards
	public void testSuits() {
		Card[] cards = new Card[] { new Card (8, Card.HEARTS),
									new Card (9, Card.SPADES),
									new Card (10, Card.DIAMONDS),
									new Card (10, Card.CLUBS) };

		assertTrue (cards[2].sameRank(cards[3]));
		assertFalse (cards[1].sameRank(cards[2]));
		
		// default behaviors of null case are ok
		assertFalse (cards[2].sameRank(null));
		assertFalse (cards[2].sameSuit(null));
		
		for (int i = 0 ; i < cards.length; i++) {
			for (int j = 0; j < cards.length; j++) {
				if (i == j) {
					assertTrue (cards[i].sameSuit(cards[j]));
				} else {
					assertFalse (cards[i].sameSuit(cards[j]));
				}				
			}
		}
	}
	
	public void testFaceUpStatus() {
		Card c = new Card (2, Card.HEARTS);
		assertTrue (c.isFaceUp());
		c.setFaceUp(true);
		assertTrue (c.isFaceUp());
		
		c.setFaceUp(false);
		assertFalse (c.isFaceUp());
	}
	
	public void testNaming () {
		Card c = new Card (2, Card.HEARTS);
		assertEquals ("2H", c.getName());
		try {
			c.setName("bad");
			fail("Can't set card names.");
		} catch (Exception e) {
			//success.
		}
		
		
	}
	
}

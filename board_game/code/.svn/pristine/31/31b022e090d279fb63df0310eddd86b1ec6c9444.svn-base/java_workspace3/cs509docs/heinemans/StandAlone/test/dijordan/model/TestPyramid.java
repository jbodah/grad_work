package dijordan.model;

import junit.framework.TestCase;
import ks.common.model.Card;
import ks.common.model.Deck;

public class TestPyramid extends TestCase {

	Pyramid p;
	Deck d;
	
	// start with setup.
	protected void setUp() {
		p = new Pyramid();
		assertTrue (p.empty());
		d = new Deck();
		
		// create and deal
		d.create(Deck.OrderBySuit);
		p.deal(d);
		assertFalse (p.empty());
		
		assertEquals (28, p.countCards());
	}
	
	public void testBadDeals() {
		try {
			p.deal(null);
			fail ("Must prevent null deal");
		} catch (Exception e) {
			
		}
		
		try {
			Deck dd = new Deck();
			dd.removeAll();
			p.deal(dd);
			fail ("Must prevent deal from empty deck");
		} catch (Exception e) {
			// success
		}
		
		// no overdeals;
		try {
			Deck dd = new Deck();
			p.deal(dd);
			fail ("Must prevent over deal");
		} catch (Exception e) {
			// success
		}
	}
	
	public void testAddRemove() {
		assertFalse (p.isCovered(7,6));
		
		// validate we can't add here
		PositionCard pc = new PositionCard(Card.KING, Card.SPADES, 7, 6);
		assertFalse (p.addCard(pc));
		try {
			assertFalse (p.addCard(null));
			fail ("Must prevent null addition");
		} catch (IllegalArgumentException iae) {
			// success
		}
		
		// remove existing card at (7,6)
		PositionCard exist = p.getCard(7, 6);
		assertEquals (Card.KING, exist.getRank());
		assertEquals (Card.DIAMONDS, exist.getSuit());
		
		assertFalse (p.isCardThere(7, 6));
		
		// now can add
		assertTrue (p.addCard(pc));
	}
	
	public void testSelected() {
		p.deselect();
		
		assertTrue (p.getSelected() == null);
		assertTrue (p.peekSelected() == null);
		
		p.select(7, 6);
		p.deselect();
		assertTrue (p.peekSelected() == null);
		p.select(7,6);
		
		PositionCard peek = p.peekCard(7, 6);
		PositionCard peekS = p.peekSelected();
		PositionCard pc = p.getSelected();
		assertEquals (7, pc.getRow());
		assertEquals (6, pc.getPosition());
		
		assertTrue (peek == pc);

		assertTrue (peekS == peek);
		
		// can't select multiple cards
		try {
			assertFalse (p.select(1, 1));
			fail ("Can't select multiples");
		} catch (IllegalStateException ise) {
			// success
		}
		
		p.deselect();
		
		assertTrue (p.peekSelected() == null);
		
		// can't select covered cards.
		assertFalse (p.select(1, 1));
	}
	
	public void testCoverage() {
		assertTrue (p.isCovered(1,1));
		assertTrue (p.isCovered(p.peekCard(1, 1)));
		
		assertTrue (p.isCardThere(1, 1));
		
		// get all cards in the final row
		for (int i = 1; i <= 7; i++) {
			p.getCard(7, i);
		}
		
		assertFalse (p.isCovered(6, 1));
		
		try {
			assertFalse (p.isCovered(null));
			fail ("Must detect null coverage test.");
		} catch (Exception e) {
			// success
		}
		
	}
	
	public void testBadPeeks() {
		try {
			assertTrue (null == p.peekCard(-3, 3));
			fail ("Must detect invalid peek requests.");
		} catch (Exception e) {
			// success
		}
		
		try {
			assertTrue (null == p.peekCard(3, -3));
			fail ("Must detect invalid peek requests.");
		} catch (Exception e) {
			// success
		}
	}
	
	public void testConstructors() {
		Pyramid pp = new Pyramid(7);
		assertEquals (7, pp.countRows());
		assertEquals (0, pp.countCards());
		
		pp = new Pyramid("test");
		assertEquals (7, pp.countRows());
		
		pp = new Pyramid(4, "test2");
		assertEquals (4, pp.countRows());
			
		try {
			pp = new Pyramid(0, "bad");
			fail ("Must detect attempts to create empty pyramid");
		} catch (Exception e) {
			// success
		}
	}
	
	public void testGetCard() {
		try {
			p.getCard(1, 10);
			fail ("Must detect invalid get requests.");
		} catch (Exception e) { 
			// success
		}
		
		try {
			p.getCard(10, 1);
			fail ("Must detect invalid get requests.");
		} catch (Exception e) { 
			// success
		}
		
		assertTrue (null != p.getCard(7, 6));
		
		try {
			p.getCard(7, 6);
			fail ("Must detect invalid get requests from empty slots");
		} catch (Exception e) { 
			// success
		}
		
		try {
			p.getCard(1, 1);
			fail ("Must detect invalid get requests from covered slots");
		} catch (Exception e) { 
			// success
		}
	}
	
	public void testIsCardThere() {
		try {
			p.isCardThere(1, 10);
			fail ("Must detect invalid isCardThere requests.");
		} catch (Exception e) { 
			// success
		}
		
		try {
			p.isCardThere(10, 1);
			fail ("Must detect invalid isCardThere requests.");
		} catch (Exception e) { 
			// success
		}
	}
	
	public void testIsCovered() {
		try {
			p.isCovered(1, 10);
			fail ("Must detect invalid isCovered requests.");
		} catch (Exception e) { 
			// success
		}
		
		try {
			p.isCovered(10, 1);
			fail ("Must detect invalid isCovered requests.");
		} catch (Exception e) { 
			// success
		}
		
		
		// remove and try again.
		assertTrue (null != p.getCard(7, 6));
		
		try {
			p.isCovered(7, 6);
			fail ("Must detect invalid isCovered request when card is no longer there.");
		} catch (Exception e) { 
			// success
		}
	}
	
	public void testSelect() {
		try {
			p.select(1, 10);
			fail ("Must detect invalid select requests.");
		} catch (Exception e) { 
			// success
		}
		
		try {
			p.select(10, 1);
			fail ("Must detect invalid select requests.");
		} catch (Exception e) { 
			// success
		}
		
		
		// remove and try again.
		assertTrue (null != p.getCard(7, 6));
		
		try {
			p.select(7, 6);
			fail ("Must detect invalid select request when card is no longer there.");
		} catch (Exception e) { 
			// success
		}
	}
}

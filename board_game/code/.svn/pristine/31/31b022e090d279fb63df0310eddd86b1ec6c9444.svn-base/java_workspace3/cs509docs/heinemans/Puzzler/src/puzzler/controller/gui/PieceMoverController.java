package puzzler.controller.gui;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


import puzzler.model.Puzzle;
import puzzler.model.PuzzlePiece;
import puzzler.view.PuzzleManipulation;
import puzzler.view.PuzzlePieceView;
import puzzler.view.Sounds;

/**
 * Controller responsible for tracking mouse events (Press, Release
 * and Drag) to manipulate the location of puzzle pieces.
 * <p>
 * Due to the nature of Swing, this controller is a bit of a hybrid. While
 * the mouse drag is in effect, it manipulates the location of each piece
 * in transit, only confirming the change to the model when the user
 * releases the mouse.
 * 
 * @author George Heineman
 */
public class PieceMoverController extends MouseAdapter {

	/** View being controlled. */
	PuzzleManipulation puzzlePanel;
	
	/** Model being manipulated. */
	Puzzle puzzle;
	
	/** Anchor point where first grabbed and delta from that location. */
	Point anchor;
	int deltaX;
	int deltaY;

	/** Currently selected piece (or null if none). */
	PuzzlePiece selected;
	
	/**
	 * Controller for mouse events knows about the puzzle panel which
	 * contains all pieces.
	 *
	 * @param puzzlePanel
	 */
	public PieceMoverController(PuzzleManipulation puzzlePanel) {
		this.puzzlePanel = puzzlePanel;
	}
	
	/**
	 * Update the puzzle being managed by this controller.
	 */
	public void setPuzzle(Puzzle puzzle) {
		this.puzzle = puzzle;
	}
	
	/**
	 * React to mouse press events by selecting the puzzle piece on which
	 * the user clicked.
	 * 
	 * End result of this method is to properly set {@link #selected}, either
	 * to <code>null</code> or to a valid {@link PuzzlePiece} in the panel.
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		// no puzzle? no behavior!
		if (puzzle == null) { return; }
		
		anchor = e.getPoint();
		
		// pieces are returned in order of Z coordinate
		for (PuzzlePiece pp : puzzle) {
			Point relative = new Point (anchor);
			relative.translate(-pp.getX(), -pp.getY());
			
			if (pp.shape.contains(relative)) {
				
				// once in place, can't move
				if (pp.isProperlyPlaced()) {
					continue;
				}
				
				selected = pp;
				
				// set anchor for smooth moving
				deltaX = relative.x;
				deltaY = relative.y;
				
				// bring to front in model and update GUI accordingly
				puzzle.bringToFront(pp.id);
				puzzlePanel.bringToFront(pp.id);
				return;
			}
		}
		
		selected = null;
	}
	
	/**
	 * Once move is completed, update the model.
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		// no puzzle? no behavior!
		if (puzzle == null) { return; }

		// now released we can update the model.
		selected = null;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// no puzzle? no behavior!
		if (puzzle == null) { return; }

		if (selected == null) { return; }
		snapLocation(selected, e.getX() -  deltaX, e.getY() - deltaY);
		
		// if piece is properly placed, make the sound
		if (selected.isProperlyPlaced()) {
			Sounds.playPieceFit();
		}
	}

	/**
	 * Properly snaps location of widget to align with grid.
	 * 
	 * @param widget
	 * @param x
	 * @param y
	 */
	private void snapLocation(PuzzlePiece pp, int x, int y) {
		x = (x/puzzlePanel.getGridSize())*puzzlePanel.getGridSize();
		y = (y/puzzlePanel.getGridSize())*puzzlePanel.getGridSize();
		pp.setLocation(x, y);
		
		// now that we have updated the pieces location, we need to 
		// refresh the view. Either this is handled in a publish/subscribe
		// model based upon the puzzle piece or we do it manually. In 
		// this example, we do it manually.
		PuzzlePieceView ppv = puzzlePanel.getPiece(pp.id);
		ppv.setLocation(x,y);
	}
}


package wordsteal.entities;

import java.util.ArrayList;

/**
 * Entity representing the game's tile rack
 * @author zbrod
 *
 */
public class Rack {

	/** Maximium amount of tiles the rack can hold */
	public static final int maxTiles = 7;
	
	/** List of tiles held in the rack */
	ArrayList<Tile> tiles = new ArrayList<Tile>();
	
	/**
	 * 
	 * @return List of tiles held in the rack
	 */
	public ArrayList<Tile> getTiles() {
		return this.tiles;
	}
	
	/**
	 * 
	 * @param tile Tile to be added to the rack
	 */
	public void addTile(Tile tile) {
		if(this.tiles.size() < Rack.maxTiles) {
			this.tiles.add(tile);
		}
	}
	
	/**
	 * 
	 * @param tile Tile to be added into the rack
	 * @param index Position at which to insert the tile (0 - maxTiles-1)
	 */
	public void insertTile(Tile tile, int index) {
		if(this.tiles.size() < Rack.maxTiles) {
			this.tiles.add(index, tile);
		}
	}
	
	/**
	 * 
	 * @param tile Tile to be removed from the rack
	 */
	public void removeTile(Tile tile) {
		this.tiles.remove(tile);
	}
	
	/**
	 * 
	 * @param index Index of tile to be removed from the rack
	 * @return Tile removed from the rack
	 */
	public Tile removeTile(int index) {
		return this.tiles.remove(index);
	}
	
	/** Return convenient string for debugging. */
	public String toString () {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < tiles.size(); i++) {
			sb.append(tiles.get(i));
		}
		
		return sb.toString();
	}
	
}

package ks.server.controllers;

import junit.framework.TestCase;

public class TestServerControllerChain extends TestCase {

	public void testOneLink() {
		ServerControllerChain scc1 = new ServerControllerChain();
		ServerControllerChain scc2 = new ServerControllerChain();
		scc1.append(scc2);
		
		assertTrue (scc1.next == scc2);
	}
	
	public void testTwoLink() {
		ServerControllerChain scc1 = new ServerControllerChain();
		ServerControllerChain scc2 = new ServerControllerChain(scc1);
		ServerControllerChain scc3 = new ServerControllerChain(scc2);
		
		
		assertTrue (scc3.next == scc2);
		assertTrue (scc2.next == scc1);
	}
	
	public void testTwoLinkAppend() {
		ServerControllerChain scc1 = new ServerControllerChain();
		ServerControllerChain scc2 = new ServerControllerChain();
		ServerControllerChain scc3 = new ServerControllerChain();
		
		scc1.append(scc2);
		scc1.append(scc3);
		
		assertTrue (scc1.next == scc2);
		assertTrue (scc2.next == scc3);
	}
	
	public void testTwoMessage() {
		ServerControllerChain scc1 = new ServerControllerChain();
		ServerControllerChain scc2 = new ServerControllerChain();
		ServerControllerChain scc3 = new ServerControllerChain();
		
		scc1.append(scc2);
		scc1.append(scc3);
		
		// fake generate
		assertFalse (scc1.process(null, null));
	}
}

NOTE: 
  * Add availableMoves
  * Add 'auto-solve' once the game has been provably won...
  
       A card is unneeded when no lower-rank cards of the opposite color remain 
       in the playing area. 
  
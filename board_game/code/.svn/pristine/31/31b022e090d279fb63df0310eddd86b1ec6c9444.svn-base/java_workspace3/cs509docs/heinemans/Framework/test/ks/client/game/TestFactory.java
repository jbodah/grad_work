package ks.client.game;

import java.util.Collection;
import java.util.Iterator;
import java.util.Properties;

import junit.framework.TestCase;

public class TestFactory extends TestCase {

	public void testCreate() {
		Iterator<String> it = Factory.validGameTypes();
		assertTrue (it.hasNext());
	}
	
	public void testASolitaire() {
		Properties p = new Properties();
		String s = "heineman.Klondike";
		p.setProperty("game", s);
		
		Properties options = new Properties();
		
		GameInformation gi = Factory.create(p, options);
		
		assertEquals (s, gi.game);
	}
	
	public void testWordsteal() {
		Properties p = new Properties();
		String ws = "wordsteal.Wordsteal";
		p.setProperty("game", ws);
		
		Properties options = new Properties();
		
		GameInformation gi = Factory.create(p, options);
		
		assertEquals (ws, gi.game);
	}
	
	public void testInvalid() {
		Properties p = new Properties();
		String ws = "bogus-game";
		p.setProperty("game", ws);
		
		Properties options = new Properties();
		
		try {
			Factory.create(p, options);
			fail ("must detect invalid options");
		} catch (Exception e) {
			// success
		}
		
		try {
			p = new Properties();
			p.setProperty("game", "java.lang.String");
			Factory.create(p, options);
			fail ("must detect invalid options");
		} catch (Exception e) {
			// success
		}
	}
	
	public void testDefaults() {
		Properties p = GameManager.defaultOptions("java.lang.String");
		assertTrue (p == null);
		
		Iterator<String> set = GameManager.validGameTypes();
		while (set.hasNext()) {
			String type = set.next();
			p = GameManager.defaultOptions(type);
			assertFalse (p.size() == 0);
		}
	}
	
	public void testValidOptions() {
		Collection<String> set = GameManager.validOptions("java.lang.String");

		assertTrue (set == null);
		Iterator<String> types = GameManager.validGameTypes();
		while (types.hasNext()) {
			String type = types.next();
			set = GameManager.validOptions(type);
			assertFalse (set == null);
		}
	}
	
}

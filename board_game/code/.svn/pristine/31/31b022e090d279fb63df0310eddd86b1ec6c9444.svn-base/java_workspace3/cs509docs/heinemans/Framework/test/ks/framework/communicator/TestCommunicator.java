package ks.framework.communicator;


import java.util.ArrayList;

import org.w3c.dom.Document;


import junit.framework.TestCase;
import ks.framework.common.Configure;
import ks.framework.common.Message;

public class TestCommunicator extends TestCase {

	/** Communicator under test. */
	Communicator com;

	final String user1 = "heineman";
	SampleOutput out1;
	final String user2 = "observer2";
	SampleOutput out2;
	final String user3 = "observer3";
	SampleOutput out3;

	@Override
	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}

		out1 = new SampleOutput();
		out2 = new SampleOutput();
		out3 = new SampleOutput();

		com = new Communicator();
		com.connectUser(user1, out1);
		com.connectUser(user2, out2);
		com.connectUser(user3, out3);
	}

	/**
	 * Reset back to normal.
	 */
	@Override
	protected void tearDown() {
		Message.unconfigure();
		out1 = null;
		out2 = null;
		out3 = null;
		com = null;
	}

	public void testBasic() {

		// send a message from user1 -> user2
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\"><tables/></request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);

		m1.setOriginator(user1);
		m1.setRecipient(user2);

		assertTrue(com.distribute(m1));

		// can read object from user2 but that's it
		assertEquals (m1, out2.readObject());
		assertFalse (out1.hasObject());
		assertFalse (out3.hasObject());
	}


	public void testBroadcast() {

		// send a message from user1 -> user2
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\"><tables/></request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);

		// this is to be broadcast to everyone
		m1.setOriginator(user1);
		m1.setRecipient(user1);
		m1.setBroadcast();

		assertTrue(com.distribute(m1)); 

		// everyone gets this EXCEPT for user1, the originator.
		// While it's a broadcast, the originator doesn't get message.
		assertEquals (m1, out1.readObject());
		assertEquals (m1, out2.readObject());
		assertEquals (m1, out3.readObject());
	}
	
	public void testBroadcastAllButOriginator() {

		// send a message from user1 -> user2
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\"><tables/></request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);

		// this is to be broadcast to everyone but the originator
		m1.setOriginator(user1);
		m1.setBroadcast();

		assertTrue(com.distribute(m1)); 

		// everyone gets this EXCEPT for user1, the originator.
		// While it's a broadcast, the originator doesn't get message.
		assertEquals (m1, out2.readObject());
		assertFalse (out1.hasObject());
		assertEquals (m1, out3.readObject());
	}
	
	// writing this test case helped detect a defect in my code. I had
	// the logic for partial broadcast BACKWARDS.
	public void testDistribution() {

		// send a message from user1 -> user2
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\"><tables/></request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);

		// this is to be sent to just two users.
		m1.setOriginator(user1);
		ArrayList<String> users = new ArrayList<String>();
		users.add(user2);
		users.add(user3);
		
		assertTrue(com.distribute(users.iterator(), m1));

		// everyone gets this EXCEPT for user1, the originator.
		// While it's a broadcast, the originator doesn't get message.
		assertEquals (m1, out2.readObject());
		assertFalse (out1.hasObject());
		assertEquals (m1, out3.readObject());
		
		// now show empty iterator
		users.clear();
		assertFalse (com.distribute(users.iterator(), m1));

		// no message sent
		assertFalse (out1.hasObject());
		assertFalse (out2.hasObject());
		assertFalse (out3.hasObject());
		
	}
	
	public void testDisconnect() {
		assertTrue (com.isOnline(user1));
		com.disconnectUser(user1);
		assertFalse (com.isOnline(user1));
	}

	public void testNoOp() {
		com.disconnectUser(user2);
		com.disconnectUser(user3);
		
		// send a message from user1 -> user2
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\"><tables/></request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);

		m1.setOriginator(user1);
		m1.setBroadcast();

		// nothing to send, since no other users.
		assertFalse (com.distribute(m1)); 
	}
	
	// communicator at 87.6% the following are just to get as much as possible.
	public void testDisconnectAndConnect() {
		assertTrue (com.isOnline(user1));
		
		// can't disconnect multiple times
		assertTrue (com.disconnectUser(user1));
		assertFalse(com.disconnectUser(user1));
		
		// can't connect multiple times with same user.
		SampleOutput newSample = new SampleOutput();
		assertTrue (com.connectUser("new_user", newSample));
		assertFalse(com.connectUser("new_user", newSample));
		
		// validate that same ICommunicator object is not mistakenly
		// connected-to on different users. Note when writing this test
		// case, I actually added this functionality which I hadn't thought
		// of until I had started testing.
		SampleOutput copy = new SampleOutput();
		assertTrue (com.connectUser("new_user_xx", copy));
		try {
			com.connectUser("new_user_yy", copy);
			fail ("Mustn't allow same agent with multiple users.");
		} catch (IllegalArgumentException iae) {
			// supposed to happen
		}
	}
	
	// to get that last elusive 100% coverage.
	public void testNonexistentSingleRecipient() {
		// send a message from user1 -> user2
		String s = "<request version=\"1.0\" id=\"589a39591271844e3fbe32bbb9281ad9\"><tables/></request>";
		Document d = Message.construct(s);
		Message m1 = new Message(d);
		
		m1.setRecipient("No One I Know");
		assertFalse (com.distribute(m1));
	}
}

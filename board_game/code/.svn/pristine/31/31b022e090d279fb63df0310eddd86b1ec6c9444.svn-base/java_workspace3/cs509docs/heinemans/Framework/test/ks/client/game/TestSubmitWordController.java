package ks.client.game;

import java.util.ArrayList;
import java.util.Properties;

import wordsteal.boundaries.main.MainJPanel;
import wordsteal.entities.Board;
import wordsteal.entities.Cell;
import wordsteal.entities.Game;
import wordsteal.entities.Rack;
import wordsteal.entities.Tile;
import junit.framework.TestCase;
import ks.client.game.wordsteal.SubmitWordController;
import ks.client.game.wordsteal.WordstealGameInformation;

/**
 * Makes sure we have tied in the functionality appropriately.
 * 
 * @author George Heineman
 *
 */
public class TestSubmitWordController extends TestCase {


	GameManager gm;
	
	int tableID = 13;
	String me = "982";
	Properties options;
	Properties gameOptions;
	Properties playerIDs;
	SampleInterface sample;
	
	String player1 = "1124";
	String player2 = "997";
	
	/** My info. */
	WordstealGameInformation info;
	
	/** IWordstealApp. */
	MainJPanel mjp;
	
	/** internal info. */
	Game game;
	
	// create the wordsteal game/app
	protected void setUp() {
		gm = GameManager.instance();
		Properties options = new Properties();
		// default ones from message
		options.setProperty("seed", "1234");
		options.setProperty("game", "wordsteal.Wordsteal");
	
		sample = new SampleInterface();
		
		// game specific ones for wordsteal variations. note
		// that the pointsToWin of 4 means any word played of
		// four or more letters will win the game.
		Properties gameOptions = new Properties();
		gameOptions.setProperty("noS", "true");
		gameOptions.setProperty("pink", "true");
		gameOptions.setProperty("turnTime", "80");
		
		// make score low enough that we can actually win a game, but
		// high enough that we can try it out
		gameOptions.setProperty("pointsToWin", "10");
		
		// player ids and real names (example where one has no real name)
		Properties players = new Properties();
		players.setProperty(me,  "George Heineman");
		players.setProperty(player1, "Paul Simon");
		players.setProperty(player2,  "");
		
		// note that for the purpose of this demonstration, I am assuming
		// that I am the moderator. This need not be the case. Indeed, 
		// getting this bit of logic right will be a partnership between
		// myself and all other groups.
		
		// forgot that Properties has no guaranteed ordering.
		ArrayList<String> order = new ArrayList<String>();
		order.add("982");
		order.add(player1);
		order.add(player2);
		
		// request creation of game window. Will start in locked mode.
		assertTrue (gm.createGameWindow(tableID, me, options, gameOptions, order, players, sample));
		
		// extract constructed info.
		info = (WordstealGameInformation) gm.frame.getGameInformation();
		mjp = (MainJPanel) info.getGameContainer();
		game = mjp.getGame();
	}
	
	protected void tearDown() {
		gm.frame.setVisible(false);
		gm.frame.dispose();
	}
	
	// have to at least place a single tile
	public void testNoMoveMade() {
		assertFalse (new SubmitWordController(mjp).process(info, sample));
	}
	
	private void helperPlaceTile(Tile t, int row, int col) {
		Rack rack = game.getRack();
		Board board = game.getBoard();
		Cell cell = board.getCell(row, col);
		cell.setTile(t);
		rack.removeTile(t); 
	}
	
	// place some tiles from Rack (initial OUSLHEH)
	public void testHouse() {
		Rack rack = game.getRack();
		ArrayList<Tile> allTiles = rack.getTiles();
		
		// as they are placed, they are deleted from the rack, and positions adjust
		// this is why we start from the RIGHT and add in that order.
		Tile t = allTiles.get(6);  // H
		helperPlaceTile(t, 6, 6);
		
		t = allTiles.get(5);       // E
		helperPlaceTile(t, 6, 10);
		
		t = allTiles.get(2);       // S
		helperPlaceTile(t, 6, 9);
				
		t = allTiles.get(1);       // U
		helperPlaceTile(t, 6, 8);

		t = allTiles.get(0);       // O
		helperPlaceTile(t, 6, 7);
		
		assertTrue (new SubmitWordController(mjp).process(info, sample));
	}
	
	// place some tiles from Rack (initial OUSLHEH)
	public void testInvalidWord() {
		Rack rack = game.getRack();
		ArrayList<Tile> allTiles = rack.getTiles();
		
		// as they are placed, they are deleted from the rack, and positions adjust
		// this is why we start from the RIGHT and add in that order.
		Tile t = allTiles.get(6);  // H
		helperPlaceTile(t, 6, 6);
		
		t = allTiles.get(5);       // E
		helperPlaceTile(t, 6, 10);
		
		t = allTiles.get(1);       // U
		helperPlaceTile(t, 6, 8);
		
		assertFalse (new SubmitWordController(mjp).process(info, sample));
	}
	
	
}

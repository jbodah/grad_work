package wordsteal.entities;

/**
 * Class representing movement of a tile from one location to another
 * @author Zach
 *
 */
public class TileMovement {

	/** Original location of the tile */
	ITileLocation srcLocation;
	/** Destination location of the tile */
	ITileLocation destLocation;
	
	/**
	 * Constructor
	 * @param srcLocation Original location of the tile
	 * @param destLocation Destination location of the tile
	 */
	public TileMovement(ITileLocation srcLocation, ITileLocation destLocation) {
		
		this.srcLocation = srcLocation;
		this.destLocation = destLocation;
	}
	
	/** Undoes this movement */
	public void undo() {
		
		this.srcLocation.addTile(this.destLocation.removeTile());
	}
	
	/** Redoes this movement */
	public void redo() {
		
		this.destLocation.addTile(this.srcLocation.removeTile());
	}
}

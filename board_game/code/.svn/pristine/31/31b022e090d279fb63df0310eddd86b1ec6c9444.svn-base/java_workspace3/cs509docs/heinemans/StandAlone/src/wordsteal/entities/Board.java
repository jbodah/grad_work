package wordsteal.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

import wordsteal.util.BoardLocation;


/**
 * Class representing the game board
 * @author zbrod
 *
 */
public class Board {

	/**
	 * Multidimensional array representing the structure of the board
	 * 0 = white cell,
	 * 1 = green,
	 * 2 = pink,
	 * 3 = orange
	 */
	public static final int[][] boardStructure = {{2,0,0,0,0,0,2,0,0,0,0,0,2},
		{0,0,0,0,0,3,0,3,0,0,0,0,0},
		{0,0,0,0,3,0,0,0,3,0,0,0,0},
		{0,0,0,3,0,0,0,0,0,3,0,0,0},
		{0,0,3,0,0,0,0,0,0,0,3,0,0},
		{0,3,0,0,0,0,0,0,0,0,0,3,0},
		{2,0,0,0,0,0,1,0,0,0,0,0,2},
		{0,3,0,0,0,0,0,0,0,0,0,3,0},
		{0,0,3,0,0,0,0,0,0,0,3,0,0},
		{0,0,0,3,0,0,0,0,0,3,0,0,0},
		{0,0,0,0,3,0,0,0,3,0,0,0,0},
		{0,0,0,0,0,3,0,3,0,0,0,0,0},
		{2,0,0,0,0,0,2,0,0,0,0,0,2}};

	/** Constant representing the up direction (for keyboard purposes) */
	public static final int UP = 0;
	/** Constant representing the down direction (for keyboard purposes) */
	public static final int DOWN = 1;
	/** Constant representing the left direction (for keyboard purposes) */
	public static final int LEFT = 2;
	/** Constant representing the right direction (for keyboard purposes) */
	public static final int RIGHT = 3;

	/** Hash storing the cells that make up the board, keyed by their position */
	HashMap<BoardLocation, Cell> cells = new HashMap<BoardLocation, Cell>();

	/**
	 * Constructor that sets up the tiles
	 */
	public Board() {

		// Loop through the board structure and create each cell
		// r = row, c = column
		for(int r = 0; r < Board.boardStructure.length; r++) {
			for(int c = 0; c < Board.boardStructure[r].length; c++) {

				BoardLocation bl = new BoardLocation(r,c);
				CellColor color;

				switch(boardStructure[r][c]) {
				case 0: color = CellColor.White;  break;
				case 1: color = CellColor.Green; break;
				case 2: color = CellColor.Pink; break;
				case 3: color = CellColor.Orange; break;
				default: color = CellColor.White; break;
				}

				this.cells.put(bl, new Cell(bl, color));
			}
		}
	}

	/**
	 * Overloaded method to get a cell based on row col
	 * @param row Row of the cell
	 * @param col Column of the cell
	 * @return
	 */
	public Cell getCell(int row, int col) {
		return this.cells.get(new BoardLocation(row, col));
	}

	/**
	 * Get's a cell based on a BoardLocation
	 * @param bl BoardLocation corresponding to the location of the cell
	 * @return
	 */
	public Cell getCell(BoardLocation bl) {
		return this.cells.get(bl);
	}

	/**
	 * Gets the cell occupied by the given tile on the board
	 * @param tile Tile that is located on the board
	 * @return
	 */
	public Cell getCellFromTile(Tile tile) {

		// Loop through cells
		for(int r = 0; r < Board.boardStructure.length; r++) {
			for(int c = 0; c < Board.boardStructure.length; c++) {

				// Extract tile from cell
				Cell cell = getCell(r, c);
				Tile tile2 = cell.getTile();

				// If the cell contains a tile and...
				if(tile2 != null) {
					// ...the tile is the same as the one we're looking for...
					if(tile == tile2) {
						// ...return it
						return cell;
					}
				}
			}
		}

		// Otherwise, return null
		return null;
	}

	/**
	 * Gets the newly placed tiles on the board
	 * @return WordHashTable containing the board location and cells of newly placed tiles
	 */
	public Hashtable<BoardLocation, Cell> getNewTiles(){
		//Use a hash table to store the cells of the newly placed tiles
		Hashtable<BoardLocation, Cell> WordHashTable = new Hashtable<BoardLocation, Cell>();

		//Loop through cells and retrieve the newly placed tiles on the board without owners,
		//use the getCell method in the board entity to retrieve the cells and their board locations,
		//for(int r = Board.boardStructure.length - 1; r >= 0; r--) {
		//for(int c = Board.boardStructure.length - 1; c >= 0; c--) {
		for(int r = 0; r < Board.boardStructure.length; r++) {
			for(int c = 0; c < Board.boardStructure.length; c++) {
				Cell cell = getCell(r, c);
				if (cell.getTile() != null){
					if (cell.getTile().getOwner() == null){
						BoardLocation bl = new BoardLocation(r,c);
						WordHashTable.put(bl, cell);
					}
				}

			}
		}
		return WordHashTable;
	}



	/**
	 * clearBoard steps through all of the cells on the board and sets tiles equal to null
	 */
	public void clearBoard() {
		//Loop through cells and set all tiles to null
		for(int r = Board.boardStructure.length - 1; r >= 0; r--) {
			for(int c = Board.boardStructure.length - 1; c >= 0; c--) {
				if (getCell(r, c).getTile() != null){
					getCell(r, c).setTile(null);
				}
			}
		}
	}



	/**
	 * Given a cell on the board and a direction, this function will return
	 * the next cell in the direction specified relative to the given cell.
	 * If isOccupied is set, it will return the first cell that has a tile.
	 * Otherwise, it will return the first cell without a tile.
	 * 
	 * The purpose of this method is for keyboard accessibility. If the user
	 * has not "grabbed" a tile with the keyboard, and he or she presses an
	 * arrow key, we want to highlight the next legal tile on the board in
	 * the direction of the arrow key relative to the currently highlighted
	 * tile. If the user has grabbed a tile, we need to find the next empty
	 * cell in that direction to place the tile in.
	 * 
	 * The strategy taken at this time is thus: ideally, the function tries
	 * to find an eligible cell in it's own row/col (depending on the
	 * direction). If it can't, it searches the adjacent rows/cols, and
	 * continues to do so outward, alternating between sides.
	 * 
	 * @param cell The currently highlighted/grabbed cell
	 * @param direction The direction to search the board relative to the cell
	 * @param isOccupied Whether or not we are looking for a cell with a tile
	 * @return The next cell in that direction relative to the given cell
	 */
	public Cell getNextCell(Cell cell, int direction, boolean isOccupied) {

		// Depending on which direction we are searching, either the cell's
		// row or its column is going to be static, while the other will
		// be changed as the search progresses. rowOrCol represents the
		// one that will be changing (at least on the higher level). For
		// example, if the user pressed the up or down keys, this function
		// will attempt to find a valid cell in the same column. However,
		// if that fails, we will be searching adjacent columns, and so
		// rowOrCol will represent the search's current column, starting
		// with the cell's own column.
		int rowOrCol = cell.boardLocation.col;

		// However, if the user pressed left or right, it will be the 
		// adjacent rows that will be searched, starting with the cell's
		// own row.
		if(direction == Board.LEFT || direction == Board.RIGHT) {
			rowOrCol = cell.boardLocation.row;
		}

		// Delta represents how many rows/columns out relative to the cell's
		// own row/column we are search. It starts at 0, representing the
		// cell's own row/column. Then delta becomes one, and is added/sub'd
		// from rowOrCol to search the adjacent rows/columns. If that fails,
		// then it searches the two rows/columns adjacent to those, and so
		// on.
		for(int delta = 0; delta < Board.boardStructure.length; delta++) {

			// If we are in the cell's own row/col, we only need to search
			// once
			if(delta == 0) {

				Cell tempCell = getNextCellInRowCol(cell, rowOrCol, direction, isOccupied);

				if(tempCell != null) {
					return tempCell;
				} else {
					// We only need to search once, so we continue
					continue;
				}
			} 

			// We now add delta to the rowOrCol, making sure it is not off
			// the board
			if(rowOrCol + delta < Board.boardStructure.length) {

				Cell tempCell = getNextCellInRowCol(cell, rowOrCol + delta, direction, isOccupied);
				if(tempCell != null) {
					return tempCell;
				}
			}

			// We then subtract delta to the rowOrCol, making sure it is not off
			// the board
			if(rowOrCol - delta >= 0) {

				Cell tempCell = getNextCellInRowCol(cell, rowOrCol - delta, direction, isOccupied);
				if(tempCell != null) {
					return tempCell;
				}
			}

		}	

		// If we search the entire board space to the direction of the source
		// cell and nothing is found, we return null
		return null;
	}

	/**
	 * This is an internal method used by getNextCell. It searches one
	 * row/col for a valid cell.
	 * @param cell The cell passed to getNextCell
	 * @param rowCol The row/col that is static
	 * @param direction Direction of the search
	 * @param isOccupied Whether or not we want a cell with a tile
	 * @return
	 */
	private Cell getNextCellInRowCol(Cell cell, int rowCol, int direction, boolean isOccupied) {

		// If we are searching up, that means the column stays static and
		// the row decreases cell by cell
		if(direction == Board.UP) {

			for(int r = cell.boardLocation.row - 1; r >= 0; r--) {

				Cell tempCell = this.getCell(r, 
						rowCol);

				if(isValidCell(tempCell, isOccupied)) {
					return tempCell;
				}
			}
			// If we are searching down, that means the column stays static and
			// the row increases cell by cell
		} else if(direction == Board.DOWN) {

			for(int r = cell.boardLocation.row + 1; r < Board.boardStructure.length; r++) {

				Cell tempCell = this.getCell(r, 
						rowCol);

				if(isValidCell(tempCell, isOccupied)) {
					return tempCell;
				}
			}
			// If we are searching left, the row stays the same and the column
			// decreases cell by cell
		} else if(direction == Board.LEFT) {

			for(int c = cell.boardLocation.col - 1; c >= 0; c--) {

				Cell tempCell = this.getCell(rowCol, 
						c);

				if(isValidCell(tempCell, isOccupied)) {
					return tempCell;
				}
			}
			// If we are searching left, the row stays the same and the column
			// increases cell by cell
		} else if(direction == Board.RIGHT) {

			for(int c = cell.boardLocation.col + 1; c < Board.boardStructure.length; c++) {

				Cell tempCell = this.getCell(rowCol, 
						c);

				if(isValidCell(tempCell, isOccupied)) {
					return tempCell;
				}
			}
		}

		// If nothing is found in this row/col, we return null
		return null;
	}

	/**
	 * Internal method for getNextCell. Determines is a given cell is valid
	 * based on whether the user specified isOccupied and whether the cell
	 * belongs to someone (if they are attempting to move it)
	 * @param newCell The cell being checked for validity
	 * @param isOccupied Whether or not we want an occupied cell
	 * @return
	 */
	private boolean isValidCell(Cell newCell, boolean isOccupied) {

		if(!isOccupied && newCell.getTile() == null) {
			return true;
		} else if (isOccupied && 
				newCell.getTile() != null &&
				newCell.getTile().owner == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * extractAdjacentWordCells takes a hash table of newly placed tiles and determines what potential words they are being used in,
	 * it returns an array of cell arrays containing all of the cells involved with new words
	 * @param placedTileCells Cells containing tiles placed by the player this turn
	 * @return Hash tabled of potential word cells
	 */
	public ArrayList<ArrayList<Cell>>  extractAdjacentWordCells(Hashtable<BoardLocation, Cell> placedTileCells){

		// This algorithm works thusly: We iterate through each cell containing a tile placed by the
		// player this turn. We then search through the adjacent contiguous cells in the row and column
		//of the cell and store them as potential words
		ArrayList<ArrayList<Cell>> potentialWordCells = new ArrayList<ArrayList<Cell>>();

		Iterator<BoardLocation> itr = placedTileCells.keySet().iterator();

		while (itr.hasNext()){

			BoardLocation bl = itr.next();

			ArrayList<Cell> colWordCells = extractColumnWordCells(bl);

			// Verify the word cells are not already counted and that the word is more than 1 letter
			if (!potentialWordCells.contains(colWordCells) && 
					colWordCells.size() > 1) {

				potentialWordCells.add(colWordCells);
			}

			ArrayList<Cell> rowWordCells = extractRowWordCells(bl);

			// Verify the word cells are not already counted and that the word is more than 1 letter
			if (!potentialWordCells.contains(rowWordCells) && 
					rowWordCells.size() > 1) {

				potentialWordCells.add(rowWordCells);
			}	
		}

		return potentialWordCells;
	}

	/**
	 * extractColumnWordCells is used by extractAdjacentWordCells to check for column words created with newly placed tiles
	 * it takes in the BoardLocation of the tile being checked and returns an array of cells if a word is 
	 * formed
	 * @param bl Location of cell whose row and column are being checked
	 * @return List of cells forming potential word
	 */
	ArrayList<Cell> extractColumnWordCells(BoardLocation bl){

		ArrayList<Cell> tempWord = new ArrayList<Cell>();
		tempWord.add(getCell(bl));

		// Check for adjacent tiles in the positive row direction, if they exist add the cells they reside in
		// to the end of the array of cells
		for (int i = bl.row + 1; i < Board.boardStructure.length; i++ ) {
			if (getCell(i, bl.col).getTile() != null) {
				tempWord.add(getCell(i, bl.col));
			} else {
				break;
			}
		}

		// Check for adjacent tiles in the negative row direction, if they exist add the cells they reside in
		// to the beginning of the array of cells
		for (int i = bl.row - 1; i >= 0; i-- ) {
			if (getCell(i, bl.col).getTile() != null) {
				tempWord.add(0, getCell(i, bl.col));
			} else {
				break;
			}
		}
		return tempWord;
	}

	/**
	 * extractRowWordCells is used by extractAdjacentWordCells to check for row words created with newly placed tiles
	 * it takes in the BoardLocation of the tile being checked and returns an array of cells if a word is 
	 * formed
	 * 
	 * @param bl Location of cell whose row and column are being checked
	 * @return List of cells forming potential word
	 */
	ArrayList<Cell> extractRowWordCells(BoardLocation bl){

		ArrayList<Cell> tempWord = new ArrayList<Cell>();
		tempWord.add(getCell(bl));

		// Check for adjacent tiles in the positive column direction, if they exist add the cells they reside in
		// to the end of the array of cells
		for (int i = bl.col + 1; i < Board.boardStructure.length; i++ ) {
			if (getCell(bl.row, i).getTile() != null) {
				tempWord.add(getCell(bl.row, i));
			} else	{
				break;
			}
		}

		// Check for adjacent tiles in the negative column direction, if they exist add the cells they reside in
		// to the beginning of the array of cells
		for (int i = bl.col - 1; i >= 0; i-- ){
			if (getCell(bl.row, i).getTile() != null) { 
				tempWord.add(0, getCell(bl.row, i));
			} else {
				break;
			}
		}

		return tempWord;
	}

	/**
	 * formWordsFromCells takes an array of cell arrays and determines the words that each cell array forms
	 * @param wordCells Cells containing potential words
	 * @return ArrayList of words formed by the cells
	 */
	public ArrayList<String> formWordsFromCells(ArrayList<ArrayList<Cell>> wordCells){

		ArrayList<String> words = new ArrayList<String>();
		Iterator<ArrayList<Cell>> wordItr = wordCells.iterator(); 

		while(wordItr.hasNext()) {

			ArrayList<Cell> cells = wordItr.next();
			Iterator<Cell> cellItr = cells.iterator();
			String word = "";

			while(cellItr.hasNext()) {
				word += cellItr.next().getTile().letter;
			}

			words.add(word);
		}

		return words;
	}

}

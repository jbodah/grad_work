package ks.server.controllers;

import ks.framework.common.Message;
import ks.framework.communicator.Communicator;

/**
 * This class defines the chain of controllers that I will provide for you. As this
 * list grows (if at all) I will alert the class.
 * 
 * Note: I am now allowing these to be processed by Me AND THEN they are allowed to propagate 
 * through the chain. This will allow everyone to do what they need to do...
 * 
 * @author George Heineman
 */
public class DefaultServerChain extends ServerControllerChain {
	
	/**
	 * Default controllers are:
	 * 
	 * {@link LoginController}
	 * {@link LogoutController}
	 */
	@Override
	public boolean process(Communicator com, Message m) {
		
		if (m.getName().equals ("login")) {
			boolean rv = new LoginController().process(com, m);
			next(com, m);
			return rv;
		}
		
		if (m.getName().equals ("logout")) {
			boolean rv = new LogoutController().process(com, m);
			next (com, m);
			return rv;
		}
		
		// try the next one
		return next(com, m);
	}

	
}

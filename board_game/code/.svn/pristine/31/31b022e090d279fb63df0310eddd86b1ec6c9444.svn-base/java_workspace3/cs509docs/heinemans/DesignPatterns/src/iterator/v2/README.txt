Decision is to replace array-based implementation (which had defect) with 
Hashtable to make a more efficient implementation.

Instead of extending Hashtable (as discussed in class) we create a Hashtable
object and delegate methods to it.


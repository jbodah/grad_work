package ks.client.interfaces;

import javax.swing.JMenuBar;
import javax.swing.JPanel;

import ks.client.UserContext;

/**
 * This abstraction presents the interface that most client-side component
 * need from the lobby without exposing the lobby itself.
 * 
 * @author George Heineman
 */
public interface ILobby {

	/** Return user context associated with the lobby. */
	UserContext getContext();
	
	/** 
	 * Append string to the lobby output ('\n' is prepended prior to
	 * the insertion).
	 * 
	 * @param s     the message to deliver
	 */
	void append(String s);

	/**
	 * Return the JPanel associated as the TableManagerGUI
	 */
	JPanel getTableManagerGUI();
	
	/**
	 * Return the JPanel associated as the UserManagerGUI
	 */
	JPanel getUserManagerGUI();
	
	/**
	 * Return the MenuBar so it can be expanded as you see fit.
	 */
	JMenuBar getJMenuBar();
	
	/** 
	 * Tell lobby of connected status.
	 * 
	 * @param status   latest connection status
	 */
	void connected(boolean status);
}

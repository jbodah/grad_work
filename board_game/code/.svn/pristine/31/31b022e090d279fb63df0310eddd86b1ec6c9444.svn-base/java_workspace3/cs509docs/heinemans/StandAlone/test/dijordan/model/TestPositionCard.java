package dijordan.model;

import junit.framework.TestCase;
import ks.common.model.Card;

public class TestPositionCard extends TestCase {

	public void testConstruct() {
		int row = 6;
		int position = 6;
		PositionCard pc = new PositionCard(Card.KING, Card.CLUBS, row, position);
		
	}
	
	public void testConstructSame() {
		int row = 6;
		int position = 6;
		PositionCard pc = new PositionCard(Card.KING, Card.CLUBS, row, position);
		PositionCard pc2 = new PositionCard(pc);
		assertEquals (pc, pc2);
		
	}
	
	public void testConstructCard() {
		int row = 6;
		int position = 6;
		PositionCard pc = new PositionCard(new Card(Card.KING, Card.CLUBS), row, position);
		PositionCard pc2 = new PositionCard(pc);
		assertEquals (pc, pc2);
		
	}
	
	public void testInvalidConstruct() {
		try {
			new PositionCard(Card.KING, Card.CLUBS, 8, 1);
			fail ("INVALID");
		} catch (Exception e) {
			// success
		}
		
		try {
			new PositionCard(Card.KING, Card.CLUBS, 1, 8);
			fail ("INVALID");
		} catch (Exception e) {
			// success
		}
		
		try {
			new PositionCard(Card.KING, Card.CLUBS, 0, 8);
			fail ("INVALID");
		} catch (Exception e) {
			// success
		}
		
		try {
			new PositionCard(new Card(Card.KING, Card.CLUBS), 8, 1);
			fail ("INVALID");
		} catch (Exception e) {
			// success
		}
		
		try {
			new PositionCard(new Card(Card.KING, Card.CLUBS), 1, 8);
			fail ("INVALID");
		} catch (Exception e) {
			// success
		}
		
		try {
			new PositionCard(new Card(Card.KING, Card.CLUBS), 0, 8);
			fail ("INVALID");
		} catch (Exception e) {
			// success
		}
		
	}
}

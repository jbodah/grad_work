package gui;

import java.awt.Graphics;

/**
 * The abstract base class representing both the renderer and the decorators being used
 * as part of the rendering process.
 * 
 * @author heineman
 */
public abstract class DrawingCanvas {
	
	/**
	 * Redraw the state.
	 *
	 * Note that each inner Decorator is going to have to maintain the graphics
	 * entity into which the actual drawing is to be done. We do it this way to 
	 * avoid having to force a particular parameter to the outermost client that
	 * invokes the drawing in the first place. Specifically, why should that client
	 * Know of the graphics object? Leave that knowledge to the concrete decorators and
	 * the main drawer.
	 */
	public abstract void drawState (Graphics g);

	
}

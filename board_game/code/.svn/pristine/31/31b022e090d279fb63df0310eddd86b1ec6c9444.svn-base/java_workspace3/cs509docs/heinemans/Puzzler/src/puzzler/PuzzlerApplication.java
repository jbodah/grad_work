package puzzler;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;

import puzzler.controller.AboutController;
import puzzler.controller.ExitApplicationController;
import puzzler.controller.LoadPuzzleController;
import puzzler.controller.gui.PieceMoverController;
import puzzler.view.PuzzleManipulation;

//VS4E -- DO NOT REMOVE THIS LINE!
public class PuzzlerApplication extends JFrame {

	private static final long serialVersionUID = 1L;
	private JMenuItem openFile;
	private JMenu fileMenu;
	private JMenuBar jMenuBar0;
	private JMenuItem aboutMenuItem;
	private JMenu aboutMenu;
	private JMenuItem exitMenuItem;
	private JSplitPane mainPanel;
	private PuzzleManipulation puzzlePanel;
	
	/** Controller to manage mouse events in the manipulation frame. */
	PieceMoverController mover; 
	
	private JTextField statusField;
	private static final String PREFERRED_LOOK_AND_FEEL = "javax.swing.plaf.metal.MetalLookAndFeel";
	public PuzzlerApplication() {
		initComponents();
	}

	private void initComponents() {
		setTitle("Puzzler 1.0");
		JPanel p = new JPanel();
		GroupLayout layout = new GroupLayout(p);
		p.setLayout(layout);
		
		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);
		
		layout.setHorizontalGroup(layout.createParallelGroup(Alignment.CENTER).
				addComponent(getStatusField()).
				addComponent(getJSplitPane0()));
		
		layout.setVerticalGroup(layout.createSequentialGroup().
				addComponent(getJSplitPane0()).
				addComponent(getStatusField(), GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE,
						GroupLayout.PREFERRED_SIZE));
		
		add(p);
		
		setJMenuBar(getJMenuBar0());
		setSize(606, 440);
	}

	private JTextField getStatusField() {
		if (statusField == null) {
			statusField = new JTextField();
			statusField.setEditable(false);
			statusField.setPreferredSize(new Dimension(800, 30));
		}
		return statusField;
	}

	
	public PuzzleManipulation getPuzzleManipulation() {
		if (puzzlePanel == null) {
			puzzlePanel = new PuzzleManipulation();
			puzzlePanel.setLayout(null);
			
			mover = new PieceMoverController(puzzlePanel);
	
			puzzlePanel.addMouseListener(mover);
			puzzlePanel.addMouseMotionListener(mover);
		}
		return puzzlePanel;
	}

	private JSplitPane getJSplitPane0() {
		if (mainPanel == null) {
			mainPanel = new JSplitPane();
			mainPanel.setDividerLocation(400);
			mainPanel.setRightComponent(new JLabel(""));
			mainPanel.setLeftComponent(getPuzzleManipulation());
		}
		return mainPanel;
	}

	/**
	 * Insert image within scrolling region.
	 * 
	 * @param img
	 */
	public void setSolution(Image img) {
		JLabel label = new JLabel();
		label.setText(null);
		label.setIcon (new ImageIcon(img));
		
		JScrollPane jsp = new JScrollPane();
		jsp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		jsp.setViewportView(label);
		
		mainPanel.setRightComponent(jsp);
	}
	
	private JMenuItem getOpenMenuItem() {
		if (openFile == null) {
			openFile = new JMenuItem();
			openFile.setText("Open...");
			openFile.addActionListener(new ActionListener() {
	
				public void actionPerformed(ActionEvent event) {
					openFileActionActionPerformed(event);
				}
			});
		}
		return openFile;
	}

	private JMenu getAboutMenu() {
		if (aboutMenu == null) {
			aboutMenu = new JMenu();
			aboutMenu.setText("About");
			aboutMenu.add(getAboutMenuItem());
		}
		return aboutMenu;
	}

	private JMenuItem getAboutMenuItem() {
		if (aboutMenuItem == null) {
			aboutMenuItem = new JMenuItem();
			aboutMenuItem.setText("About");
			
			aboutMenuItem.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent event) {
					aboutMenuItemActionActionPerformed(event);
				}
			});
		}
		return aboutMenuItem;
	}

	private JMenuBar getJMenuBar0() {
		if (jMenuBar0 == null) {
			jMenuBar0 = new JMenuBar();
			jMenuBar0.add(getFileMenu());
			jMenuBar0.add(getAboutMenu());
		}
		return jMenuBar0;
	}

	private JMenu getFileMenu() {
		if (fileMenu == null) {
			fileMenu = new JMenu();
			fileMenu.setText("File");
			fileMenu.add(getOpenMenuItem());
			fileMenu.add(getExitMenuItem());
		}
		return fileMenu;
	}

	private JMenuItem getExitMenuItem() {
		if (exitMenuItem == null) {
			exitMenuItem = new JMenuItem();
			exitMenuItem.setText("Exit");
			exitMenuItem.addActionListener(new ActionListener() {
	
				public void actionPerformed(ActionEvent event) {
					exitMenuItemActionActionPerformed(event);
				}
			});
		}
		return exitMenuItem;
	}

	
	/**
	 * Main entry of the class.
	 * Note: This class is only created so that you can easily preview the result at runtime.
	 * It is not expected to be managed by the designer.
	 * You can modify it as you like.
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				final PuzzlerApplication frame = new PuzzlerApplication();
				frame.setDefaultCloseOperation(PuzzlerApplication.DO_NOTHING_ON_CLOSE);
				frame.setTitle("PuzzlerApplication");
				frame.getContentPane().setPreferredSize(frame.getSize());
				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
				
				frame.addWindowListener(new WindowAdapter() {
					@Override
					public void windowClosing(WindowEvent e) {
						new ExitApplicationController(frame).process();
					}
				});
			}
		});
	}

	/**
	 * Show status information.
	 * 
	 * @param msg   Message to show
	 */
	public void status(String msg) {
		getStatusField().setText(msg);
	}

	/**
	 * Clear status warning messages.
	 */
	public void statusOK() {
		getStatusField().setText("");
	}

	private void openFileActionActionPerformed(ActionEvent event) {
		new LoadPuzzleController(this).process();
	}

	private void exitMenuItemActionActionPerformed(ActionEvent event) {
		new ExitApplicationController(this).process();
	}

	private void aboutMenuItemActionActionPerformed(ActionEvent event) {
		new AboutController(this).process();
	}
	
	/**
	 * Must be able to expose this controller because it needs to be 
	 * customized with the current puzzle.
	 */
	public PieceMoverController getPieceMoverController() {
		return mover;
	}

	/**
	 * Ensure window is split evenly.
	 */
	public void splitWindowEvenly() {
		getJSplitPane0().setDividerLocation(0.5);
	}

}

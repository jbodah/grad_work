package ks.client.controllers;

import org.w3c.dom.Document;

import junit.framework.TestCase;
import ks.client.interfaces.ILobby;
import ks.framework.common.Configure;
import ks.framework.common.Message;

public class TestClientControllerChain extends TestCase {

	ILobby lobby;
	Message m;
	
	protected void setUp() {
		lobby = new SampleLobby(); 
		
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
		
		String s = Message.requestHeader() + "<chat><text>Here is the message</text></chat></request>";
		Document d = Message.construct(s);
		assertTrue (d != null);
		m = new Message(d);
	}
	
	public void testChainEmpty() {
		ClientControllerChain ccc = new ClientControllerChain();
		assertTrue (ccc.next == null);
	}
	
	public void testNotHandled() {
		
		
		ClientControllerChain ccc = new ClientControllerChain();
		assertFalse (ccc.process(lobby, m));
	}
	
	// chain, but still none process the request.
	public void testCreateChain() {
		ClientControllerChain ccc = new ClientControllerChain();
		
		// this one "processes" all of its messages by delegating to next in the chain
		ClientControllerChain cccNext = new ClientControllerChain() {
			public boolean process(ILobby lobby, Message m) {
				return next(lobby, m);
			} 
		};
		
		ccc.append(cccNext);
		assertFalse (cccNext.process(lobby, m));
	}
	
	// chain, but still none process the request.
	public void testCreateMultipleChain() {
		ClientControllerChain ccc = new ClientControllerChain();
		
		// this one "processes" all of its messages by delegating to next in the chain
		ClientControllerChain cccNext = new ClientControllerChain() {
			public boolean process(ILobby lobby, Message m) {
				return next(lobby, m);
			} 
		};
		
		// this one "processes" all of its messages by delegating to next in the chain
		ClientControllerChain ccc2Next = new ClientControllerChain() {
			public boolean process(ILobby lobby, Message m) {
				return next(lobby, m);
			} 
		};
		
		ccc.append(cccNext);
		ccc.append(ccc2Next);
		assertFalse (ccc.process(lobby, m));
	}
	
	// chain, but still none process the request.
	public void testTakeMessage() {
		// this one "processes" all of its messages by delegating to next in the chain
		ClientControllerChain ccc = new ClientControllerChain() {
			public boolean process(ILobby lobby, Message m) {
				return true;
			} 
		};
		
		assertTrue (ccc.process(lobby, m));
	}
}

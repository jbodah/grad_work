package wordsteal.boundaries.main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;


import wordsteal.controllers.AccessibilityController;
import wordsteal.controllers.MoveTileController;
import wordsteal.entities.Game;
import wordsteal.entities.GameState;
import wordsteal.entities.Player;
import wordsteal.entities.Rack;
import wordsteal.entities.ReqTilesPerTurn;
import wordsteal.entities.Tile;
import wordsteal.interfaces.IWordstealApp;

/** Wordsteal core game elements. */
public class MainJPanel extends javax.swing.JPanel implements IWordstealApp {

	/** Keep Eclipse happy. */
	private static final long serialVersionUID = 1L;
	
	/** Handle to top-level entity object representing game state */
	Game game = null;
	
	/** Must store table information. */
	int tableNumber;
	
	/** Persistent mouse event handler */
	MoveTileController moveTileController = new MoveTileController(this);
	
	/** Persistent key event handler */
	AccessibilityController accessibilityController = new AccessibilityController(this);
	
	/** Current Timer */
	//TimerController timerController = new TimerController(this);
	
	/** knows of external interface to which major events are passed. */
	IExternalInterface callback;
	
	/** Default background color. */
	Color defaultBackgroundColor;
	
	/**
	 * Constructor
	 * @param title Title displayed on the titlebar of the application window
	 */
	public MainJPanel() {

		// Manually sets up Swing UI widgets
		setupGUI();
		
	}
	
	/**
	 * Allows other boundaries and controllers access to the game state
	 * @return Top-level Game entity containing game state and access to
	 */
	public Game getGame() {
		return game;
	}
	
	/**
	 * 
	 * @param game New game object
	 */
	public void setGame(Game game) {
		this.game = game;
	}
	
	/**
	 * Getter method for moveTileController
	 * For testing purposes
	 * @return MoveTileController
	 */
	public MoveTileController getMoveTileController() {
		return moveTileController;
	}
	
	/**
	 * Getter method for AccessibilityController
	 * For testing purposes
	 * @return AccessibilityController
	 */
	public AccessibilityController getAccessibilityController() {
		
		return accessibilityController;
	}
	
	/**
	 * Getter method for boardRackPanel
	 * For testing purposes
	 * @return BoardRackPanel
	 */
	public BoardRackPanel getBoardRackPanel() {
		
		return boardRackPanel;
	}	

	/**
	 * Updates GUI when a new game is set
	 */
	public void refreshGUI() {
		
		playerStatusPanel[1].setVisible(false);
		playerStatusPanel[2].setVisible(false);
		playerStatusPanel[3].setVisible(false);
		playerWordList[1].setVisible(false);
		playerWordList[2].setVisible(false);
		playerWordList[3].setVisible(false);
		
		// Update UI
		ArrayList<Player> pps = game.getPlayers();
		for(int i = 0; i < pps.size(); i++) {
			playerStatusPanel[i].setVisible(true);
			playerWordList[i].setVisible(true);
			((DefaultListModel)playerWordList[i].getModel()).clear();
			playerName[i].setText(game.getPlayers().get(i).name);
			playerPoints[i].setBackground(game.getPlayers().get(i).color);
			playerPoints[i].setText("0");
			playerBonusPoints[i].setText("0");
			playerWinning[i].setVisible(false);

			if (game.isInactive(i)) {
				playerName[i].setBackground(Color.darkGray);
				playerName[i].setOpaque(true);
			} else {
				playerName[i].setBackground(defaultBackgroundColor);
				playerName[i].setOpaque(false);
			}
		}
		
		
		// Set game variation icons
		winningScoreIcon.setText(String.valueOf(game.getPointsToWin()));
		
		if (game.isNoPinkEnabled()) {
			noPinkIcon.setIcon(new ImageIcon("Images/noPinkEnabled.png"));			
		} else {
			noPinkIcon.setIcon(new ImageIcon("Images/noPinkDisabled.png"));
		}
		
		if (game.isNoSEnabled()){
			noSIcon.setIcon(new ImageIcon("Images/noSenabled.png"));
		} else {
			noSIcon.setIcon(new ImageIcon("Images/noSdisabled.png"));
		}			
		
		if (game.getReqTilesPerTurn() == ReqTilesPerTurn.Normal) {
			reqTilesPerTurnIcon.setIcon(new ImageIcon("Images/reqTilesAny.png"));
		} else if (game.getReqTilesPerTurn() == ReqTilesPerTurn.Two) {
			reqTilesPerTurnIcon.setIcon(new ImageIcon("Images/reqTiles2.png"));
		} else {
			reqTilesPerTurnIcon.setIcon(new ImageIcon("Images/reqTiles3.png"));
		}
		
		// Add clock to current players turn
		//playerClockIcon[game.getCurrentPlayer()].setVisible(true);
		
		//	Add tiles to rack
		for(int i = 0; i < Rack.maxTiles; i++) {
			Tile tile = new Tile(game.getDictionary().generateLetter());
			game.getRack().addTile(tile);
		}

		repaintBoardAndRack();
	}
	
	/**
	 * Enables/disables the UI
	 * @param lock Whether to enable/disable
	 */
	public void lockUI(boolean lock) {
		
		setEnabled(!lock);
	}
	
	
	/** Expose whether GUI has been locked so controllers know. */
	public boolean isLockedUI() {
		return !isEnabled();
	}
	
	/** Main UI panel holding all other widgets */
	JPanel mainPanel;
	
	/** Panel holding status information */
	JPanel bottomMainPanel;
	/** Panel holding title and board/rack display */
	JPanel leftMainPanel;
	/** Panel holding game information and player scores */
	JPanel rightMainPanel;
	
	/** Displays status messages */
	JLabel statusLabel;
	
	/** Draws the board and rack */
	BoardRackPanel boardRackPanel;
	
	/** Panel holding information about rule settings, New Game button */
	JPanel gameStatePanel;
	/** Panel holding player information such as scores and word lists */
	JPanel playerPanel;
	
	/** Displays points needed to win the game */
	JLabel winningScoreIcon;
	/** Displays whether or not No S rule variation is enabled */
	JLabel noSIcon;
	/** Displays whether or not No Pink rule variation is enabled */
	JLabel noPinkIcon;
	/** Displays the rule variation specifying how many tiles must be played each turn */
	JLabel reqTilesPerTurnIcon;
	
	/** Panel holding widgets for players 1 and 3 */
	JPanel leftPlayerPanel;
	
	/** Panel holding widgets for players 2 and 4 */
	JPanel rightPlayerPanel;
	
	/** Panel holding player info: points, bonus points, name, winning?, clock and time left */
	JPanel[] playerStatusPanel = new JPanel[4];
	
	/** Displays how many points the player has in their color */
	JLabel[] playerPoints = new JLabel[4];
	
	/** Displays how many bonus points the player has (in orange) */
	JLabel[] playerBonusPoints = new JLabel[4];
	
	/** Displays the player's name */
	JLabel[] playerName = new JLabel[4];
	
	/** Displays a star icon next to a player's name if they are winning */
	JLabel[] playerWinning = new JLabel[4];

	/** Displays the list of words the player has placed this game */
	JList[]  playerWordList = new JList[4];
	
	/**
	 * Sets up the Swing widgets for the main UI
	 */
	private void setupGUI() {
		
		// Bottom Status Panel
		bottomMainPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		
		statusLabel = new JLabel("");
		statusLabel.setFont(new Font("Tahoma", 1, 18));
		
		bottomMainPanel.add(statusLabel);
		
		// Left Canvas Panel
		leftMainPanel = new JPanel();
		leftMainPanel.setLayout(new BoxLayout(leftMainPanel, BoxLayout.Y_AXIS));
		
		//		Title Panel
		FlowLayout fl = new FlowLayout(FlowLayout.LEFT);
		fl.setAlignOnBaseline(true);

		
		//		Canvas
		boardRackPanel = new BoardRackPanel(this);
		boardRackPanel.setPreferredSize(new Dimension(BoardRackPanel.boardRackPanelPreferredWidth, 
													  BoardRackPanel.boardRackPanelPreferredHeight));
		boardRackPanel.addMouseListener(moveTileController);
		boardRackPanel.addMouseMotionListener(moveTileController);
		boardRackPanel.addKeyListener(accessibilityController);
		boardRackPanel.addFocusListener(accessibilityController);
		boardRackPanel.setFocusable(true);
		
		leftMainPanel.add(boardRackPanel);
		
		// Right Main Panel
		rightMainPanel = new JPanel();
		rightMainPanel.setLayout(new BoxLayout(rightMainPanel, BoxLayout.Y_AXIS));
		
		//		GameStatePanel
		gameStatePanel = new JPanel();
		gameStatePanel.setLayout(new BoxLayout(gameStatePanel, BoxLayout.X_AXIS));
		gameStatePanel.setMaximumSize(new Dimension(Short.MAX_VALUE, 0));
		
		winningScoreIcon = new JLabel(String.valueOf(Game.defaultPointsToWin),
				new ImageIcon("Images/pointsToWin.png"), JLabel.CENTER);
		winningScoreIcon.setVerticalTextPosition(JLabel.TOP);
		winningScoreIcon.setHorizontalTextPosition(JLabel.CENTER);
		winningScoreIcon.setBorder(BorderFactory.createLineBorder(Color.BLACK, 4));
		winningScoreIcon.setFont(new Font("Tahoma", 1, 20));
		
		noSIcon = new JLabel(new ImageIcon("Images/noSdisabled.png"));
		noSIcon.setBorder(BorderFactory.createLineBorder(Color.BLACK, 4));
		noSIcon.setFont(new Font("Tahoma", 1, 40));
		
		noPinkIcon = new JLabel(new ImageIcon("Images/noPinkdisabled.png"));
		noPinkIcon.setBorder(BorderFactory.createLineBorder(Color.BLACK, 4));
		noPinkIcon.setFont(new Font("Tahoma", 1, 40));
		
		reqTilesPerTurnIcon = new JLabel(new ImageIcon("Images/reqTilesAny.png"));
		reqTilesPerTurnIcon.setBorder(BorderFactory.createLineBorder(Color.BLACK, 4));
		reqTilesPerTurnIcon.setFont(new Font("Tahoma", 1, 40));
		
		gameStatePanel.add(Box.createRigidArea(new Dimension(5,0)));
		gameStatePanel.add(winningScoreIcon);
		gameStatePanel.add(Box.createRigidArea(new Dimension(5,0)));
		gameStatePanel.add(noSIcon);
		gameStatePanel.add(Box.createRigidArea(new Dimension(5,0)));
		gameStatePanel.add(noPinkIcon);
		gameStatePanel.add(Box.createRigidArea(new Dimension(5,0)));
		gameStatePanel.add(reqTilesPerTurnIcon);
		gameStatePanel.add(Box.createRigidArea(new Dimension(5,0)));
		
		rightMainPanel.add(Box.createRigidArea(new Dimension(0,5)));
		rightMainPanel.add(gameStatePanel);
		
		//		Player Panel
		int tempSizeX = BoardRackPanel.boardRackPanelPreferredWidth - 40;
		
		playerPanel = new JPanel();
		playerPanel.setLayout(new BoxLayout(playerPanel, BoxLayout.X_AXIS));
		playerPanel.setPreferredSize(new Dimension(tempSizeX, 
				  BoardRackPanel.boardRackPanelPreferredHeight));
		
		
		leftPlayerPanel = new JPanel();
		leftPlayerPanel.setLayout(new BoxLayout(leftPlayerPanel, BoxLayout.Y_AXIS));
		leftPlayerPanel.setMaximumSize(new Dimension(tempSizeX/2 - 11,
				Short.MAX_VALUE));
		leftPlayerPanel.setMinimumSize(new Dimension(tempSizeX/2 - 11,
				0));
		leftPlayerPanel.setPreferredSize(new Dimension(tempSizeX/2 - 11,
				0));
		
		
		rightPlayerPanel = new JPanel();
		rightPlayerPanel.setLayout(new BoxLayout(rightPlayerPanel, BoxLayout.Y_AXIS));
		rightPlayerPanel.setMaximumSize(new Dimension(tempSizeX/2 - 11,
				Short.MAX_VALUE));
		rightPlayerPanel.setMinimumSize(new Dimension(tempSizeX/2 - 11,
				0));
		rightPlayerPanel.setPreferredSize(new Dimension(tempSizeX/2 - 11,
				0));
		
		// Default game state
		Color[] colors = new Color[] {Color.RED, Color.BLUE, Color.GREEN, Color.PINK};
		String[] names = new String[] {"Player 1", "Player 2", "Player 3", "Player 4"};
		
		for(int i = 0; i < 4; i++) {
			playerStatusPanel[i] = new JPanel();
			playerStatusPanel[i].setLayout(new BoxLayout(playerStatusPanel[i], BoxLayout.X_AXIS));
			playerStatusPanel[i].setMaximumSize(new Dimension(Short.MAX_VALUE, 50));
			playerStatusPanel[i].setAlignmentX(LEFT_ALIGNMENT);
			
			playerPoints[i] = new JLabel("0");
			playerPoints[i].setPreferredSize(new Dimension(
					50,
					40));
			playerPoints[i].setHorizontalAlignment(JLabel.CENTER);
			playerPoints[i].setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			playerPoints[i].setFont(new Font("Tahoma", 1, 28));
			playerPoints[i].setBackground(colors[i]);
			playerPoints[i].setOpaque(true);
			playerPoints[i].setAlignmentX(LEFT_ALIGNMENT);
			playerPoints[i].setAlignmentY(BOTTOM_ALIGNMENT);
			
			playerBonusPoints[i] = new JLabel("0");
			playerBonusPoints[i].setPreferredSize(new Dimension(
					15,
					playerBonusPoints[i].getPreferredSize().height));
			playerBonusPoints[i].setHorizontalAlignment(JLabel.CENTER);
			playerBonusPoints[i].setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			playerBonusPoints[i].setFont(new Font("Tahoma", 1, 12));
			playerBonusPoints[i].setBackground(Color.ORANGE);
			playerBonusPoints[i].setOpaque(true);
			playerBonusPoints[i].setAlignmentX(LEFT_ALIGNMENT);
			playerBonusPoints[i].setAlignmentY(BOTTOM_ALIGNMENT);
			
			playerName[i] = new JLabel(names[i]);
			playerName[i].setFont(new Font("Tahoma", 1, 12));
			playerName[i].setAlignmentX(LEFT_ALIGNMENT);
			playerName[i].setAlignmentY(BOTTOM_ALIGNMENT);
			defaultBackgroundColor = playerName[i].getBackground();
			
			playerWinning[i] = new JLabel(new ImageIcon("Images/star.png"));
			playerWinning[i].setFont(new Font("Tahoma", 1, 12));
			playerWinning[i].setAlignmentX(LEFT_ALIGNMENT);
			playerWinning[i].setAlignmentY(BOTTOM_ALIGNMENT);
			playerWinning[i].setVisible(false);
			
			playerStatusPanel[i].add(playerPoints[i]);
			playerStatusPanel[i].add(playerBonusPoints[i]);
			playerStatusPanel[i].add(Box.createRigidArea(new Dimension(5,0)));
			playerStatusPanel[i].add(playerName[i]);
			playerStatusPanel[i].add(Box.createRigidArea(new Dimension(5,0)));
			playerStatusPanel[i].add(playerWinning[i]);
			
			playerWordList[i] = new JList(new DefaultListModel());
			playerWordList[i].setBackground(Color.WHITE);
			playerWordList[i].setFocusable(false);
			playerWordList[i].setOpaque(true);
			playerWordList[i].setAlignmentX(Component.LEFT_ALIGNMENT);
			playerWordList[i].setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			playerWordList[i].setMaximumSize(new Dimension(Short.MAX_VALUE, 140));
			playerWordList[i].setMinimumSize(new Dimension(0, 140));
			playerWordList[i].setPreferredSize(new Dimension(Short.MAX_VALUE, 140));
			playerWordList[i].setLayoutOrientation(JList.VERTICAL_WRAP);
			playerWordList[i].setVisibleRowCount(8);
		}
		
		leftPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		leftPlayerPanel.add(playerStatusPanel[0]);
		leftPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		leftPlayerPanel.add(playerWordList[0]);
		leftPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		leftPlayerPanel.add(playerStatusPanel[2]);
		leftPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		leftPlayerPanel.add(playerWordList[2]);
		leftPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		leftPlayerPanel.add(Box.createVerticalGlue());
			
		rightPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		rightPlayerPanel.add(playerStatusPanel[1]);
		rightPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		rightPlayerPanel.add(playerWordList[1]);
		rightPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		rightPlayerPanel.add(playerStatusPanel[3]);
		rightPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		rightPlayerPanel.add(playerWordList[3]);
		rightPlayerPanel.add(Box.createRigidArea(new Dimension(0,5)));
		rightPlayerPanel.add(Box.createVerticalGlue());
		
		playerPanel.add(leftPlayerPanel);
		playerPanel.add(Box.createRigidArea(new Dimension(5,0)));
		playerPanel.add(rightPlayerPanel);
		playerPanel.add(Box.createRigidArea(new Dimension(5,0)));
		
		rightMainPanel.add(playerPanel);
		
		// Main Panel
		mainPanel = new JPanel(new BorderLayout(5,5));
		
		// Insert 4 main panels
		mainPanel.add(bottomMainPanel, BorderLayout.PAGE_END);
		mainPanel.add(leftMainPanel, BorderLayout.LINE_START);
		mainPanel.add(rightMainPanel, BorderLayout.LINE_END);
		
		// Insert main panel into frame
		add(mainPanel);
	}

	/**
	 * Sets the status label text
	 * @param text Status text to display
	 */
	public void setStatus(String text) {
		statusLabel.setText(text);
	}
	
	/**
	 * Refreshes the board and rack
	 */
	public void repaintBoardAndRack() {
		boardRackPanel.repaint();
	}
	
	/**
	 * updateGUI is called by SubmitWordController  and SkipTurnController, it updates the players wordlists,
	 * points, Bonus points, and rack on the mainframe
	 */
	public void updateGUI(){
		// Update UI
		int highScore = 0;
		
		// Determine what the high score is
		for(int i = 0; i < game.getPlayers().size(); i++) {
			if (game.getPlayers().get(i).getPoints() > highScore){
				highScore = game.getPlayers().get(i).getPoints();
			}
		}
		
		// Update player info and icons in the GUI
		for(int i = 0; i < game.getPlayers().size(); i++) {
			((DefaultListModel)playerWordList[i].getModel()).clear();
			for (int j = 0; j < game.getPlayers().get(i).getWords().size(); j++){			
				((DefaultListModel)playerWordList[i].getModel()).addElement(game.getPlayers().get(i).getWords().get(j));
			}
			playerPoints[i].setText(String.valueOf(game.getPlayers().get(i).getPoints()));
			playerBonusPoints[i].setText(String.valueOf(game.getPlayers().get(i).getBonusPoints()));
			playerWinning[i].setVisible(false);
			if (game.getPlayers().get(i).getPoints() >= highScore){
				playerWinning[i].setVisible(true);
			}
					
			if (game.isInactive(i)) {
				playerName[i].setBackground(Color.darkGray);
				playerName[i].setOpaque(true);
			} else {
				playerName[i].setBackground(defaultBackgroundColor);
				playerName[i].setOpaque(false);
			}
		}
		
		
		// Add tiles to rack if there are empty cells, if maximum number of consecutive skips is reached
		// then refresh the rack
		if (game.getConsecSkips() == game.getPlayers().size()) {
			int numInRack = game.getRack().getTiles().size();
			for(int i = 0; i < numInRack; i++) {
				// remove tile from rack
				game.getRack().removeTile(0);
				
				// add new one at the end
				Tile tile = new Tile(game.getDictionary().generateLetter());
				game.getRack().addTile(tile);
			}

			game.setConsecSkips(0);
		} else {
			int numInRack = game.getRack().getTiles().size();
			for(int i = numInRack; i < Rack.maxTiles; i++) {
				//Tile tile = new Tile(game.getDictionary().generateLetter());
				Tile tile = new Tile(game.getDictionary().generateLetter());
				game.getRack().addTile(tile);
			}
		}		
		
		repaintBoardAndRack();		
	}
	

	public MoveTileController moveTileController() {
		return moveTileController;
	}

	/** Retrieve the table number. */
	
	@Override
	public int getTableNumber() {
		return tableNumber;
	}
	
	/** Set the table number. */
	public void setTableNumber(int tn) {
		tableNumber = tn;
	}

	@Override
	public void skipTurn() {
		// Update the game log
		GameState gs = new GameState(getGame(), "Time is up! You lose your turn", 0, null);
		getGame().getGameLog().pushGameState(gs);
		
		getGame().returnPlayedTiles();
		//getGame().nextTurn();
		getGame().setConsecSkips(getGame().getConsecSkips() + 1);
		setStatus("Time is up! You lose your turn");
		updateGUI();

		// we have skipped our turn.
		callback.skipTurn();
	}

	/** Record the callback handler to which we send major events. */
	public void setCallback(IExternalInterface callback) {
		this.callback = callback;
	}

	/** Hilight active player. */
	public void activatePlayer(String name) {
		int idx = game.getPlayerIndex(name);
		playerName[idx].setBackground(Color.yellow);
		playerName[idx].setOpaque(true);
	}

}

package arch;

import junit.framework.TestCase;

public class TestServerArchitecture extends TestCase {

	public void testServer() {
		try {
			ServerArchitecture.main(new String[]{});
			assertTrue (ServerArchitecture.srv != null);
			
			// close it down
			ServerArchitecture.srv.deactivate();
			
		} catch (Exception e) {
			fail (e.getMessage());
		}
		
	}
}

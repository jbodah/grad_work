package puzzler.view;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;

import javax.swing.*;

import puzzler.model.PuzzlePiece;

/**
 * Represents a graphical interactive element of a puzzle piece.
 * 
 * @author heineman
 */
public class PuzzlePieceView extends JButton {
	
	/** Keep Eclipse happy. */
	private static final long serialVersionUID = -257355714913624305L;

	/** Perimeter to be stored as a polygonal shape. */
	Polygon perimeter;
	
	/** Transformed perimeter to handle rotations. */
	Area transformedPerimeter;
	
	/**
	 * Maintain link to Puzzle model element so we can tell if
	 * we are properly placed -- we draw differently when this
	 * is the case. 
	 */
	final PuzzlePiece piece;
	
	/**
	 * All drawing to be clipped within this boundary.
	 */
	Rectangle clipRegion;
	
	/** Image on which we are based. */
	final Image image;
	
	/** Anchor for puzzle piece within image. */
	final Point anchor;
	
	/** Rotation in PI/2 increments for 0, 90, 180 or 270 degrees. */
	double rotation = 0;
	
	/** Fixed rotations. */
	public static final double ROT0 = 0.0;
	public static final double ROT1 = Math.PI/2;
	public static final double ROT2 = Math.PI;
	public static final double ROT3 = 3*Math.PI/2;
	
	/** All rotations. */
	static final double[] rotations = { ROT0, ROT1, ROT2, ROT3 }; 
	static final String rotString = ROT0 + ", " + ROT1 + ", " + ROT2 + ", " + ROT3;
	
	/** Fixed distance to match. */
	public static final double delta = 0.0001;
	
	/**
	 * Buttons have no label to hinder the graphics.
	 * <p>
	 * All shape points are relative to the button anchor.
	 * 
	 * @param piece for which we are displaying
	 * @param img on which we are based
	 * @param shape allocated shape to use extract from image
	 * @param anchor point within the image
	 */
	public PuzzlePieceView(PuzzlePiece piece, Image img, Polygon shape, Point anchor) {
		super((String)null);

		// anchor the image 
		this.piece = piece;
		this.image = img;
		this.anchor = new Point(anchor);
		
		// extract points
		this.perimeter = shape;
		
		Rectangle maxBounds = shape.getBounds();
		
		// Grow as necessary
		setPreferredSize(new Dimension (maxBounds.width+2, maxBounds.height+2));

		// This call causes the JButton not to paint the background.
		// This allows us to paint a round background.
		setContentAreaFilled(false);
		
		// set up transformed polygon for containment checks.
		transformedPerimeter = new Area(shape);
		AffineTransform newXform = new AffineTransform();
		newXform.rotate(rotation);

		transformedPerimeter.transform(newXform);
	}

	@Override
	public int getHeight() {
		return (int)perimeter.getBounds().getHeight();
	}

	@Override
	public int getWidth() {
		return (int)perimeter.getBounds().getWidth();
	}

	/**
	 * Draw piece within this rectangle.
	 * 
	 * @param visibleRect
	 */
	public void setClipRegion(Rectangle visibleRect) {
		this.clipRegion = visibleRect; 
	}
	
	/**
	 * paint the piece
	 * 
	 */
	protected void paintComponent(Graphics g) {
		if (getModel().isArmed() && !piece.isProperlyPlaced()) {
			// You might want to make the highlight color 
			// a property of the RoundButton class.
			g.setColor(Color.lightGray);
			
			AffineTransform old = ((Graphics2D)g).getTransform();
			AffineTransform newXform = (AffineTransform)(old.clone());
			newXform.rotate(rotation);
			((Graphics2D)g).setTransform(newXform);

			g.fillPolygon(perimeter);
			
			// reset
			((Graphics2D)g).setTransform(old);
			return;
		}
		
		// basic clipping area is always a rectangle.
		Rectangle oldClip = (Rectangle) g.getClip();
		
		Rectangle bounds = perimeter.getBounds();
		if (clipRegion != null) {
			// note that g coordinates are LOCAL and we have to translate
			// the clipRegion into these local
			clipRegion.translate(-clipRegion.x, -clipRegion.y);
			
			// FIX LATER!!!
			
			// make sure we don't go beyond our containing space
	//		g.setClip(perimeter);
	//		Shape updateClip = g.getClip();
			Area area = new Area(clipRegion);
			System.out.println("area1:" + area.getBounds());
			Rectangle rect2 = new Rectangle(oldClip);
			rect2.translate(-oldClip.x, -oldClip.y);  // normalizes
			//rect2.translate(clipRegion.x, clipRegion.y);
			area.intersect(new Area(rect2));
			System.out.println("area2:" + area.getBounds());
			
			// begin trial
			// NO CLIPPING works on the Swing components but not the pieces.
			System.out.println("old:" + rect2);
			area.intersect(new Area(oldClip));  // make sure we bringin old clip
			System.out.println("area3:" + area.getBounds());
			
			
			Polygon trShape = new Polygon(perimeter.xpoints, perimeter.ypoints, perimeter.npoints);
			area.intersect(new Area(trShape));
			
			System.out.println("area4:" + area.getBounds());
			
			// rotate
			
			g.setClip(area);
			
			
			// end trial
			
	//		area.intersect(new Area(perimeter));
	//		g.setClip(area);
			
	//		int cornerX = clipRegion.getBounds().x;
	//		int cornerY = clipRegion.getBounds().y;
	//
	//		int minW = (int)clipRegion.getWidth();
	//		int minH = (int)clipRegion.getHeight();
	//		
	//		g.drawImage(image, cornerX, cornerY, cornerX+minW, cornerY+minH, 
	//				cornerX+anchor.x, cornerY+anchor.y, cornerX+anchor.x+minW, cornerY+anchor.y+minH,
	//				this);
			
			System.out.println(area.getBounds() + " :: " + clipRegion);
		} else {
			g.setClip(perimeter);
		}
		
		AffineTransform old = ((Graphics2D)g).getTransform();
		AffineTransform newXform = (AffineTransform)(old.clone());
		newXform.rotate(rotation);
		((Graphics2D)g).setTransform(newXform);
		
		g.drawImage (image, 0, 0, bounds.width, bounds.height,
				anchor.x, anchor.y, anchor.x + bounds.width, anchor.y+bounds.height,
				this);
		
		// reset
		((Graphics2D)g).setTransform(old);
		
		// reset clipping region
		g.setClip(oldClip);
		
		// Complete via Swing framework
		super.paintComponent(g);
	}

	// Paint the border of the button using a simple stroke, but only 
	// if not properly placed.
	protected void paintBorder(Graphics g) {
		if (piece.isProperlyPlaced()) {
			return;
		}
			
		g.setColor(getForeground());
		
		AffineTransform old = ((Graphics2D)g).getTransform();
		AffineTransform newXform = (AffineTransform)(old.clone());
		newXform.rotate(rotation);
		((Graphics2D)g).setTransform(newXform);
		
		g.drawPolygon(perimeter);
		
		// reset
		((Graphics2D)g).setTransform(old);
		
	}

	// Hit detection.
	public boolean contains(int x, int y) {
		return perimeter.contains(new Point (x,y));
	}
	
	/**
	 * Sets rotation but it must be one of the fixed set otherwise
	 * an exception is thrown.
	 * <p>
	 * Comparison is based on a delta of 0.0001 as compared to the 
	 * canonical PI/2, PI, 3*PI/2 rotational angles.
	 * 
	 * @param rot
	 */
	public void setRotation (double rot) throws IllegalArgumentException {
		for (double r : rotations) {
			if (Math.abs(rot - r) < delta) { 
				rotation = r;
				return;
			}
		}
		
		throw new IllegalArgumentException (rot + " is an invalid rotation. Must be one of " + rotString);
	}
	
	
	/**
	 * Make a clockwise rotation of the piece.
	 */
}

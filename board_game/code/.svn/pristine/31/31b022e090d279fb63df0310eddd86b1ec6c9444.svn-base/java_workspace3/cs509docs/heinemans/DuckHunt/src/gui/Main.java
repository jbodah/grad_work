package gui;

import controller.CreateController;

/**
 * Frame for encapsulating the DuckHunt game within a stand-alone application
 * 
 * @author heineman
 **/
public class Main extends java.awt.Frame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1026503477147285312L;


	/**
	 * The default constructor
	 */
	public Main() {
		super();
		
		this.setLayout(null);
		this.setSize(638, 542);
		this.setBackground(java.awt.Color.lightGray);
		this.setTitle("Duckhunt 2006");
	}

	
	/**
	 * Set up the game interface.
	 * 
	 * @param controller
	 */
	public void setup(CreateController controller) {
		this.add(controller.createPlayingArea(), null);
		this.add(controller.createStartButton(), null);
	}
	
}  //  @jve:decl-index=0:visual-constraint="10,10"

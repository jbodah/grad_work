package puzzler.view;

import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.util.Hashtable;

import javax.swing.JPanel;

import puzzler.controller.gui.EventDispatchController;
import puzzler.model.Puzzle;
import puzzler.model.PuzzlePiece;

/**
 * GUI widget responsible for showing the views of all puzzle pieces.
 * <p>
 * 
 * It is useful for this widget to know about the puzzle whenever it changes. 
 * Why? because the GUI controller that manages/manipulates the puzzle pieces
 * also needs to know about it, so we deal with that issue directly here
 * within the {@link #setPuzzle(Puzzle)} method.
 * 
 * @author George Heineman
 *
 */
//VS4E -- DO NOT REMOVE THIS LINE!
public class PuzzleManipulation extends JPanel {

	private static final long serialVersionUID = 1L;

	// Hashtable by id.
	Hashtable<Integer,PuzzlePieceView> pieces = new Hashtable<Integer,PuzzlePieceView>(); 

	/** Snappable grid coordinate size. */
	int gridSize = 10;
	
	public PuzzleManipulation() {
		initComponents();
	}

	private void initComponents() {
		setLayout(null);
		setSize(320, 240);
	}

	/**
	 * The panel maintains the grid-size for snapping pieces properly.
	 */
	public int getGridSize() {
		return gridSize;
	}
	
	/** Set the grid size for snapping pieces properly. */
	public void setGridSize(int gs) {
		this.gridSize = gs;
	}
	
	/**
	 * Query for a puzzle piece by unique identifier.
	 * 
	 * @param id
	 */
	public PuzzlePieceView getPiece(int id) {
		return pieces.get(id);
	}

	/**
	 * Add a piece at a specific location
	 * 
	 * @param piece  Piece for which we are being displayed
	 * @param image  image from which puzzle piece is drawn
	 * @param shape  polygon shape from the image to be drawn
	 * @param anchor original point from within image where polygon comes from.
	 *               Note that polygon uses relative coordinates not absolute
	 * @param loc    location on the board where piece is placed      
	 */
	public void addPiece(PuzzlePiece piece, Image image, Polygon shape, Point anchor, Point loc) {
		PuzzlePieceView ppv = new PuzzlePieceView(piece, image, shape, anchor);
		Rectangle bounds = shape.getBounds();
		ppv.setBounds(loc.x, loc.y, bounds.width, bounds.height);
		
		EventDispatchController mover = new EventDispatchController(ppv);
		ppv.addMouseListener(mover);
		ppv.addMouseMotionListener(mover);

		add(ppv);
		pieces.put(piece.id, ppv);
	}

	/**
	 * Bring a piece to the front.
	 * 
	 * @param id
	 */
	public void bringToFront(int id) {
		PuzzlePieceView ppv = pieces.get(id);
		
		remove(ppv);
		add(ppv, 0);  // bring to front.
		validate();
	}

}

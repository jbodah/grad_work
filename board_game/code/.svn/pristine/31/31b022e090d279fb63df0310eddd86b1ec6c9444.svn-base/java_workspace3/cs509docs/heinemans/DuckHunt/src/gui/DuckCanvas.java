package gui;

import java.awt.*;

/**
 * Canvas into which all drawing occurs.
 * 
 *   Knows about Game State.
 * @author George
 *
 */
public class DuckCanvas extends Canvas {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2646310410536981605L;

	/** Knows the decorator at the top of the chain. */
	DrawingCanvas drawing;
	
	/** Double buffer. */
	Image screenImage = null;

	/**
	 * Create canvas of given size, with known Drawer.
	 * 
	 * @param width
	 * @param height
	 */
	public DuckCanvas(int width, int height) {
		super();
		
		this.setSize(width, height);
	}	
	
	/** 
	 * Set the decorator chain for this canvas.
	 * 
	 * Decouple from the canvas constructor so it can be executed separately, as needed.
	 * 
	 * @param    drawing entity that forms a potential chain of decorators.
	 */
	public void setDrawers(DrawingCanvas drawing) {
		this.drawing = drawing;
	}
	
	/**
	 * Requests a redraw on the chain of drawers.
	 * 
	 * When invoked, all drawing decorators are asked to draw their state, then the
	 * canvas is repainted.
	 */
	public void redrawState() {
		ensureImageAvailable();
		
		// nothing to draw into? Must stop here.
		if (screenImage == null) return;
		
		// no drawers assigned? Must stop here.
		if (drawing == null) return;
		
		// clear the image.
		Graphics sc = screenImage.getGraphics();
		sc.clearRect(0, 0, this.getWidth(), this.getHeight());
		sc.setColor(Color.white);
		
		// cause the chain of drawing to commence. Make sure we start things off in black
		sc.setColor(Color.black);
		drawing.drawState(sc);
		
		// force the copy of the new state into our visible region.
		repaint();
	}
	
	/**
	 * Ensures that the image file into which decorators are drawn is properly constructed.
	 *
	 * Because of the way Java AWT works, you can't create an Image object until the Application
	 * is visible; however, this leads to a catch-22, so we perform "lazy computation" by
	 * creating the image once it is really needed.
	 */
	private void ensureImageAvailable() {
		// not yet created the background image. Must do now; can't do this until
		// we have a valid Graphics object.
		if (screenImage == null) {
			screenImage = this.createImage(this.getWidth(), this.getHeight());
		}
	}

	/**
	 * Paint method to copy image to screen, as part of a double buffering scheme.
	 * 
	 * @param g  Graphics entity
	 */
	public void paint (Graphics g) {
		// not visible yet (RARELY occurs).
		if (g == null) {
			return;
		}
		
		// simply overwrite the image.
		int w = getWidth();
		int h = getHeight();
		g.drawImage(screenImage, 0, 0, w, h, this);

	}



}

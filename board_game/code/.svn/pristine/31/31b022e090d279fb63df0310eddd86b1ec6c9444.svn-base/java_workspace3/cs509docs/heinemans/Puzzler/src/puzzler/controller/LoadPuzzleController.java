package puzzler.controller;

import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import puzzler.PuzzlerApplication;
import puzzler.constructor.PuzzleConstructor;
import puzzler.constructor.SimpleBlocksConstructor;
import puzzler.controller.gui.PieceMoverController;
import puzzler.model.Puzzle;
import puzzler.model.PuzzlePiece;
import puzzler.view.PuzzleManipulation;

/**
 * Load up a puzzle.
 * 
 * @author George Heineman
 */
public class LoadPuzzleController {

	/** Controller will need app to manage it properly. */
	PuzzlerApplication app;

	/** Use same FileChooser so we can remember past directories. */
	final JFileChooser chooser;

	/** Construct puzzle controller with application in mind. */
	public LoadPuzzleController(PuzzlerApplication pa) {
		this.app = pa;

		chooser = new JFileChooser();
	}

	/**
	 * Load up a puzzle.
	 */
	public void process() { 

		// Get a file
		int rc = chooser.showOpenDialog(app);

		if (rc == JFileChooser.APPROVE_OPTION) {
			File file = chooser.getSelectedFile();
			try {
				if (!processFile (file.getPath())) {
					app.status("Unable to load:" + file);
				} else {
					app.statusOK();
				}
			} catch (IOException e) {
				app.status("Unable to load:" + file);
				e.printStackTrace();
			}
		} 
	}

	/**
	 * Separate out the logic from the GUI elements in the controller so this
	 * capability can be validated through its own test cases.
	 * 
	 * @param fileName
	 * @throws IOException 
	 */
	boolean processFile (String fileName) throws IOException {

		File f = new File (fileName);
		if (!f.exists()) {
			return false;
		}
		
		Image image = Toolkit.getDefaultToolkit().createImage(fileName);
		if (image == null) {
			return false;
		}

		MediaTracker tracker = new MediaTracker (app);
		tracker.addImage (image, 0);
		try {
			tracker.waitForAll();
		} catch (InterruptedException e) {
			e.printStackTrace();
			return false;
		}
		
		int ht = image.getHeight(app);
		int wd = image.getWidth(app);
		
		// if we can't create graphics object from this image, it can't be drawn.
		if (ht <= 0 && wd <= 0) {
			return false;
		}

		// ok. So we have a meaningful puzzle. Let's break it up
		//Puzzle puzzle = new PuzzleConstructor().construct(wd, ht, 10, 50);
		// create sample puzzle
		SimpleBlocksConstructor sbc = new SimpleBlocksConstructor(wd, ht, 50);
		Puzzle puzzle = sbc.construct();
		
		// tell controller management about this new puzzle
		PieceMoverController pmc = app.getPieceMoverController();
		pmc.setPuzzle(puzzle);
		
		// add to manipulations area.  
		PuzzleManipulation pm = app.getPuzzleManipulation();
		pm.removeAll();
		
		// add in at 'semi-random' locations, starting at middle.
		Point loc = new Point (wd/2, ht/2);
		for (PuzzlePiece pp : puzzle) {
			loc.translate(2, 2);
			
			// Piece knows of its location for model
			pp.setLocation(loc.x, loc.y);
			
			// PieceView knows of its location so it can draw itself properly.
			pm.addPiece(pp, image, pp.shape, new Point(pp.properX, pp.properY), loc);
		}

		// redraw canvas area
		pm.invalidate();
		pm.repaint();
		
		// set solution image
		app.setSolution(image);
		
		// properly split window
		app.splitWindowEvenly();
		return true;
	}
}

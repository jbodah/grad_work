package gui;


import puzzler.PuzzlerApplication;
import puzzler.controller.ExitApplicationController;
import junit.framework.TestCase;

/**
 * Validate exit controller works.
 * 
 * @author George Heineman
 */
public class TestExitController extends TestCase {
	
	PuzzlerApplication app;
	
	@Override
	protected void setUp() {
		app = new PuzzlerApplication();
		app.setVisible(true);
	}
	
	public void testShow() {
		System.out.println("Click on NO in Exit Puzzler Application");
		ExitApplicationController ec = new ExitApplicationController(app);
		ec.process();
		assertTrue (app.isVisible());
		
		System.out.println("Click on YES in Exit Puzzler Application");
		ec = new ExitApplicationController(app);
		ec.process();
		assertFalse (app.isVisible());
	}

}

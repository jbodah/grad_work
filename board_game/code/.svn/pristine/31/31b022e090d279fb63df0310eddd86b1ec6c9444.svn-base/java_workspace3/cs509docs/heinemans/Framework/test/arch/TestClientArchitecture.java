package arch;

import junit.framework.TestCase;

public class TestClientArchitecture extends TestCase {
	
	public void testClient() {
		try {
			ClientArchitecture.main(new String[]{});
			assertTrue (ClientArchitecture.cf != null);
			
			assertTrue(ClientArchitecture.cf.isVisible());
			
			// close it down
			ClientArchitecture.cf.setVisible(false);
			ClientArchitecture.cf.dispose();
			
		} catch (Exception e) {
			fail (e.getMessage());
		}
		
	}
}

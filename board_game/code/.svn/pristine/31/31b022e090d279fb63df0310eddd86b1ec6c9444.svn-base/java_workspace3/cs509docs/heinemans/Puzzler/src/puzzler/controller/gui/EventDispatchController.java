package puzzler.controller.gui;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import puzzler.view.PuzzlePieceView;

/**
 * Enables "pass-through" of events if user clicks on a PuzzlePiece
 * button.
 * <p>
 * This is most assuredly a Swing-related issue and nothing that could
 * have been foreseen during analysis.
 * 
 * @author George Heineman
 */
public class EventDispatchController extends MouseAdapter {

	/** Panel being controlled. */
	PuzzlePieceView widget;
	
	/** Anchor point where first grabbed. */
	Point anchor;
	
	/** Currently selected piece (or null if none). */
	Component selected;
	
	public EventDispatchController(PuzzlePieceView widget) {
		this.widget = widget;
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		// translate so it will be correct within parent coordinates
		e.translatePoint(widget.getX(), widget.getY());
		widget.getParent().dispatchEvent(e);
	}
	
	@Override
	public void mouseReleased(MouseEvent e) {
		// translate so it will be correct within parent coordinates
		e.translatePoint(widget.getX(), widget.getY());
		widget.getParent().dispatchEvent(e);
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// translate so it will be correct within parent coordinates
		e.translatePoint(widget.getX(), widget.getY());
		widget.getParent().dispatchEvent(e);
	}

}

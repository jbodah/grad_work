package gui;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;


/**
 * Knows how to load up duck images and draw them into the Graphical state.
 * 
 * Because of java.awt requirements on MediaTracker, we must have access to
 * some GUI object so the images can be loaded. Thus the DuckDrawer requires
 * a java.awt.Component object in its constructor. 
 * 
 * @author heineman
 *
 */
public class DefaultDuckDrawer extends DuckDrawer {
	/**
	 * Image loader of duck images.
	 */
	MediaTracker mt;
	
	/** Needed for the entity capable of viewing image. */
	Component base;
	
	/** Duck image. */
	Image duckImage;
	
	/** Calculate based on image file. */
	int width = 0;
	int height = 0;
	
	/**
	 * Load up the image to be used for the duck.
	 * @param base   AWT component used to construct the images.
	 */
	public DefaultDuckDrawer (Component base) {
		mt = new MediaTracker(base);
		this.base = base;
	}
	
	/** 
	 * Return calculated width of the image.
	 * 
	 * Only meaningful after loadImage() called.
	 */
	public int getWidth() {
		return width;
	}
	
	/** 
	 * Return calculated height of the image.
	 * 
	 * Only meaningful after loadImage() called.
	 */
	public int getHeight() {
		return height; 
	}
	
	void loadImage (String name) {
		java.net.URL url = this.getClass().getResource (name);
		duckImage = java.awt.Toolkit.getDefaultToolkit().getImage(url);
		mt.addImage (duckImage, 0);
		
		try {
			mt.waitForAll();
		} catch (InterruptedException e) {
			System.err.println ("unable to load image:" + name);
		}
		
		// calculate things.
		width = duckImage.getWidth(base);
		height = duckImage.getHeight(base);
	}

	public void draw(Graphics g, int x, int y) {
		g.drawImage(duckImage, x, y, width, height, base);		
	}

	public void init() {
		// MUST start with '/' to properly be located.
		loadImage("/images/duck.gif");
	}
}

package liskov;

public class S {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double x = Math.sqrt(25);
		System.out.println (x);
	}

}

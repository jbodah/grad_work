package wordsteal.entities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Main entity that keeps track of game state
 * @author zbrod
 *
 */
public class Game {

	/** Default value for points to win */
	public static final int defaultPointsToWin = 50;
	
	/** Default value for time per turn */
	public static final int defaultTimePerTurn = 90;
	
	/** List of players in the game */
	ArrayList<Player> players = null;
	
	/** Inactive players. */
	boolean[] inactive = null;
	
	/** Handle to the game's board object */
	Board board = new Board();
	
	/** Handle to the game's rack object */
	Rack rack = new Rack();
	
	/** Handle to the game's dictionary */
	Dictionary dictionary = null;
	
	/** Whether or not the No S rule is enabled */
	boolean isNoSEnabled = false;
	
	/** Whether or not the No Pink rule is enabled */
	boolean isNoPinkEnabled = false;
	
	/** Required number of tiles to be placed each turn */
	ReqTilesPerTurn reqTilesPerTurn = ReqTilesPerTurn.Normal;
	
	/** Amount of points needed to win the game */
	int pointsToWin = Game.defaultPointsToWin;
	
	/** Amount of time alotted to each player per turn */
	int timePerTurn = Game.defaultTimePerTurn;
	
	/** Number of times players have consecutively skipped their turns */
	int consecSkips = 0;
	
	/** Whether or not it is the first turn */
	boolean isFirstTurn = true;
	
	/** Handle to the tile that is currently highlighted (keyboard play) */
	Tile highlightedTile = null;
	
	/** Handle to the tile that is currently "grabbed" (being dragged) by the tile */
	Tile grabbedTile = null;
	
	/** Handle to the original location of the currently grabbed tile */
	ITileLocation grabbedTileSrcLocation = null;
	
	/** X coordinate of the grabbed tile relative to BoardRackPanel */
	int grabbedTileX = 0;
	
	/** Y coordinate of the grabbed tile relative to BoardRackPanel */
	int grabbedTileY = 0;
	
	/** Index of the current player in the player list */
	//int currentPlayer = 0;
	
	/** Handle to the game's logger */
	GameLog gameLog = null;
	
	/** Handle to the game's undo/redo manager */
	UndoManager undoManager = null;
	
	/**
	 * Construct
	 * @param players - a list of Player objects participating in the game
	 * @param dictionary - a dictionary object used to generate letters and validate words
	 */
	public Game(ArrayList<Player> players, Dictionary dictionary) {
		
		this.players = players;
		inactive = new boolean[players.size()];
		
		// preset to all being active.
		for (int i = 0; i < players.size(); i++) {
			inactive[i] = false;
		}
		
		this.dictionary = dictionary;
		//currentPlayer = 0;
		undoManager = new UndoManager();
		gameLog = new GameLog();
	}
	
	/**
	 * 
	 * @return List of players in the game
	 */
	public ArrayList<Player> getPlayers() {
		return players;
	}
	
	/**
	 * 
	 * @return The game board
	 */
	public Board getBoard() {
		return board;
	}
	
	/**
	 * 
	 * @return The game rack
	 */
	public Rack getRack() {
		return rack;
	}
	
	/**
	 * 
	 * @return The dictionary used by the game
	 */
	public Dictionary getDictionary() {
		return dictionary;
	}
	
	/**
	 * 
	 * @return Whether or not the No S variation is enabled
	 */
	public boolean isNoSEnabled() {
		return isNoSEnabled;
	}
	
	/**
	 * 
	 * @return Whether or not the No Pink variation is enabled
	 */
	public boolean isNoPinkEnabled() {
		return isNoPinkEnabled;
	}
	
	/**
	 * 
	 * @return Whether or not it is the first turn of the game 
	 */
	public boolean isFirstTurn() {
		return isFirstTurn;
	}
	
	/**
	 * 
	 * @param enabled Whether or not the No S rule variation is enabled
	 */
	public void setNoSEnabled(boolean enabled) {
		isNoSEnabled = enabled;
	}
	
	/**
	 * 
	 * @param enabled Whether or not the No Pink rule variation is enabled
	 */
	public void setNoPinkEnabled(boolean enabled) {
		isNoPinkEnabled = enabled;
	}
	
	/**
	 * 
	 * @param enabled Whether or not it is the first turn of the game
	 */
	public void setFirstTurn(boolean enabled) {
		isFirstTurn = enabled;
	}
	
	/**
	 * 
	 * @return The number of tiles a player is required to play each turn
	 */
	public ReqTilesPerTurn getReqTilesPerTurn() {
		return reqTilesPerTurn;
	}
	
	/**
	 * 
	 * @param reqTilesPerTurn The number of tiles a player is required to play each turn
	 */
	public void setReqTilesPerTurn(ReqTilesPerTurn reqTilesPerTurn) {
		this.reqTilesPerTurn = reqTilesPerTurn;
	}

	/**
	 * 
	 * @return Points necessary to win the game
	 */
	public int getPointsToWin() {
		return pointsToWin;
	}

	/**
	 * 
	 * @param pointsToWin Points necessary to win the game
	 */
	public void setPointsToWin(int pointsToWin) {
		this.pointsToWin = pointsToWin;
	}

	/**
	 * 
	 * @return The number of consecutive times players have skipped their turns
	 */
	public int getConsecSkips() {
		return consecSkips;
	}

	/**
	 * 
	 * @param consecSkips The number of consecutive times players have skipped their turns
	 */
	public void setConsecSkips(int consecSkips) {
		this.consecSkips = consecSkips;
	}

	/**
	 * 
	 * @return Tile currently highlighted by the keyboard
	 */
	public Tile getHighlightedTile() {
		return highlightedTile;
	}

	/**
	 * 
	 * @param highlightedTile Tile currently highlighted by the keyboard
	 */
	public void setHighlightedTile(Tile highlightedTile) {
		this.highlightedTile = highlightedTile;
	}

	/**
	 * 
	 * @return Tile currently being dragged by the active player
	 */
	public Tile getGrabbedTile() {
		return grabbedTile;
	}

	/**
	 * 
	 * @param grabbedTile Tile currently being dragged by the active player
	 */
	public void setGrabbedTile(Tile grabbedTile) {
		this.grabbedTile = grabbedTile;
	}
	
	/**
	 * 
	 * @return Location currently grabbed tile was taken from
	 */
	public ITileLocation getGrabbedTileSrcLocation() {
		return grabbedTileSrcLocation;
	}

	/**
	 * 
	 * @param tileLocation Location currently grabbed tile was taken from
	 */
	public void setGrabbedTileSrcLocation(ITileLocation tileLocation) {
		grabbedTileSrcLocation = tileLocation;
	}
	
	/**
	 * 
	 * @return X coordinate relative to boardRackPanel of currently grabbed tile
	 */
	public int getGrabbedTileX() {
		return grabbedTileX;
	}

	/**
	 * 
	 * @param grabbedTileX X coordinate relative to boardRackPanel of currently grabbed tile
	 */
	public void setGrabbedTileX(int grabbedTileX) {
		this.grabbedTileX = grabbedTileX;
	}

	/**
	 * 
	 * @return Y coordinate relative to boardRackPanel of currently grabbed tile
	 */
	public int getGrabbedTileY() {
		return grabbedTileY;
	}

	/**
	 * 
	 * @param grabbedTileY X coordinate relative to boardRackPanel of currently grabbed tile
	 */
	public void setGrabbedTileY(int grabbedTileY) {
		this.grabbedTileY = grabbedTileY;
	}

	/**
	 * 
	 * @return Time each player has per turn
	 */
	public int getTimePerTurn() {
		return timePerTurn;
	}

	/**
	 * 
	 * @param timePerTurn Time each player has per turn
	 */
	public void setTimePerTurn(int timePerTurn) {
		this.timePerTurn = timePerTurn;
	}
	
	/**
	 * 
	 * @return Index into the list of the player whose turn it currently is
	 */
//	public int getCurrentPlayer() {
//		return currentPlayer;
//	}
	
	/**
	 * Increments the index of the current player BUT NOW
	 * take into account inactive players.
	 * 
	 */
//	public void nextTurn() {
//		int stopHere = currentPlayer;
//		if (++currentPlayer >= players.size()) {
//			currentPlayer = 0;
//		}
//		
//		// at this point, check to see if inactive and keep on going.
//		// make sure we have means to terminate loop
//		while (currentPlayer != stopHere && inactive[currentPlayer]) {
//			if (++currentPlayer >= players.size()) {
//				currentPlayer = 0;
//			}
//		}
//		
//		undoManager.clear();
//	}

	/**
	 * 
	 * @return Handle to the game logger
	 */
	public GameLog getGameLog() {
		return gameLog;
	}

	/**
	 * 
	 * @return Handle to the undo/redo manager
	 */
	public UndoManager getUndoManager() {
		return undoManager;
	}

	/**
	 * Returns all tiles played in the current turn to the rack
	 */
	public void returnPlayedTiles() {
		
		Collection<Cell> coll = board.getNewTiles().values();
		
		for(Iterator<Cell> iter = coll.iterator(); iter.hasNext();) {
			
			Cell cell = iter.next();
			Tile tile = cell.getTile();
			cell.setTile(null);
			rack.addTile(tile);
			
		}
	}

	/** Return the given player. */
	public Player getPlayer(int idx) {
		return players.get(idx);
	}

	/** Return whether given player is active or not. */
	public boolean isInactive(int idx) {
		return inactive[idx];
	}

	
	/**
	 * Remove by marking as inactive.
	 * 
	 * @param fullName
	 */
	public void removePlayer(String fullName) {
		for (int i = 0; i < players.size(); i++) {
			Player p = players.get(i);
			if (p != null && p.name.equals(fullName)) {
				inactive[i] = true;
				break;
			}
		}
	}

	/** Return player index. */
	public int getPlayerIndex(String name) {
		for (int i = 0; i < players.size(); i++) {
			Player p = players.get(i);
			if (p != null && p.name.equals(name)) {
				return i;
			}
		}
		
		return -1;
	}

	/** Return player object with given name. */
	public Player findPlayer(String name) {
		for (int i = 0; i < players.size(); i++) {
			Player p = players.get(i);
			if (p != null && p.name.equals(name)) {
				return p;
			}
		}
		
		return null;
	}


}

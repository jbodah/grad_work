package ks.client;

import ks.client.ipc.Client;
import ks.server.ipc.Server;

/**
 * Records information about the user and machine to which the KombatGames
 * is being connected.
 * <p>
 * This class also stores a reference to the actual {@link Client} object which
 * manages the communication with the server. This enables us to have multiple
 * client connection objects, which will help during testing.
 * <p>
 * This class will contain references to the key Managers on the client which will
 * enable two things. First, it will make it possible to rapidly find the appropriate
 * manager from within a controller. Second, it will do so in such a way that allows
 * us during testing to start up multiple clients so we can test our code. That is,
 * instead of using a Singleton Design pattern (where in the same test case all clients
 * would otherwise be sharing the same manager) we can ensure that each individually
 * connected client will have its own set of managers. 
 * 
 * @author George Heineman
 */
public class UserContext {

	/** Machine. */
	String host = "localhost";
	
	/** Port. */
	int port = Server.defaultPort;
	
	/** User info. */
	String user;
	
	/** User password. */
	String pass;
	
	/** Client object which manages all communication with remote server. */
	Client client;
	
	/** Whether this context was initiated anew by a brand new user. */
	boolean selfRegister = false;
	
	/** The IconManager for this client connection. */
	//final IconManager iconManager;
	
	public UserContext() { 
		
		// extend as necessary with other managers.
		//this.iconManager = new IconManager();
	}
	
	public String getUser() { return user; }
	public void setUser(String u) { user = u; }
	
	public String getPassword() { return pass; }
	public void setPassword(String p) { pass = p; }
	
	public String getHost() { return host; }
	public void setHost (String h) { host = h; }
	
	public int getPort () { return port; }
	public void setPort (int p) { port = p; }
	
	public Client getClient() { return client; }
	public void setClient (Client c) { client = c; }
	
	public boolean getSelfRegister() { return selfRegister; }
	public void setSelfRegister(boolean b) { selfRegister = b; }
	
	// Extend as necessary to retrieve managers.
	//public IconManager getIconManager() { return iconManager; }
	
}

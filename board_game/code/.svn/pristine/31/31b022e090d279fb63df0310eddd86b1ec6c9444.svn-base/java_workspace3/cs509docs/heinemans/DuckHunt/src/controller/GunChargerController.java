package controller;

import state.GameState;
import state.Gun;

/**
 * Responsible for recharging guns that have been fired.
 * 
 * Increases the charge on the given gun every 200 milliseconds.
 * 
 * @author heineman
 */
public class GunChargerController {
	
	/** Once false, we shutdown. */
	boolean active = true;
	
	/** known game state (including gun) */
	GameState state;
	
	/** Thread to do the updating. */
	UpdateThread updater;
	
	/**
	 * Thread used to encapsulate the operation of charging a gun every 200 milliseconds
	 * 
	 * @author heineman
	 */
	class UpdateThread extends Thread {
		public void run () {
			while(active) {
				
				// pause between updates
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					// do nothing...
				}
				
				Gun g = state.getGun();
				
				synchronized (g) {
					if (!g.isFullyCharged()) {
						g.increaseCharge();
					}
				}
				
			}
		}
	}
	
	/**
	 * The Game state that is being controlled.
	 * 
	 * @param state  state of the game.
	 */
	public GunChargerController(GameState state) {
		this.state = state;
	}
	
	/**
	 * Enables the  GunCharger controller to start operating.
	 */
	public void begin() {
		active = true;
		updater = new UpdateThread();
		updater.start();
	}
	
	/**
	 * Terminates the activity of the GunCharger controller.
	 */
	public void complete() {
		active = false;
	}
}
 
package ks.client.ipc;

import org.w3c.dom.Document;


import junit.framework.TestCase;
import ks.client.UserContext;
import ks.client.controllers.ConnectController;
import ks.client.controllers.DisconnectController;
import ks.client.lobby.LobbyFrame;
import ks.framework.common.Configure;
import ks.framework.common.Message;
import ks.server.ipc.Server;

/**
 * 
 */
public class TestClient extends TestCase {

	// host
	public static final String localhost = "localhost";
	
	// sample credentials
	public static final String user = "11323";
	public static final String password = "password";
	
	int specialPort;
	
	protected void setUp() {
		// Determine the XML schema we are going to use
		try {
			Message.unconfigure();
			assertTrue (Configure.configure());
			
			// validate a simple tables
			String s = Message.requestHeader() + "<chat><text>Here is the message</text></chat></request>";
			Document d = Message.construct(s);
			assertTrue (d != null);
			
			// random port
			specialPort = (int)(8000 + Math.random()*1000);
			
		} catch (Exception e) {
			fail ("Unable to setup Message tests.");
		}
	}

	
	private void waitASecond() {
		// literally wait a second.
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
	}
	
	public void testClient() {
		Server s = new Server(specialPort);
		assertTrue (s.activate());
		
		waitASecond();
		
		// create client to connect
		UserContext context = new UserContext();  // by default, localhost
		context.setPort(specialPort);
		LobbyFrame lobby = new LobbyFrame (context);
		lobby.setVisible(true);
		
		context.setUser(user);
		context.setPassword(password);
		context.setSelfRegister(false);
		
		assertTrue (new ConnectController(lobby).process(context));
		
		waitASecond();
		
		//assertTrue (new DisconnectController (lobby.getRoom()).process(context));
		assertTrue (lobby.tryToDisconnect());
		
		waitASecond();
		s.deactivate();
	
		lobby.setVisible(false);
		lobby.dispose();
	}	
	
	
	public void testClientManualDisconnect() {
		Server s = new Server(specialPort);
		assertTrue (s.activate());
		
		waitASecond();
		
		// create client to connect
		UserContext context = new UserContext();  // by default, localhost
		context.setPort(specialPort);
		LobbyFrame lobby = new LobbyFrame (context);
		lobby.setVisible(true);
		
		context.setUser(user);
		context.setPassword(password);
		context.setSelfRegister(false);
		
		new ConnectController(lobby).process(context);
		
		// have to wait a bit longer... HACK 
		waitASecond();
		waitASecond();
		waitASecond();
		
		// the other way to leave is to manually invoke controller.
		assertTrue (new DisconnectController (lobby).process(context));
		
		waitASecond();
		s.deactivate();

		lobby.setVisible(false);
		lobby.dispose();
	}	
	
	public void testClientWithNoServer() {
		
		// create client to connect
		UserContext context = new UserContext();  // by default, localhost
		LobbyFrame lobby = new LobbyFrame (context);
		lobby.setVisible(true);
		
		context.setUser(user);
		context.setPort(specialPort); // someplace (hopefully) no server is
		context.setPassword(password);
		context.setSelfRegister(false);
		
		new ConnectController(lobby).process(context);
		
		waitASecond();
		
		// client not connected
		assertFalse (context.getClient().isConnected);

		lobby.setVisible(false);
		lobby.dispose();
	}	
}

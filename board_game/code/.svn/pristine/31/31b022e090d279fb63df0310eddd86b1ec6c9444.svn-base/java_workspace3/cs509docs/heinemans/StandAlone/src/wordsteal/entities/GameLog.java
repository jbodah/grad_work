package wordsteal.entities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Class representing the game log
 * @author Dan
 *
 */
public class GameLog {
	
	/** List of game states representing the game log*/
	ArrayList<GameState> log = new ArrayList<GameState>();
	
	/**
	 * GameLog Constructor
	 */
	public GameLog() {	

	}
	
	/**
	 * Add a current game state to the game log
	 * @param gameState
	 */
	public void pushGameState(GameState gameState) {
		this.log.add(gameState);
	}
	
	/**
	 * Take the current game log and write it to a text file with the given title
	 * @param title
	 */
	public void writeToFile(String path) {
		File f = new File(path);
		
        try{
            // Try to create file 
            FileWriter fstream = new FileWriter(f);
            BufferedWriter output = new BufferedWriter(fstream);           	
          
            // Create game log header including date and time
            output.write("WORDSTEAL Game Log\r\n");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MMMMM.dd  hh:mm aaa");
            output.write(sdf.format(Calendar.getInstance().getTime()) + "\r\n\r\n");
                    
            if (this.log != null) {
            	//  Add information from each turn in the game to the game log
            	for (int i = 0; i < this.log.size(); i++) {
            		output.write("Turn # " + (i + 1) + "\r\n");
            		output.write("Current Player: ");
            		output.write(this.log.get(i).game.getPlayers().get(this.log.get(i).activePlayer).name + "\r\n");
            		output.write("Points currently held by all players in the game: \r\n");
            		for (int j = 0; j < this.log.get(i).game.getPlayers().size(); j ++){
            			output.write(this.log.get(i).game.getPlayers().get(j).name + ": ");
            			output.write(this.log.get(i).playerPoints.get(j) + "\r\n");
            		}
            		output.write("Bonus points currently held by all players in the game: \r\n");
            		for (int j = 0; j < this.log.get(i).game.getPlayers().size(); j ++){
            			output.write(this.log.get(i).game.getPlayers().get(j).name + ": ");
            			output.write(this.log.get(i).playerBonuses.get(j) + "\r\n");
            		}
            		if (this.log.get(i).newWords != null) {
            			output.write("Words added this turn: \r\n");
            			for (int j = 0; j < this.log.get(i).newWords.size(); j++){
            				output.write(this.log.get(i).newWords.get(j) + "\r\n");
            			}
            		}
            		output.write("Time Remaining in Player's turn: ");
            		output.write(this.log.get(i).playerTime + " seconds\r\n");
            		output.write("Status Message: " + this.log.get(i).getPlayerAction() + "\r\n");
            		output.write("\r\n");
            	}  
            }
            
            //Final game board state
            //Winner
            output.write("Final Board State\r\n");
            output.write("Game Winner: ");
            output.write(this.log.get(log.size()-1).game.getPlayers().get(this.log.get(log.size()-1).activePlayer).name + "\r\n");
            
            //Player points
    		output.write("Points currently held by all players in the game: \r\n");
    		for (int j = 0; j < this.log.get(log.size()-1).game.getPlayers().size(); j ++){
    			output.write(this.log.get(log.size()-1).game.getPlayers().get(j).name + ": ");
    			output.write(this.log.get(log.size()-1).playerPoints.get(j) + "\r\n");
    		}

            //Player bonus points
    		output.write("Bonus points currently held by all players in the game: \r\n");
    		for (int j = 0; j < this.log.get(log.size()-1).game.getPlayers().size(); j ++){
    			output.write(this.log.get(log.size()-1).game.getPlayers().get(j).name + ": ");
    			output.write(this.log.get(log.size()-1).playerBonuses.get(j) + "\r\n");
    		}
    		
            //Player word lists
    		output.write("Word Lists for all Players: \r\n");
    		for (int j = 0; j < this.log.get(log.size()-1).game.getPlayers().size(); j ++){
    			output.write(this.log.get(log.size()-1).game.getPlayers().get(j).name + ": \r\n");
    			for (int i = 0; i < this.log.get(log.size()-1).game.getPlayers().get(j).getWords().size(); i++) {
    				output.write(this.log.get(log.size()-1).game.getPlayers().get(j).getWords().get(i) + "\r\n");
    			}
    		}
                    
            output.write("\r\n");
            
            // End of the game log
            output.write("End of Log");
                    
            // Close the output stream
            output.close();            	
	            	
         }catch (Exception e){//Catch exception if any
             System.out.println("Error: " + e.getMessage());
         }
            	
      }        
        
}

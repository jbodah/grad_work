package ks.common.model;

import junit.framework.TestCase;

// facedown status mostly
public class TestBuildablePile extends TestCase {

	public void testToString() {
		BuildablePile p = new BuildablePile("sample");
		assertEquals ("[BuildablePile:sample:<empty>]", p.toString());
		p.add (new Card (2, Card.HEARTS));
		assertEquals ("[BuildablePile:sample:2H]", p.toString());
		p.add (new Card (3, Card.HEARTS));
		assertEquals ("[BuildablePile:sample:2H,3H]", p.toString());
	}
	
	public void testConstruct() {
		BuildablePile bp = new BuildablePile(null);
		
		assertTrue (bp.getName().startsWith("BuildablePile"));
		
		// empty? None face up
		assertFalse (bp.faceUp());
	}
	
	public void testFaceups() {
		BuildablePile bp = new BuildablePile("sample");
		bp.add(new Card (2, Card.HEARTS));
		
		// top card is face up
		assertTrue (bp.faceUp());
		
		bp.flipCard();
		
		// top card is no longer face up
		assertFalse (bp.faceUp());
	}
	
	public void testAll() {
		BuildablePile bp = new BuildablePile("sample");
		Card c1 = new Card (2, Card.HEARTS);
		c1.setFaceUp(false);
		
		bp.add(c1);
		bp.add(c1);
		bp.add(c1);
		bp.add(c1);
		
		Card c2 = new Card (3, Card.HEARTS);
		c2.setFaceUp(true);
		bp.add(c2);
		bp.add(c2);
		bp.add(c2);
		
		
		assertEquals (3, bp.getNumFaceUp());
		assertEquals (4, bp.getNumFaceDown());
		
		assertEquals ("[BuildablePile:sample:[2H],[2H],[2H],[2H],3H,3H,3H]", bp.toString());
	}
	
	
	
}

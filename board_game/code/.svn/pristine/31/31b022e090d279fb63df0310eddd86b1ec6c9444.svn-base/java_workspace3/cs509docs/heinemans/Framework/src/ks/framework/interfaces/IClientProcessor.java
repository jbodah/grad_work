package ks.framework.interfaces;

import ks.client.interfaces.IProcessClientMessage;

/**
 * A Client processor must be able to process messages via {@link IProcessClientMessage} 
 * as well as deal with the connected(boolean) status method that comes once the
 * connection to the server has been properly validated.
 * 
 * @author George Heineman
 */
public interface IClientProcessor extends IProcessClientMessage {
	
	/**
	 * When the connection status changes, this method is invoked. 
	 * 
	 * @param status  <code>true</code> once connected, <code>false</code> when no longer connected.
	 */
	public void connected(boolean status);

}

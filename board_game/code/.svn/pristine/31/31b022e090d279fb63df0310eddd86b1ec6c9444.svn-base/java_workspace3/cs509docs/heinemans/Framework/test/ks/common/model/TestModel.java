package ks.common.model;

import java.util.Enumeration;

import junit.framework.TestCase;

public class TestModel extends TestCase {

	public void testBase() {
		Model m = new Model();
		
		Element e1 = new Element();
		e1.setName("1");
		
		Element e2 = new Element();
		e2.setName("2");
		
		// none in there
		assertFalse (m.elements().hasMoreElements());
		
		assertTrue(m.addElement(e2));
		
		boolean found = false;
		for (Enumeration<Element> en = m.elements(); en.hasMoreElements(); ) {
			Element e = en.nextElement();
			if (e.getName().equals("2")) {
				found = true;
			}
		}

		assertTrue (found);
	}
	
	// prevent multiple elements with same name
	public void testMult() {
		Model m = new Model();
		
		Element e1 = new Element();
		e1.setName("1");
		
		Element e2 = new Element();
		e2.setName("1");
	
		assertTrue (m.addElement(e1));
		assertFalse (m.addElement(e2));
		
		try {
			m.addElement(null);
			fail ("can't add NULL element!");
		} catch (Exception e) {
			
		}
	}
	
	// test retrieval
	public void testRetrieval() {
		Model m = new Model();
		
		Element e1 = new Element();
		e1.setName("1");
		
		Element e2 = new Element();
		e2.setName("2");
	
		assertTrue (m.addElement(e1));
		assertTrue (m.addElement(e2));
		
		assertEquals (e1, m.getElement("1"));
		
		//  bad query
		assertTrue (m.getElement(null) == null);
	}
	
	// test removal
	public void testRemoval() {
		Model m = new Model();
		
		Element e1 = new Element();
		e1.setName("1");
		
		Element e2 = new Element();
		e2.setName("2");
	
		assertTrue (m.addElement(e1));
		assertTrue (m.addElement(e2));
		
		assertTrue (m.removeElement(e2));
		assertFalse (m.removeElement(e2));
		assertFalse (m.removeElement(null));
		
		m.removeAllElements();
		assertFalse(m.elements().hasMoreElements());
	}
}

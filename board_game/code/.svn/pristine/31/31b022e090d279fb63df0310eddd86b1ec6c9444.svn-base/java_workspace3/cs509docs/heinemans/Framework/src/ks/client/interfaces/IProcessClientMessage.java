package ks.client.interfaces;

import ks.framework.common.Message;

/**
 * Interface to declare the processing of a message on the client.
 * <p>
 * The message may be a request or a response. Sometimes the
 * class implementing this interface processes the message to generate
 * a request. Other times, the class implementing the interface is passing
 * along the message (without processing) along to another class who is
 * responsible for the actual processing.
 * 
 * @author George Heineman
 */
public interface IProcessClientMessage {
	
	/**
	 * Acts upon a message to be processed. If the message is appropriately
	 * handled then <code>true</code> is returned; otherwise <code>false</code>.
	 * <p>
	 * The definition of what constitutes an "appropriate handler" is left to
	 * the implementor of this interface to decide. For example, if a command
	 * handler is unable to complete the processing of the message then the 
	 * handler could return <code>false</code>. Similarly, the successful 
	 * processing of a message could return <code>true</code>.
	 * <p>
	 * @param lobby client-side agent in charge of the main lobby.
	 * @param m   Message to be processed. 
	 */
	boolean process (ILobby lobby, Message m);
}

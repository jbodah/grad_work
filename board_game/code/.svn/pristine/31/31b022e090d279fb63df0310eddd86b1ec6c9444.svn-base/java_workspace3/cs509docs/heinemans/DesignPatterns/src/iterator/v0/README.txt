Original idea is to show a MySet implementation and wonder how to expose each 
element in the set one at a time.

This implementation doesn't do much. It also has a design flaw that can be detected
through testing or just code inspection

Run the Driver to see how to iterate over the elements of this set.

Run the test cases to detect the defect.

package ks.client.game;

import heineman.Klondike;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Properties;

import wordsteal.Wordsteal;

import junit.framework.TestCase;
import ks.client.interfaces.IGameInterface;

public class TestGameManager extends TestCase {

	public void testSolitaireOptions() {
		String s = Klondike.class.getCanonicalName();
		Collection<String> opts = GameManager.validOptions(s);
		
		assertTrue (opts.contains("undo"));
		assertTrue (opts.contains("newHand"));
	}
	
	public void testWordsteal() {
		String s = Wordsteal.class.getCanonicalName();
		
		Collection<String> opts = GameManager.validOptions(s);
		
		assertTrue (opts.contains("noS"));
		assertTrue (opts.contains("pink"));
		assertTrue (opts.contains("turnTime"));
		assertTrue (opts.contains("pointsToWin"));
	}
	
	public void testGameFrames() {
		GameManager gm = GameManager.instance();
		
		IGameInterface callback = new SampleInterface();
		Properties options = new Properties();
		options.setProperty("game", "heineman.Klondike");
		options.setProperty("seed", "117");
		
		Properties gameOptions = new Properties();
		gameOptions.setProperty("undo", "true");
		gameOptions.setProperty("newHand", "true");
		
		Properties players = new Properties();
		players.setProperty("982", "George Heineman");
		players.setProperty("1124", "Paul Simon");
		players.setProperty("135", "");
		
		
		// forgot that Properties has no guaranteed ordering.
		ArrayList<String> order = new ArrayList<String>();
		order.add("982");
		order.add("1124");
		order.add("135");
		
		boolean success = gm.createGameWindow(13, "11234", options, gameOptions, order, players, callback);
		assertTrue (success);
		assertTrue (gm.frame != null);
		
	}
}

package ks.client.game.wordsteal;

import ks.client.interfaces.IGameInterface;
import wordsteal.entities.GameState;
import wordsteal.interfaces.IWordstealApp;


/**
 * SkipSelfTurnController is launched when the skip turn button is pressed in mainFrame.
 * The controller updates the number of consecutive skips in the game, passes turn to
 * the next player and updates the GUI accordingly.
 * @author Dan
 */
public class SkipSelfTurnController {
	
	/** Controller has handle to MainFrame */
	IWordstealApp mf;

	/** 
	 * Construct controller
	 * @param mainFrame MainFrame allows ability to set and retrieve entity information
	 */
	public SkipSelfTurnController(IWordstealApp mainFrame) {
		this.mf = mainFrame;
	}
	
	/**
	 * Launches the controller
	 * @param callback 
	 */
	public boolean process(WordstealGameInformation info, IGameInterface callback){
		int consecSkips = 0;
		
		//Return tiles to rack
		this.mf.getGame().returnPlayedTiles();
		
		// Update the game log
		GameState gs = new GameState(this.mf.getGame(), "Turn skipped!", 0, null);
		this.mf.getGame().getGameLog().pushGameState(gs);
		
		// Update consecutive skips, pass turn to next player, update GUI
		consecSkips = this.mf.getGame().getConsecSkips() + 1;
		this.mf.getGame().setConsecSkips(consecSkips);

		callback.skip(mf.getTableNumber());
		
		// disable buttons.
		info.enableButtons(false);
		info.resetTimer();
		this.mf.updateGUI();
		
		// make sure we lock out
		this.mf.lockUI(true);
		return true;
	}


	
}

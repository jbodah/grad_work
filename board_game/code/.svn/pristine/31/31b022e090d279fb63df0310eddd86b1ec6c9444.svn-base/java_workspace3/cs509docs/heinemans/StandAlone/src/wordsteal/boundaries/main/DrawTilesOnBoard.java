package wordsteal.boundaries.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import wordsteal.entities.Tile;


/**
 * Decorator that draws the tiles placed on the board
 * @author Zach
 *
 */
public class DrawTilesOnBoard extends DrawLayerBase {

	public DrawTilesOnBoard(IDrawLayer next, BoardRackPanel brp) {
		super(next, brp);
	}

	@Override
	public void draw(Graphics2D g2D) {
		
		if(this.brp.getMainFrame().getGame() != null) {
			for(int r = 0; r < BoardRackPanel.boardStructure.length; r++) {
				for(int c = 0; c < BoardRackPanel.boardStructure.length; c++) {
					Tile tile = this.brp.getMainFrame().getGame().getBoard().getCell(r, c).getTile();
					
					if(tile != null) {
						Color tileColor = Color.WHITE;
						
						if(tile.getOwner() != null) {
							tileColor = tile.getOwner().color;
						}
						
						Rectangle rect = new Rectangle(
								BoardRackPanel.boardOffsetX + 
									c * BoardRackPanel.boardCellLength + 1,
								BoardRackPanel.boardOffsetY + 
									r * BoardRackPanel.boardCellLength + 1,
								BoardRackPanel.boardCellLength - 1,
								BoardRackPanel.boardCellLength - 1);
						
						g2D.setColor(tileColor);
						g2D.fill(rect);
						
						if(tile.equals(this.brp.getMainFrame().getGame().getHighlightedTile())) {
							g2D.setColor(Color.RED);
						} else {
							g2D.setColor(Color.BLACK);
						}
						g2D.setFont(new Font("Monospaced", Font.BOLD, BoardRackPanel.boardTileFontSize));
						g2D.drawString(tile.letter,
								BoardRackPanel.boardOffsetX + 
									c * BoardRackPanel.boardCellLength +
									BoardRackPanel.boardTileLetterXOffset,
								BoardRackPanel.boardOffsetY + 
									r * BoardRackPanel.boardCellLength +
									BoardRackPanel.boardTileLetterYOffset);
					}
				}
			}
		}
		
		next(g2D);
	}

	@Override
	public String getDescription() {
		
		if(this.nextLayer != null) {
			return this.nextLayer.getDescription() + ", " + this.getClass().getName();
		} else {
			return this.getClass().getName();
		}
	}

}

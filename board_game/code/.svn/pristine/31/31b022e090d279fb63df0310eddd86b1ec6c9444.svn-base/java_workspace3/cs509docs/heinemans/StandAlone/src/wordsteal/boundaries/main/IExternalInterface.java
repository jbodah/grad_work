package wordsteal.boundaries.main;

public interface IExternalInterface {
	void skipTurn();
}
